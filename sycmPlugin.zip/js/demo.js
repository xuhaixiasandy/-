// function delay(ms) {
//     return new Promise(resolve => setTimeout(resolve, ms));
//   }
  
//   async function asyncFunction() {
//     console.log('Start');
    
//     await delay(2000); // 等待2秒钟
    
//     console.log('After 2 seconds');
    
//     const result = await fetch('https://www.baidu.com'); // 发起网络请求并等待响应
    
//     const data = await result.json(); // 解析响应的 JSON 数据
    
//     console.log('Data:', data);
    
//     console.log('End');
//   }
  
//   asyncFunction();

  