var owner_douyin_id = null;
var task_status = false;


// 监听来自content-script的消息
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    console.log('收到来自content-script的消息：' + JSON.stringify(request));
    // 获取cookies
    if (request.cmd === "get_cookie") {
        chrome.cookies.getAll({url: request.url}, function (cookie) {
            let cookies = {}
            cookie.forEach(function (c) {
                console.log(JSON.stringify(c));
                cookies[c.name] = c.value;
            });
            sendResponse(cookies);
        });
    }

    if (request.cmd === "chrome_storage_local_get") {
        chrome.storage.local.get(request.item, (result) => {
            console.log(request.item + "获取: " + result);
            sendResponse(result);
        })
    }

    if (request.cmd === "chrome_storage_local_set") {
        chrome.storage.local.set(request.item, () => {
            let msg = JSON.stringify(request.item) + "设置成功";
            sendResponse(msg);
        })
    }

    if (request.cmd === "chrome_storage_local_remove") {
        chrome.storage.local.remove(request.item, () => {
            let msg = request.item + "删除成功";
            sendResponse(msg);
        })
    }

    if (request.cmd === "updateCookie") {
        sendData(request, sender, sendResponse);
    }

    return true;

});


// chrome.contextMenus.create({
//     title: "上传cookie",
//     onclick: async function () {
//         debugger;
//         sendMessageToContentScript({cmd: 'test', value: '你好，我是popup！'}, function (response) {
//             console.log('来自content的回复：' + response);
//         } );
//
//         // 获取url
//         // let url = await new Promise((resolve, reject) => {
//         //     sendMessageToContentScript({cmd: 'get_url'}, function (response) {
//         //         console.log("get_url: " + response);
//         //         resolve(response);
//         //     })
//         // });
//         //
//         // // 获取账号
//         // let account_name = await new Promise((resolve, reject) => {
//         //     chrome.runtime.sendMessage({cmd: 'get_account'}, (response) => {
//         //         console.log("get_account: " + response);
//         //         resolve(response);
//         //     });
//         // });
//         //
//         // // 获取平台url
//         // let platform_url = await new Promise((resolve, reject) => {
//         //     chrome.runtime.sendMessage({cmd: 'get_platform_url'}, (response) => {
//         //         console.log("get_platform_url: " + response);
//         //         resolve(response);
//         //     });
//         // });
//         //
//         // let cookie_str = await new Promise((resolve, reject) => {
//         //     // 获取cookie
//         //     chrome.cookies.getAll({url: url}, function (cookie) {
//         //         let cookies = {}
//         //         cookie.forEach(function (c) {
//         //             console.log(JSON.stringify(c));
//         //             cookies[c.name] = c.value;
//         //         });
//         //         // 把cookie转换为字符串
//         //         const arr = []
//         //         for (const Key in cookies) {
//         //             arr.push(`${Key}=${response[Key]};'`)
//         //         }
//         //         let cookies_str = arr.join().slice(0, -2);
//         //         resolve(cookies_str)
//         //     });
//         // })
//         //
//         // // 上传cookie
//         // let data = {"account_name": account_name, "cookies": cookie_str};
//         // sendData(
//         //     {url: platform_url, data: data},
//         //     {},
//         //     alert
//         // )
//
//         // alert('您点击了右键菜单！');
//     }
// });

// chrome.webRequest.onBeforeSendHeaders.addListener(details => {
//     // cancel 表示取消本次请求
//     // debugger;
//     if (!showImage && details.type == 'image') return {cancel: true};
//     // 简单的音视频检测
//     // 大部分网站视频的type并不是media，且视频做了防下载处理，所以这里仅仅是为了演示效果，无实际意义
//     if (details.type == 'media') {
//         chrome.notifications.create(null, {
//             type: 'basic',
//             iconUrl: 'img/icon.png',
//             title: '检测到音视频',
//             message: '音视频地址：' + details.url,
//         });
//     }
// }, {urls: ["<all_urls>"]}, ["blocking", "requestHeaders", "extraHeaders"]);


function sendData(request, sender, sendResponse) {
    $.ajax({
        url: request.url,
        type: 'post',
        dataType: 'json',
        data: JSON.stringify(request.data),
        headers: {
            'Content-Type': 'application/json'
        },
        success: function (res) {
            if (res.code === 200) {
                console.log("更新cookie成功: " + JSON.stringify(request.data));
                sendResponse("更新cookie成功: " + request.data.account_name);
            }
        },
        error: function (e) {
            console.log("更新cookie失敗: " + JSON.stringify(request.data));
            sendResponse("更新cookie失败: " + request.data.account_name)

        }
    });
}


function sendMessageToContentScript(message, callback) {
    chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, message, function (response) {
            if (callback) callback(response);
        });
    });
}