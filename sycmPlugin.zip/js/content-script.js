let account_name_key = "account_name";


async function 平台选择() {

    // 创建div标签
    var elm_div = document.createElement("div");
    elm_div.style.width = "146px";
    elm_div.style.height = "30px";
    elm_div.style.lineHeight = "30px";
    elm_div.style.textAlign = "center";
    elm_div.style.display = "flex";
    // elm_div.style.position = "absolute";
    // elm_div.style.right = "1534px";
    // elm_div.style.top = "247px";

    //  创建span标签
    var elm_span = document.createElement("span");
    elm_span.innerText = "平台选择: ";
    elm_span.style.width = "90px";

    // 创建下拉框标签
    var select = document.createElement("select");
    select.id = "api";
    select.add(new Option("珀莱雅账号", "bly"))
    select.add(new Option("华熙账号", "hx"))
    select.add(new Option("梦幻账号", "mh"))
    select.add(new Option("天猫", "tm"))
    select.style.width = "120px";
    select.style.height = "30px";
    // 从本地存储中获取下拉框选中的平台作为默认值
    let platform = await get_platform();
    if (platform) {
        var index = platform.index;
        if (typeof index === "number") {
            select.options[index].selected = true;
        }
    }
    // span和下拉框成为div标签的子节点
    elm_div.appendChild(elm_span);
    elm_div.appendChild(select);
    // 把div节点添加到body
    document.body.appendChild(elm_div);
}


async function get_platform() {
    let platform = await storage_get({"platform": null});
    platform = platform.platform;
    return platform
}

async function storage_get(key) {
    return await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({cmd: 'chrome_storage_local_get', "item": key}, (response) => {
            console.log("chrome_storage_local_get: " + JSON.stringify(response));
            resolve(response);
        });
    })
}


async function storage_set(item) {
    await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({cmd: 'chrome_storage_local_set', "item": item}, (response) => {
            console.log("chrome_storage_local_set: " + response);
            resolve(response)
        });
    })
}

async function storage_remove(key) {
    await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({cmd: 'chrome_storage_local_remove', "item": key}, (response) => {
            console.log("chrome_storage_local_remove: " + response);
            resolve(response)
        });
    })
}


async function get_cookie() {
    return await new Promise((resolve, reject) => {
        // 获取cookies
        chrome.runtime.sendMessage({cmd: 'get_cookie', "url": location.href}, (response) => {
            console.log("cookies: " + JSON.stringify(response))
            console.log("cookies: " + JSON.stringify(response))
            const arr = []
            for (const Key in response) {
                arr.push(`${Key}=${response[Key]};'`)
            }
            resolve(arr.join().slice(0, -2));
        });
    });
}


async function 监听登录按钮事件(account_name_key) {
    document.getElementsByClassName("fm-button fm-submit password-login")[0].onclick = async function () {
        // 保存生意参谋账号昵称，解决跨域保存数据问题
        var account_name = document.getElementById("fm-login-id").value
        console.log("生意参谋登录账号昵称: " + account_name);
        let item = {};
        item[account_name_key] = account_name

        await storage_set(item);

        // 设置更新的平台，作为下次启动的默认值
        let node_select = document.getElementById("api");
        let index = node_select.selectedIndex;
        let text = node_select.options[index].text;
        let value = node_select.options[index].value;

        console.log("选中平台： " + text + ", 值: " + value);
        let platform = {
            "platform": {"index": index, "text": text, "value": value}
        }
        await storage_set(platform);
    }
}


document.addEventListener('DOMContentLoaded', async function () {


    var api = {
        "bly": "http://39.175.169.130:14567/bly/update/ck",
        "hx": "http://39.175.169.130:14567/hx/update/ck",
        "mh": "http://39.175.169.130:14567/mh/update/ck",
        "tm": "http://39.175.169.130:14567/tm/update/ck",
    }

    // 判断是否是生意参谋登录页面
    if (location.href.indexOf("sycm.taobao.com/custom/login.htm") !== -1) {
        // 重定向到登录页窗口
        location.href = "https://login.taobao.com/member/login.jhtml?from=sycm&full_redirect=true&style=minisimple&minititle=&minipara=0,0,0&sub=true&redirect_url=http://sycm.taobao.com/"
        return;
    }

    // 判断是否是登录页面，如果是登录页面删除本地存储的账号昵称
    if (location.href.indexOf("login.taobao.com/member/login.jhtml") !== -1) {
        await 平台选择();
        // 判断登录页面是否存在登录按钮，如果有登录按钮+登录页面证明是没有账号需要登录的
        var element_count = document.getElementsByClassName("fm-button fm-submit password-login").length;
        if (!element_count) {
            console.log("没有登录按钮");
            return
        }
        // 删除过去存储到浏览器的账号
        await storage_remove(account_name_key);
        // 如果浏览器里面没有账号，证明没有登录过，进行登录监听
        let o = await storage_get(account_name_key)
        let account_name = o[account_name_key]
        if (!account_name) {
            await 监听登录按钮事件(account_name_key);
        }
        return;
    }


    // 判断是否是登录成功页面
    if (location.href.indexOf("https://sycm.taobao.com/portal/home.htm") !== -1) {
        var elem = document.getElementsByClassName("node_modules-@ali-op-ebase-lib-redux-layouts-Frame-module-title-1OuLJ").item(0)
        if (!elem) {
            console.log("可能没有登录成功");
            return;
        }
        // 登录成功
        console.log("登录成功店铺: " + elem.innerText)
        let cookies = await get_cookie();
        console.log(cookies);

        let account_name = await storage_get(account_name_key)
        account_name = account_name[account_name_key]
        console.log("账号: " + account_name);

        // 上传账号
        let platform = await get_platform();
        if (platform) {
            var url = api[platform.value];
            // 更新cookie
            let data = {"account_name": account_name, "cookies": cookies};
            chrome.runtime.sendMessage({cmd: 'updateCookie', url: url, data: data}, (response) => {
                console.log("updateCookie: " + response);
                alert("updateCookie: " + response);
            });
        }
    }


});


// 接收来自后台的消息
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    // console.log(sender.tab ?"from a content script:" + sender.tab.url :"from the extension");
    console.log("接收来自后台的消息: " + JSON.stringify(request));
    if (request.cmd == 'test') {
        alert(request.value)
        sendResponse("hahahahhahahah");
    }
    ;
    if (request.cmd == 'get_url') {
        debugger;
        sendResponse(location.href);
    }
    // if (request.cmd == 'get_account') {
    //     let account_name = await storage_get(account_name_key)
    //     account_name = account_name[account_name_key]
    //     console.log("账号: " + account_name);
    //     sendResponse(account_name)
    // }
    // if (request.cmd == 'get_platform_url') {
    //     let platform = await get_platform();
    //     let url = api[platform.value];
    //     sendResponse(url)
    // }
    return true;
});