$("#start").click(start_task);
$("#stop").click(stop_task);
$("#getCookie").click(get_cookie)
$("#openback").click(openBackground)


function openBackground() {
    window.open(chrome.extension.getURL("background.html"));
}

// 启动任务
function start_task() {
    let url;


    var bg = chrome.extension.getBackgroundPage();
    bg.task_status = true;
    // 设置启动成功图标
    chrome.browserAction.setBadgeText({text: '执行'});
    chrome.browserAction.setBadgeBackgroundColor({color: [255, 0, 0, 255]});


    // sendMessageToContentScript({ cmd: 'status', value: 'start' }, function (response) {
    //     alert('来自content的回复：' + response);
    //     url = response
    // });
    // if (url.indexOf("www.douyin.com") == -1) {
    //     getCurrentTabId(tabId => {
    //         chrome.tabs.update(tabId, { url: 'https://www.douyin.com' });
    //     });
    // }


    // 1. 获取用户抖音id

}


// 停止任务
function stop_task() {
    var bg = chrome.extension.getBackgroundPage();
    bg.task_status = false;
    // 停止任务，去除图标状态
    chrome.browserAction.setBadgeText({text: ''});
    chrome.browserAction.setBadgeBackgroundColor({color: [0, 0, 0, 0]});

}


async function get_cookie() {

    let result = await new Promise((resolve, reject) => {
        chrome.cookies.getAll({url: 'https://sycm.taobao.com/portal/error.htm'}, function (cookie) {
            let cookies = {}
            cookie.forEach(function (c) {
                console.log(JSON.stringify(c));
                cookies[c.name] = c.value;
            });
            debugger;
            resolve(cookies)
        });
    })
    console.log(result)
    debugger;
    return result

}


// 获取当前选项卡ID
function getCurrentTabId(callback) {
    chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
        if (callback) callback(tabs.length ? tabs[0].id : null);
    });
}

// 发送消息contentScripts
function sendMessageToContentScript(message, callback) {
    chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, message, function (response) {
            if (callback) callback(response);
        });
    });
}

