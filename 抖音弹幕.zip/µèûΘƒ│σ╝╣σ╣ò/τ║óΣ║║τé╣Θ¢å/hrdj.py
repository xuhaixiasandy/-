import requests
from pymongo import MongoClient
import time

MONGO_HOST = "39.175.169.130"
MONGO_PORY = 27015
MONGO_DATABASE = "mongodb"

mg_client = MongoClient(
    host=MONGO_HOST,
    port=MONGO_PORY,
    username='boying',
    password='boying321',
)
db = mg_client['douyin_xu']
collection = db['3.8_抖音产品']


headers = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    # 'Accept-Encoding': 'gzip, deflate, br, zstd',
    'Content-Type': 'application/json',
    'sec-ch-ua': '"Chromium";v="122", "Not(A:Brand";v="24", "Google Chrome";v="122"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"macOS"',
    'Origin': 'https://www.hh1024.com',
    'Sec-Fetch-Site': 'cross-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Accept-Language': 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7',
}

json_data ={
  "param": "{\"no\":\"dy0011\",\"data\":{\"anchorId\":\"62226264798\",\"liveId\":\"7343730987832003380\"}}",
  "sign": "a1a07318af692aadd1adc3ed32799856183d1c82406f999425a24e8afb78cd8b",
  "tenant": "1",
  "timestamp": 1709872253750,
  "token": "b5/AKEvIjt5bWpKHt2Rf9s2Pg5Cv9yHq"
}


#每间隔1秒发送一次请求

while True:
    response = requests.post('https://ucp.hrdjyun.com:60359/api/dy', headers=headers, json=json_data, verify=False)
    content = response.text
    print(content)
    item = {
        "content": content,
        "created_time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    }
    collection.insert_one(item)
    time.sleep(60)
    print("插入成功")
