import requests
from pymongo import MongoClient
import datetime
import time

vidio_id = '7346034987541499155'
cursor = 0
count = 20
MONGO_HOST = "localhost"
MONGO_PORY = 27017
MONGO_DATABASE = "mongodb"

mg_client = MongoClient(
    host=MONGO_HOST,
    port=MONGO_PORY,
)
db = mg_client['douyin_dm']
collection = db['抖音评论_南昌']
import requests
import datetime
from pymongo import MongoClient

MONGO_HOST: str = "39.175.169.130"
MONGO_PORT = 27015
MONGO_PASSWORD: str = 'boying321'
MONGO_USERNAME: str = 'boying'
MONGO_AUTH_DB = 'admin'
MONGO_DB = 'douyin_xu'
collection= MongoClient(
    host=MONGO_HOST,
    port=MONGO_PORT,
    username=MONGO_USERNAME,
    password=MONGO_PASSWORD,
authSource=MONGO_AUTH_DB,
)[MONGO_DB]['抖音评论_南昌房子_付晓辉']


def get_comments(video_id, cursor, count):

    headers = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    # 'Accept-Encoding': 'gzip, deflate, br, zstd',
    'pragma': 'no-cache',
    'cache-control': 'no-cache',
    'sec-ch-ua': '"Chromium";v="122", "Not(A:Brand";v="24", "Google Chrome";v="122"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"macOS"',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': 'https://www.douyin.com/video/7346034987541499155',
    'accept-language': 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7',
    'cookie': 'xgplayer_user_id=170133754860; store-region=cn-zj; store-region-src=uid; my_rd=2; live_use_vvc=%22false%22; bd_ticket_guard_client_web_domain=2; passport_csrf_token=b2e33dfe3c921cee4f223ccb8e01d914; passport_csrf_token_default=b2e33dfe3c921cee4f223ccb8e01d914; sso_auth_status=1d03a8d76944578fc5940b5422355710; sso_auth_status_ss=1d03a8d76944578fc5940b5422355710; _bd_ticket_crypt_doamin=2; __security_server_data_status=1; __live_version__=%221.1.1.8649%22; publish_badge_show_info=%220%2C0%2C0%2C1710408241503%22; volume_info=%7B%22isUserMute%22%3Afalse%2C%22isMute%22%3Atrue%2C%22volume%22%3A0.5%7D; pwa2=%220%7C0%7C3%7C1%22; ttwid=1%7C3BeozogP8JLVjZMENOUsxvr0no_sY9h9vMRFStdYJZQ%7C1710410938%7Cd7261e0b54d36f52f59cb7c1c7fbbe80e66824a3e8a3b619e655236d8fa8ede0; FORCE_LOGIN=%7B%22videoConsumedRemainSeconds%22%3A180%2C%22isForcePopClose%22%3A1%7D; SEARCH_RESULT_LIST_TYPE=%22single%22; download_guide=%223%2F20240315%2F0%22; FOLLOW_NUMBER_YELLOW_POINT_INFO=%22MS4wLjABAAAA1F521vQ9mfqUbwM5rzG9LxNYTcUDArro0BGgUBQS0LY%2F1710518400000%2F0%2F1710500315725%2F0%22; live_can_add_dy_2_desktop=%221%22; xgplayer_device_id=49904174790; s_v_web_id=verify_ltsk5ins_78787f8f_86ae_369c_edc5_bebb69057856; d_ticket=caa5f1fd0c3292a124266d4b4a097e9d52b7e; dy_swidth=1440; dy_sheight=900; strategyABtestKey=%221710521525.308%22; douyin.com; device_web_cpu_core=8; device_web_memory_size=8; csrf_session_id=bf86e03f4be3198d61a6c43ec9aded5b; xg_device_score=7.444370582045609; __ac_nonce=065f54d4c00e889c2894a; __ac_signature=_02B4Z6wo00f01jB8HNAAAIDBYoM8y-lbjJIwXBhAAOn4t7la1-IeklIbKLuQ2MdBwZwKZWusMUjU6b4rnl8Z.u3SFCvm4gTxt9F1YShUZAyZ5JoepQsB9mkCXSsj7rxHhb-wGg8WMKmwL13g64; stream_recommend_feed_params=%22%7B%5C%22cookie_enabled%5C%22%3Atrue%2C%5C%22screen_width%5C%22%3A1440%2C%5C%22screen_height%5C%22%3A900%2C%5C%22browser_online%5C%22%3Atrue%2C%5C%22cpu_core_num%5C%22%3A8%2C%5C%22device_memory%5C%22%3A8%2C%5C%22downlink%5C%22%3A10%2C%5C%22effective_type%5C%22%3A%5C%224g%5C%22%2C%5C%22round_trip_time%5C%22%3A100%7D%22; tt_scid=CzSUUqsvTX8u.5cE6Vro1Obfn.T71UhvSusFdKA1SMe7kxbVlVlCAj4NLi1bxGnB2c12; passport_assist_user=CkEoXqew3Rja_4iCmEDA_8vIgu2SwR8cly45FN4PQwUDPrHdrpLQoEDa6CRK9rdws0hAXcXWPzd4lRReuuUixNFIoxpKCjyKEaQZ9giz7B6NphFp36CxFuvbSk0sEW-xftDIPYI8Fb6dsgcAz6dCYcAe7DnGUjpJzVXOvV2mKwYIqscQlYrMDRiJr9ZUIAEiAQPGvVPK; n_mh=xN_A8XeKVI4q9g0W4N_WKH1hnh5m06onkItvChnN_Ao; sso_uid_tt=89260454aa0d512c9ec27cf15160c10e; sso_uid_tt_ss=89260454aa0d512c9ec27cf15160c10e; toutiao_sso_user=708f5bfec1bfd75626b183b532f3272e; toutiao_sso_user_ss=708f5bfec1bfd75626b183b532f3272e; sid_ucp_sso_v1=1.0.0-KDczZWI4YzQ5ZWQ1ZGY3YWM0Njc5ZTA3MjM2MzY0OGIyMjY4ZDI4ODUKHwiuxfCaoYzQAxDKm9WvBhjvMSAMMKPLlIEGOAZA9AcaAmxmIiA3MDhmNWJmZWMxYmZkNzU2MjZiMTgzYjUzMmYzMjcyZQ; ssid_ucp_sso_v1=1.0.0-KDczZWI4YzQ5ZWQ1ZGY3YWM0Njc5ZTA3MjM2MzY0OGIyMjY4ZDI4ODUKHwiuxfCaoYzQAxDKm9WvBhjvMSAMMKPLlIEGOAZA9AcaAmxmIiA3MDhmNWJmZWMxYmZkNzU2MjZiMTgzYjUzMmYzMjcyZQ; odin_tt=9450236f6af9ec9e2ebe921aefca8c6a962f8d9064db35b81b60155672a478801ded12f0e8a4b5cfdde7cd705ba00ffa5ed012240a3fb0cdc1d27bb72d8dbbf9; passport_auth_status=25c0fd160c0c2cb01e21e7e8790d0949%2Ce5ec2da6f6304a15768d1e650c9f296c; passport_auth_status_ss=25c0fd160c0c2cb01e21e7e8790d0949%2Ce5ec2da6f6304a15768d1e650c9f296c; uid_tt=d33e1ac38cae4b4c418b3809bca3c3c5; uid_tt_ss=d33e1ac38cae4b4c418b3809bca3c3c5; sid_tt=8dfabdf857f2693334f52141ad4ea4e6; sessionid=8dfabdf857f2693334f52141ad4ea4e6; sessionid_ss=8dfabdf857f2693334f52141ad4ea4e6; LOGIN_STATUS=1; _bd_ticket_crypt_cookie=feabe975339d6a2aa3f39fdc2555c67d; bd_ticket_guard_client_data=eyJiZC10aWNrZXQtZ3VhcmQtdmVyc2lvbiI6MiwiYmQtdGlja2V0LWd1YXJkLWl0ZXJhdGlvbi12ZXJzaW9uIjoxLCJiZC10aWNrZXQtZ3VhcmQtcmVlLXB1YmxpYy1rZXkiOiJCTktrYU8yYlB6N2hBcHZDZ2k1WEZRMndqeVJaK0RCZ0FZQUdXeHVTODkxeHNwdjNPbHVQS3QyT1NvOW1Sa280SDBSME9FdVU4OVRDRTZETEJRL3pDbDg9IiwiYmQtdGlja2V0LWd1YXJkLXdlYi12ZXJzaW9uIjoxfQ%3D%3D; sid_guard=8dfabdf857f2693334f52141ad4ea4e6%7C1710575055%7C5183998%7CWed%2C+15-May-2024+07%3A44%3A13+GMT; sid_ucp_v1=1.0.0-KDE3YmI5NTg1MmY3NWQ2NzhiY2Q5MzU4YjUzZmVmYWViYjA4NThhOTQKGwiuxfCaoYzQAxDPm9WvBhjvMSAMOAZA9AdIBBoCaGwiIDhkZmFiZGY4NTdmMjY5MzMzNGY1MjE0MWFkNGVhNGU2; ssid_ucp_v1=1.0.0-KDE3YmI5NTg1MmY3NWQ2NzhiY2Q5MzU4YjUzZmVmYWViYjA4NThhOTQKGwiuxfCaoYzQAxDPm9WvBhjvMSAMOAZA9AdIBBoCaGwiIDhkZmFiZGY4NTdmMjY5MzMzNGY1MjE0MWFkNGVhNGU2; stream_player_status_params=%22%7B%5C%22is_auto_play%5C%22%3A0%2C%5C%22is_full_screen%5C%22%3A0%2C%5C%22is_full_webscreen%5C%22%3A0%2C%5C%22is_mute%5C%22%3A1%2C%5C%22is_speed%5C%22%3A1%2C%5C%22is_visible%5C%22%3A1%7D%22; home_can_add_dy_2_desktop=%221%22; FOLLOW_LIVE_POINT_INFO=%22MS4wLjABAAAAbaRhzsoky9PctuewAwh3VSKfHJpWqpYAWat0W_ZcHh_4_leUN6Rr_DCiJFo4uPQ1%2F1710604800000%2F0%2F1710575055995%2F0%22; msToken=W8hDGgE14t14yRTK9QgtJhzR1S3Z_EWlCdqdaEhy9I15tKHb5M9ts-b46nH9LXE4Y_3p68t39t9Cj-5Kq0MXC-zalNfUlWQuLkiNehzIFKF4bjuThx8=; msToken=xVTmDFuNgJ1LW3XIKz1Dfup_mUDD51LPBPA3BpZWR-L5tPrGYniB8EvPHPpHxQRgs-imteRT0U4SGi3-xtxctXnmsptNOkP2oiEJPUjbndFVbHz7DAU=; IsDouyinActive=false; passport_fe_beating_status=false',
}

    url = f'https://www.douyin.com/aweme/v1/web/comment/list/?device_platform=webapp&aid=6383&channel=channel_pc_web&aweme_id={video_id}&cursor={cursor}&count={count}&item_type=0&whale_cut_token&cut_version=1&rcFT&pc_client_type=1&version_code=170400&version_name=17.4.0&cookie_enabled=true&screen_width=1440&screen_height=900&browser_language=en-US&browser_platform=MacIntel&browser_name=Chrome&browser_version=122.0.0'
    response = requests.get(url, headers=headers, verify=False)
    data = response.json()
    print(data)
    if data.get('comments'):

        item = {
            "video_id": video_id,
            "cursor": cursor,
            "count": count,
            "content": data,
            "created_time": datetime.datetime.now()
        }
        collection.insert_one(item)

    else:
        print("No comments found for video ID:", video_id)

    return data


if __name__ == '__main__':
    get_comments(vidio_id, cursor, count)