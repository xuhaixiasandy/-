#若数据库里已经存在该video_id，而且cursor和count都相等，
#该去重在xxxxx.py中暂时还没实现，我想封装一个函数，然后在xxxxx.py中调用
from pymongo import MongoClient
import datetime
import time

vidio_id = '7346034987541499155'
cursor = 0
count = 20
MONGO_HOST = "localhost"
MONGO_PORY = 27017
MONGO_DATABASE = "mongodb"

mg_client = MongoClient(
    host=MONGO_HOST,
    port=MONGO_PORY,
)
db = mg_client['douyin_dm']
collection = db['抖音评论_南昌']
import requests
import datetime
from pymongo import MongoClient

MONGO_HOST: str = "39.175.169.130"
MONGO_PORT = 27015
MONGO_PASSWORD: str = 'boying321'
MONGO_USERNAME: str = 'boying'
MONGO_AUTH_DB = 'admin'
MONGO_DB = 'douyin_xu'
collection= MongoClient(
    host=MONGO_HOST,
    port=MONGO_PORT,
    username=MONGO_USERNAME,
    password=MONGO_PASSWORD,
authSource=MONGO_AUTH_DB,
)[MONGO_DB]['抖音评论_南昌房子_付晓辉']
collection2= MongoClient(
    host=MONGO_HOST,
    port=MONGO_PORT,
    username=MONGO_USERNAME,
    password=MONGO_PASSWORD,
authSource=MONGO_AUTH_DB,
)[MONGO_DB]['抖音评论_列表']

#对数据库数据进行处理
#查找数据库['抖音评论_南昌房子_付晓辉']中的所有数据，获取video_id，在去跟抖音评论_列表中的video_id进行比对，如果有相同的video_id，就删除['抖音评论_列表']中的数据
def remove_duplicate(collection,collection2):
    video_ids = [item['video_id'] for item in collection.find()]
    video_ids2 = [item['video_id'] for item in collection2.find()]
    for video_id in video_ids:
        if video_id in video_ids2:
            collection2.delete_many({'video_id':video_id})
            print(f"删除{video_id}成功")
        else:
            print(f"没有找到{video_id}")

#删除数据库中的数据7249264597285326084
def remove_data(collection):
    collection2.delete_many({'video_id':'7249264597285326084'})
    print("删除7249264597285326084成功")

if __name__ == '__main__':
    remove_duplicate(collection,collection2)
    #remove_data(collection2)