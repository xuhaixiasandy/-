from xxxxxxxxxxxx import get_comments
from pymongo import MongoClient
import time
import datetime

MONGO_HOST = "localhost"
MONGO_PORT = 27017
MONGO_DATABASE = "mongodb"

MONGO_HOST: str = "39.175.169.130"
MONGO_PORT = 27015
MONGO_PASSWORD: str = 'boying321'
MONGO_USERNAME: str = 'boying'
MONGO_AUTH_DB = 'admin'
MONGO_DB = 'douyin_xu'

collection= MongoClient(
    host=MONGO_HOST,
    port=MONGO_PORT,
    username=MONGO_USERNAME,
    password=MONGO_PASSWORD,
authSource=MONGO_AUTH_DB,
)[MONGO_DB]['抖音评论_列表']




def fetch_comments(video_id, cursor, count):
    try:
        result = get_comments(video_id, cursor, count)
        return result
    except Exception as e:
        print(f"No comments found for video ID: {video_id}")
        return None


# Retrieve video_ids from the database
video_ids = [item['video_id'] for item in collection.find()]

# Iterate over the video IDs and fetch/insert comments
for video_id in video_ids:
    cursor = 0
    count = 50

    print(f"Fetching comments for video ID: {video_id}")

    while True:
        comments = fetch_comments(video_id, cursor, count)

        if comments['comments'] is None:
            print(f"No comments found for video ID: {video_id}")
            break
        else:
            print("Insertion successful")
            cursor += count
            time.sleep(10)