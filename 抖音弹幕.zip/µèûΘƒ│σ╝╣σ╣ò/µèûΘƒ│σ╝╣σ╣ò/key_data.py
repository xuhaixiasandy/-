# -*- coding: utf-8 -*-
import base64
import json
import random
import time
import webcast_proto2_pb2
def get_dou_yin_message(data):
    webcast = webcast_proto2_pb2.rwebcastimResponse()
    webcast.ParseFromString(base64.b64decode(data.get('message')))
    needs =['WebcastChatMessage', 'WebcastMemberMessage', 'WebcastGiftMessage', 'WebcastLikeMessage','WebcastFansclubMessage','WebcastUpdateFanTicketMessage','WebcastRoomUserSeqMessage','WebcastScreenChatMessage','WebcastSocialMessage']
    data = dict()
    data['message'] = list()
    for message in webcast.messages:
        if message.method not in needs:
            continue
        data['message'].append(parse_message(message))
    data['internal_ext'] = webcast.internalExt
    data['cursor'] = webcast.cursor
    data['last_rtt'] = str(random.randint(200, 400))
    return json.dumps(data,ensure_ascii=False)
def parse_message(message: webcast_proto2_pb2.mwebcastimMessage):
    def parse_time(timestamp):
        time_local = time.localtime(timestamp // 1000)
        return time.strftime("%Y-%m-%d %H:%M:%S", time_local) + '  => '

    if message.method == 'WebcastMemberMessage':  # 谁来了
        MemberMessage = webcast_proto2_pb2.rwebcastimMemberMessage()
        MemberMessage.ParseFromString(message.payload)  # 解密完成
        if len(MemberMessage.common.displayText.pieces) == 1:
            data = {
                'type': 'WebcastMemberMessage',
                'content': MemberMessage.common.displayText.defaultPattern.replace('{0:user}',
                                                                                   MemberMessage.common.displayText.pieces[
                                                                                       0].userValue.user.nickname).replace(
                    '{1:string}', ''),
                'nickname': MemberMessage.user.nickname,  # 用户名
                'sec_uid': MemberMessage.user.secUid,  # 用户sec_id
                'id': MemberMessage.user.id,  # 用户id
                'short_id': MemberMessage.user.shortId,  # 用户短id
                'gender': MemberMessage.user.gender,  # 1男2女0未知
                'unique_id': MemberMessage.user.displayId,  # 抖音id
            }
            return data
        else:
            raise Exception("入场文字")
    elif message.method == 'WebcastGiftMessage':#送礼

        GiftMessage = webcast_proto2_pb2.rwebcastimGiftMessage()
        GiftMessage.ParseFromString(message.payload)
        data = {
            'type': 'WebcastGiftMessage',
            'content': GiftMessage.common.describe.split(" ")[-1],
            'nickname': GiftMessage.user.nickname,  # 用户名
            'sec_uid': GiftMessage.user.secUid,  # 用户sec_id
            'id': GiftMessage.user.id,  # 用户id
            'short_id': GiftMessage.user.shortId,  # 用户短id
            'gender': GiftMessage.user.gender,  # 1男2女0未知
            'unique_id': GiftMessage.user.displayId,  # 抖音id
        }
        return data
    elif message.method == 'WebcastLikeMessage':#点赞

        LikeMessage = webcast_proto2_pb2.rwebcastimLikeMessage()
        LikeMessage.ParseFromString(message.payload)
        # print(
        #     parse_time(int(time.time() * 1000)) + LikeMessage.user.nickname + '为主播点赞，总赞数：' + str(LikeMessage.total))
        data = {
            'type': 'WebcastLikeMessage',
            'content': '点赞',
            'nickname': LikeMessage.user.nickname,  # 用户名
            'sec_uid': LikeMessage.user.secUid,  # 用户sec_id
            'id': LikeMessage.user.id,  # 用户id
            'short_id': LikeMessage.user.shortId,  # 用户短id
            'gender': LikeMessage.user.gender,  # 1男2女0未知
            'unique_id': LikeMessage.user.displayId,  # 抖音id
        }
        return data
    elif message.method == 'WebcastRoomUserSeqMessage':#观众前三名
        RoomUserSeqMessage = webcast_proto2_pb2.rwebcastimRoomUserSeqMessage()
        RoomUserSeqMessage.ParseFromString(message.payload)
        data_key=parse_time(int(time.time() * 1000)) + '观众前三排名：【' + ' >>> '.join(
            [i.user.nickname for i in RoomUserSeqMessage.ranks[:3]]) + '】' # 返回前10，只有前3显示名字
        data={
            'type':'WebcastRoomUserSeqMessage',
            'content':data_key}
        return data

    elif message.method == 'WebcastSunDailyRankMessage':#小时榜
        SunDailyRankMessage = webcast_proto2_pb2.rwebcastimSunDailyRankMessage()
        SunDailyRankMessage.ParseFromString(message.payload)
        # print(parse_time(
        #     SunDailyRankMessage.common.createTime) + SunDailyRankMessage.afterContent + '   ' + SunDailyRankMessage.content)  # 小时榜
        data = {
            'type': 'WebcastSunDailyRankMessage',
            'content':SunDailyRankMessage.afterContent +'|'+ SunDailyRankMessage.content}
        return data
    elif message.method == 'WebcastChatMessage':  # 评论弹幕
        ChatMessage = webcast_proto2_pb2.rwebcastimChatMessage()
        ChatMessage.ParseFromString(message.payload)
        data = {
            'type': 'WebcastChatMessage',
            'nickname': ChatMessage.user.nickname,  # 用户名
            'content': ChatMessage.content,  # 用户内容
            'sec_uid': ChatMessage.user.secUid,  # 用户sec_id
            'id': ChatMessage.user.id,  # 用户id
            'short_id': ChatMessage.user.shortId,  # 用户短id
            'gender': ChatMessage.user.gender,  # 1男2女0未知
            'unique_id': ChatMessage.user.displayId,  # 抖音id
        }
        return data
    elif message.method == 'WebcastSocialMessage':#关注主播
        SocialMessage = webcast_proto2_pb2.rwebcastimSocialMessage()
        SocialMessage.ParseFromString(message.payload)
        # print(parse_time(int(time.time() * 1000)) + SocialMessage.common.displayText.defaultPattern.replace(
        #     '{0:user}', SocialMessage.common.displayText.pieces[0].userValue.user.nickname) + '，总粉丝数：' + str(
        #     SocialMessage.followCount))
        data = {
            'type': 'WebcastSocialMessage',
            'nickname': SocialMessage.user.nickname,  # 用户名
            'content': "关注了主播",  # 用户内容
            'sec_uid': SocialMessage.user.secUid,  # 用户sec_id
            'id': SocialMessage.user.id,  # 用户id
            'short_id': SocialMessage.user.shortId,  # 用户短id
            'gender': SocialMessage.user.gender,  # 1男2女0未知
            'unique_id': SocialMessage.user.displayId,  # 抖音id
        }
        return data

    elif message.method == 'WebcastRoomMessage':#直播间欢迎语
        RoomMessage = webcast_proto2_pb2.rwebcastimRoomMessage()
        RoomMessage.ParseFromString(message.payload)
        # print(parse_time(RoomMessage.common.createTime) + RoomMessage.content)
        data = {
            'type': 'WebcastRoomMessage',
            'content': '未知type'}
        return data
    elif message.method == 'WebcastRoomIntroMessage':
        RoomIntroMessage = webcast_proto2_pb2.rwebcastimRoomIntroMessage()
        RoomIntroMessage.ParseFromString(message.payload)

        # print(parse_time(
        #     int(time.time() * 1000)) + RoomIntroMessage.user.nickname + ' [直播间简介] ' + RoomIntroMessage.intro)  # 直播间简介
        data = {
            'type': 'WebcastRoomIntroMessage',
            'content': RoomIntroMessage.intro}
        return data
    elif message.method == 'WebcastRoomNotifyMessage':
        RoomNotifyMessage = webcast_proto2_pb2.rwebcastimRoomNotifyMessage()
        RoomNotifyMessage.ParseFromString(message.payload)
        # print(RoomNotifyMessage)
        # print(RoomNotifyMessage.common.displayText.defaultPattern)
        # print(RoomNotifyMessage.common.displayText.pieces[0].stringValue)
        # print(RoomNotifyMessage.common.displayText.pieces[1].stringValue)
        # print(RoomNotifyMessage.common.displayText.pieces[2].stringValue)
        # print(RoomNotifyMessage.user.nickname)
        data = {
            'type': 'WebcastRoomNotifyMessage',
            'content': "未知type"}
        return data
    elif message.method == 'WebcastScreenChatMessage':#直播间欢迎语
        ScreenChatMessage = webcast_proto2_pb2.rwebcastimScreenChatMessage()
        ScreenChatMessage.ParseFromString(message.payload)
        # print(parse_time(
        #     int(time.time() * 1000)) + '【屏幕信息】 ' + ScreenChatMessage.user.nickname + '： ' + ScreenChatMessage.content)  # 公屏信息
        data = {
            'type': 'WebcastScreenChatMessage',
            'content': ScreenChatMessage.content}
        return data
    elif message.method == 'WebcastFansclubMessage':#加入粉丝团
        FansclubMessage = webcast_proto2_pb2.rwebcastimFansclubMessage()
        FansclubMessage.ParseFromString(message.payload)
        # print(parse_time(FansclubMessage.common.createTime) + FansclubMessage.content)  # 加入粉丝团
        data = {
            'type': 'WebcastFansclubMessage',
            'nickname': FansclubMessage.user.nickname,  # 用户名
            'content': FansclubMessage.content.split(" ")[-1].strip(),  # 用户内容
            'sec_uid': FansclubMessage.user.secUid,  # 用户sec_id
            'id': FansclubMessage.user.id,  # 用户id
            'short_id': FansclubMessage.user.shortId,  # 用户短id
            'gender': FansclubMessage.user.gender,  # 1男2女0未知
            'unique_id': FansclubMessage.user.displayId,  # 抖音id
        }

        return data

    elif message.method == 'WebcastAudioChatMessage':
        AudioChatMessage = webcast_proto2_pb2.rwebcastimAudioChatMessage()
        AudioChatMessage.ParseFromString(message.payload)
        # print(parse_time(
        #     int(time.time() * 1000)) + '【音频信息】 ' + AudioChatMessage.user.nickname + '： ' + AudioChatMessage.content)  # 音频信息
        # # audio_url = AudioChatMessage.audio_url
        data = {
            'type': 'WebcastAudioChatMessage',
            'content': '未知type'}
        return data
    elif message.method == 'WebcastUpdateFanTicketMessage':#总票数
        UpdateFanTicketMessage = webcast_proto2_pb2.rwebcastimUpdateFanTicketMessage()
        UpdateFanTicketMessage.ParseFromString(message.payload)
        # print(UpdateFanTicketMessage)
        data_key=str(UpdateFanTicketMessage).split(":")[-1].strip()
        data = {
            'type': 'WebcastUpdateFanTicketMessage',
            'content': data_key}
        return data
    elif message.method == 'WebcastControlMessage':
        ControlMessage = webcast_proto2_pb2.rwebcastimControlMessage()
        ControlMessage.ParseFromString(message.payload)
        # print(ControlMessage)
        data = {
            'type': 'WebcastControlMessage',
            'content': '未知type'}
        return data
    elif message.method == 'WebcastEmojiChatMessage':
        EmojiChatMessage = webcast_proto2_pb2.rwebcastimEmojiChatMessage()
        EmojiChatMessage.ParseFromString(message.payload)
        # print(EmojiChatMessage)
        # print(EmojiChatMessage.user.nickname)
        # print(EmojiChatMessage.default_content)
        # print(parse_time(int(time.time() * 1000)) + '【表情信息】 ' +
        #       EmojiChatMessage.emoji_content.pieces[0].imageValue.image.urlList[0])  # 音频信息
        data = {
            'type': 'WebcastEmojiChatMessage',
            'content': '未知type'}
        return data
    elif message.method == 'WebcastDoubleLikeHeartMessage':
        DoubleLikeHeartMessage = webcast_proto2_pb2.rwebcastimDoubleLikeHeartMessage()
        DoubleLikeHeartMessage.ParseFromString(message.payload)
        # print(DoubleLikeHeartMessage)
        data = {
            'type': 'WebcastDoubleLikeHeartMessage',
            'content': '未知type'}
        return data
    elif message.method == 'WebcastGiftVoteMessage':#送礼人气票
        GiftVoteMessage = webcast_proto2_pb2.rwebcastimGiftVoteMessage()
        GiftVoteMessage.ParseFromString(message.payload)
        print("人气票")
        print(GiftVoteMessage)
        data = {
            'type': 'WebcastGiftVoteMessage',
            'nickname': GiftVoteMessage.user.nickname,  # 用户名
            'content': GiftVoteMessage.content,  # 用户内容
            'sec_uid': GiftVoteMessage.user.secUid,  # 用户sec_id
            'id': GiftVoteMessage.id,  # 用户id
            'short_id': GiftVoteMessage.user.shortId,  # 用户短id
            'gender': GiftVoteMessage.user.gender,  # 1男2女0未知
            'unique_id': GiftVoteMessage.user.displayId,  # 抖音id
        }
        return data

    elif message.method == 'WebcastLinkMicGuideMessage':
        LinkMicGuideMessage = webcast_proto2_pb2.rwebcastimLinkMicGuideMessage()
        LinkMicGuideMessage.ParseFromString(message.payload)
        # print(LinkMicGuideMessage)
        data = {
            'type': 'WebcastLinkMicGuideMessage',
            'content': '未知type'}
        return data
    else:
        with open(message.method + '.base64', 'wb') as f:
            f.write(message.payload)
            '''
            https://live.douyin.com/webcast/user/?aid=6383&live_id=1&device_platform=web&language=zh-CN&target_uid=111111&sec_target_uid=MS4wLjABAAAAvOEA4the1TgVpfU5Fqb1deZnw4gfJ1oxOYMEZNIHwqU
            '''