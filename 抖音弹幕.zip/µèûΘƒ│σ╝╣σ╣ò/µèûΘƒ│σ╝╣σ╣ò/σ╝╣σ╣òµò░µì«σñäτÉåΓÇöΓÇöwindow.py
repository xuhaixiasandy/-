from websocket import WebSocketApp
import time
import re
import gzip
import requests
from loguru import logger
from douyin_pb2 import PushFrame, Response
import execjs
import webcast_proto2_pb2
from hashlib import md5
import ssl
from pymongo import MongoClient

import tkinter as tk


# Create the main window
root = tk.Tk()
root.title('弹幕提示器')

text_widget = tk.Text(root, font=('微软雅黑', 48), fg='pink', bg='black', height=500, width=500, wrap='none', spacing1=0, spacing2=0, spacing3=0)

# 使文本内容居中显示
text_widget.tag_configure("center", justify='center')

# 将文本部件添加到窗口中
text_widget.pack()





# Create a text-to-speech engine
#engine = pyttsx3.init()


# 创建一个不验证SSL证书的上下文对象
ssl_context = ssl.create_default_context()

# # 连接到WebSocket服务器（此处为示例）
# ws = create_connection("wss://example.com", sslopt={"cert_reqs": ssl.CERT_NONE})

def live_info(url):
    res = requests.get(
        url=url,
        headers={
            'authority': 'live.douyin.com',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'cache-control': 'no-cache',
            'cookie': 'device_web_cpu_core=16; device_web_memory_size=8; xgplayer_user_id=463421106069; csrf_session_id=edf738231761a5147197973003809c11; webcast_leading_last_show_time=1694172613110; webcast_leading_total_show_times=1; webcast_local_quality=sd; ttwid=1%7CCXcnzcrsWub9rrnTk6VgAeMEKNq7MZy-Wdvg1UaPYGQ%7C1701928743%7C5dc0c9b315e2dd9feca70d6145c819071b42bc5b42a47dd73af13f8de4b34869; passport_csrf_token=8acc2de7b02b210e7df0fa8ca5e61009; passport_csrf_token_default=8acc2de7b02b210e7df0fa8ca5e61009; bd_ticket_guard_client_web_domain=2; FORCE_LOGIN=%7B%22videoConsumedRemainSeconds%22%3A180%2C%22isForcePopClose%22%3A1%7D; live_use_vvc=%22false%22; odin_tt=536f43455243c02f23b3f7d5de057073417fc22a1030f314eb8463954fe7cea95b86298f7c03e9c02d497aebe02817adc0fc4cea15527fca65c95b71ed968f5e0cc09b6bf95057e36624886254075255; download_guide=%223%2F20231221%2F0%22; ttcid=3d6ce9de911a4eb1a67e2fb7d67497bf41; webcast_local_quality=sd; volume_info=%7B%22isUserMute%22%3Afalse%2C%22isMute%22%3Afalse%2C%22volume%22%3A0.5%7D; stream_recommend_feed_params=%22%7B%5C%22cookie_enabled%5C%22%3Atrue%2C%5C%22screen_width%5C%22%3A1536%2C%5C%22screen_height%5C%22%3A864%2C%5C%22browser_online%5C%22%3Atrue%2C%5C%22cpu_core_num%5C%22%3A16%2C%5C%22device_memory%5C%22%3A8%2C%5C%22downlink%5C%22%3A10%2C%5C%22effective_type%5C%22%3A%5C%224g%5C%22%2C%5C%22round_trip_time%5C%22%3A150%7D%22; SEARCH_RESULT_LIST_TYPE=%22single%22; strategyABtestKey=%221703646674.962%22; home_can_add_dy_2_desktop=%221%22; bd_ticket_guard_client_data=eyJiZC10aWNrZXQtZ3VhcmQtdmVyc2lvbiI6MiwiYmQtdGlja2V0LWd1YXJkLWl0ZXJhdGlvbi12ZXJzaW9uIjoxLCJiZC10aWNrZXQtZ3VhcmQtcmVlLXB1YmxpYy1rZXkiOiJCSDV1ODRzV0RVNUNLUStrV29pY3VwTXVIQW54TlQwVXdHcmhyYlJpUy9aL0dWSk8wbG8wWm5VM2c0bHV5WmdiR2VyVHM4clRibTV1L3V3d2VUTmtNQmc9IiwiYmQtdGlja2V0LWd1YXJkLXdlYi12ZXJzaW9uIjoxfQ%3D%3D; stream_player_status_params=%22%7B%5C%22is_auto_play%5C%22%3A1%2C%5C%22is_full_screen%5C%22%3A0%2C%5C%22is_full_webscreen%5C%22%3A0%2C%5C%22is_mute%5C%22%3A0%2C%5C%22is_speed%5C%22%3A1%2C%5C%22is_visible%5C%22%3A0%7D%22; __live_version__=%221.1.1.6573%22; __ac_nonce=0658b95de0017b6239414; __ac_signature=_02B4Z6wo00f01jLbBRgAAIDDUdHFcjMDnP4y-wGAAOlLxg4cWDe8qNUcaJmaIXqVuTl5J2.d2VPavMw3D8Q3vlgUPWe9yv1O1RLNVqMnEaKIA2qb6D41y7X3qUcxsgX7f4p.HimFS.SDlheh4a; xg_device_score=7.90435294117647; msToken=LMWbS1oDACsCIqAoJzixfCStaqDhzcqqPR0MqZLJVAD-M3Gl3_cy54vFOgkleGOu2EOTbWSM5ix65av4592yiRFX1z7iD2XVewutmL56GgGC1xsq27RNZCwpECesyQ==; tt_scid=L3aNknPQWgS3h-xdRuBNCwcAp2yCJyMhBD6sajTHIkmiS0HUGo1XJWZs0Ct7IPUY1218; pwa2=%220%7C0%7C3%7C0%22; webcast_leading_last_show_time=1703646868651; webcast_leading_total_show_times=4; live_can_add_dy_2_desktop=%221%22; msToken=regBtpnAohlBr086hglLC1nzxd6p1KQP9b_WKDmFEkjbZz43YIyM0GNcFf0ZPnFC5IipW_ble4i0bDvxicJWLHxfRFi76epsrI6YZ5Lv8MceOm-m5FiVuwSeqJCaCw==; IsDouyinActive=false',
            'pragma': 'no-cache',
            'referer': 'https://live.douyin.com/',
            'sec-ch-ua': '"Google Chrome";v="119", "Chromium";v="119", "Not?A_Brand";v="24"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
        }
        ,
        cookies={
            "__ac_nonce": "065ea75a600d107f6d0e0"  # 可以是任意值
        }
    )
    room_id = re.findall(r'\\"roomId\\":\\"(.*?)\\"', res.text)[0]
    print(room_id)
    room_title = ''
    room_user_count = ''
    # enc=f"live_id=1,aid=6383,version_code=180800,webcast_sdk_version=1.0.8,room_id={room_id},sub_room_id=,sub_channel_id=,did_rule=3,user_unique_id=,device_platform=web,device_type=,ac=,identity=audience"
    enc = f"live_id=1,aid=6383,version_code=180800,webcast_sdk_version=1.0.12,room_id={room_id},sub_room_id=,sub_channel_id=,did_rule=3,user_unique_id=7309728240302016034,device_platform=web,device_type=,ac=,identity=audience"
    sign = execjs.compile(open('sign.js', encoding='gb18030').read()).call('sign', md5(enc.encode()).hexdigest())
    wss_url = f'wss://webcast5-ws-web-lq.douyin.com/webcast/im/push/v2/?app_name=douyin_web&version_code=180800&webcast_sdk_version=1.0.12&update_version_code=1.0.12&compress=gzip&device_platform=web&cookie_enabled=true&screen_width=1536&screen_height=864&browser_language=zh-CN&browser_platform=Win32&browser_name=Mozilla&browser_version=5.0%20(Windows%20NT%2010.0;%20Win64;%20x64)%20AppleWebKit/537.36%20(KHTML,%20like%20Gecko)%20Chrome/119.0.0.0%20Safari/537.36&browser_online=true&tz_name=Asia/Shanghai&cursor=t-1703251890105_r-1_d-1_u-1_fh-7315409832168641573&internal_ext=internal_src:dim|wss_push_room_id:{room_id}|wss_push_did:7309728240302016034|dim_log_id:202312222131295DBE730567E4322E82E2|first_req_ms:1703251889982|fetch_time:1703251890105|seq:1|wss_info:0-1703251890105-0-0|wrds_kvs:WebcastActivityEmojiGroupsMessage-1703247544419620387_WebcastRoomStreamAdaptationMessage-1703251871345099618_WebcastInRoomBannerMessage-GrowthCommonBannerASubSyncKey-1703251614011692005_LotteryInfoSyncData-1703250711729232057_WebcastRoomStatsMessage-1703251888588310545_DoubleLikeSyncData-1703251618744190204_WebcastRoomRankMessage-1703251880101553898&host=https://live.douyin.com&aid=6383&live_id=1&did_rule=3&endpoint=live_pc&support_wrds=1&user_unique_id=7309728240302016034&im_path=/webcast/im/fetch/&identity=audience&need_persist_msg_count=15&room_id={room_id}&heartbeatDuration=0&signature={sign["X-Bogus"]}'
    # wss_url=f'wss://webcast5-ws-web-hl.douyin.com/webcast/im/push/v2/?app_name=douyin_web&version_code=18
    ttwid = res.cookies.get_dict()['ttwid']
    return room_id, room_title, room_user_count, wss_url, ttwid


def on_open(ws, content):
    print('on_open')


def on_message(ws, content):
    frame = PushFrame()
    frame.ParseFromString(content)
    # 对PushFrame的 payload 内容进行gzip解压
    origin_bytes = gzip.decompress(frame.payload)
    # 根据Response+gzip解压数据，生成数据对象
    response = Response()
    response.ParseFromString(origin_bytes)
    needs = ['WebcastChatMessage', 'WebcastMemberMessage', 'WebcastGiftMessage', 'WebcastLikeMessage',
             'WebcastFansclubMessage', 'WebcastUpdateFanTicketMessage', 'WebcastRoomUserSeqMessage',
             'WebcastScreenChatMessage', 'WebcastSocialMessage']
    data = dict()
    data['message'] = list()
    if response.needAck:
        s = PushFrame()
        s.payloadType = "ack"
        s.payload = response.internalExt.encode('utf-8')
        s.logId = frame.logId
        ws.send(s.SerializeToString())

    for message in response.messagesList:
        if message.method not in needs:
            continue
        data['message'].append(parse_message(message))
    #print(data['message'])
    item = {
        #'room_id': room_id,
        'data': data['message'],
        'create_time': time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    }
    # #判断一下是否有数据，有数据再插入
    # if len(data['message'])==0:
    #     print('无数据')
    # else:
    #collection.insert_one(item)
    #print('插入成功')
    #logger.info(data['message'])
    #判断一下是否有数据，有数据再插入
    if len(data['message'])==0:
        #print('无数据')
        return

    else:
        for data in data['message']:
            #根据不同的类型，进行不同的处理
            if data['type']=='WebcastMemberMessage':
                #表示有新成员加入
                #判断一下 data['gender']==1 表示男性，data['gender']==2 表示女性，data['gender']==0 表示未知，若是0则不显示
                if data['gender']==1:
                    source=f"欢迎{data['nickname']}小哥哥进入直播间"
                    print(f"欢迎{data['nickname']}小哥哥进入直播间")
                elif data['gender']==2:
                    source=f"欢迎{data['nickname']}小姐姐进入直播间"
                    print(f"欢迎{data['nickname']}小姐姐进入直播间")
                else:
                    source=f"欢迎{data['nickname']}进入直播间"
                    print(f"欢迎{data['nickname']}进入直播间")

            #留言
            elif data['type']=='WebcastChatMessage':
                source=f"{data['nickname']}留言:{data['content']}"
                print(f"{data['nickname']}留言:{data['content']}")
            elif data['type']=='WebcastGiftMessage':
                #表示有礼物赠送
                # 判断一下 data['gender']==1 表示男性，data['gender']==2 表示女性，data['gender']==0 表示未知，若是0则不显示
                if data['gender'] == 1:
                    source = f"{data['nickname']}小哥哥送了{data['content']}礼物"
                    print(f"欢迎{data['nickname']}小哥哥赠送{data['content']}")
                elif data['gender'] == 2:
                    source = f"{data['nickname']}小姐姐送了{data['content']}礼物"
                    print(f"欢迎{data['nickname']}小姐姐赠送{data['content']}")
                else:
                    source = f"{data['nickname']}送了{data['content']}礼物"
                    print(f"欢迎{data['nickname']}进入直播间{data['content']}")
            elif data['type']=='WebcastLikeMessage':
                #表示有点赞
                # 判断一下 data['gender']==1 表示男性，data['gender']==2 表示女性，data['gender']==0 表示未知，若是0则不显示
                if data['gender'] == 1:
                    source = f"{data['nickname']}小哥哥的点赞"
                    print(f"欢迎{data['nickname']}小哥哥的点赞")
                elif data['gender'] == 2:
                    source = f"{data['nickname']}小姐姐的点赞"
                    print(f"欢迎{data['nickname']}小姐姐的点赞")
                else:
                    source = f"{data['nickname']}的点赞"
                    print(f"欢迎{data['nickname']}进入直播间")
            elif data['type']=='WebcastRoomUserSeqMessage':
                #表示有用户排名
                source=data['content']
                print(data['content'])
            else:
                return
            #将以上判断的结果每一条根据最终的输出格式进行输出
            #打印的字体居中显示，高度也居中显示
            text_widget.tag_add('center', '1.0', 'end')
            text_widget.insert('end', '\n'+ '\n'+'\n'+'\n'+'\n'+source + '\n', 'center')
            text_widget.tag_add('center', '1.0', 'end')
            text_widget.see('end')
            # text_widget.insert(tk.END, source + '\n', "center")
            text_widget.tag_config("center", justify='center')
            # text_widget.insert(tk.END, f"{source}\n")
            text_widget.update()
            # 每输出一次，就删除一次
            time.sleep(3)
            text_widget.delete(1.0, tk.END)

            #engine.say(f"{data['content']}")
            #engine.runAndWait()
            time.sleep(1)
    #print(data['message'])
def on_error(ws, content):
    print("on_error")
    print(content)


def on_close(ws, content):
    print("on_close")


def parse_message(message: webcast_proto2_pb2.mwebcastimMessage):
    def parse_time(timestamp):
        time_local = time.localtime(timestamp // 1000)
        return time.strftime("%Y-%m-%d %H:%M:%S", time_local) + '  => '

    # 谁来了
    if message.method == 'WebcastMemberMessage':
        MemberMessage = webcast_proto2_pb2.rwebcastimMemberMessage()
        MemberMessage.ParseFromString(message.payload)  # 解密完成
        if len(MemberMessage.common.displayText.pieces) == 1:
            data = {
                'type': 'WebcastMemberMessage',
                'content': MemberMessage.common.displayText.defaultPattern.replace('{0:user}',
                                                                                   MemberMessage.common.displayText.pieces[
                                                                                       0].userValue.user.nickname).replace(
                    '{1:string}', ''),
                'nickname': MemberMessage.user.nickname,  # 用户名
                'sec_uid': MemberMessage.user.secUid,  # 用户sec_id
                'id': MemberMessage.user.id,  # 用户id
                'short_id': MemberMessage.user.shortId,  # 用户短id
                'gender': MemberMessage.user.gender,  # 1男2女0未知
                'unique_id': MemberMessage.user.displayId,  # 抖音id
            }
            return data
        else:
            raise Exception("入场文字")
    # 送礼
    elif message.method == 'WebcastGiftMessage':
        GiftMessage = webcast_proto2_pb2.rwebcastimGiftMessage()
        GiftMessage.ParseFromString(message.payload)
        data = {
            'type': 'WebcastGiftMessage',
            'content': GiftMessage.common.describe.split(" ")[-1],
            'nickname': GiftMessage.user.nickname,  # 用户名
            'sec_uid': GiftMessage.user.secUid,  # 用户sec_id
            'id': GiftMessage.user.id,  # 用户id
            'short_id': GiftMessage.user.shortId,  # 用户短id
            'gender': GiftMessage.user.gender,  # 1男2女0未知
            'unique_id': GiftMessage.user.displayId,  # 抖音id
        }
        return data
    # 点赞
    elif message.method == 'WebcastLikeMessage':  # 点赞

        LikeMessage = webcast_proto2_pb2.rwebcastimLikeMessage()
        LikeMessage.ParseFromString(message.payload)
        # print(
        #     parse_time(int(time.time() * 1000)) + LikeMessage.user.nickname + '为主播点赞，总赞数：' + str(LikeMessage.total))
        data = {
            'type': 'WebcastLikeMessage',
            'content': '点赞',
            'nickname': LikeMessage.user.nickname,  # 用户名
            'sec_uid': LikeMessage.user.secUid,  # 用户sec_id
            'id': LikeMessage.user.id,  # 用户id
            'short_id': LikeMessage.user.shortId,  # 用户短id
            'gender': LikeMessage.user.gender,  # 1男2女0未知
            'unique_id': LikeMessage.user.displayId,  # 抖音id
        }
        return data
    # 观众前三名# 返回前10，只有前3显示名字
    elif message.method == 'WebcastRoomUserSeqMessage':  # 观众前三名
        RoomUserSeqMessage = webcast_proto2_pb2.rwebcastimRoomUserSeqMessage()
        RoomUserSeqMessage.ParseFromString(message.payload)
        data_key =  '观众前三排名：【' + ' >>> '.join(
            [i.user.nickname for i in RoomUserSeqMessage.ranks[:3]]) + '】'  # 返回前10，只有前3显示名字
        data = {
            'type': 'WebcastRoomUserSeqMessage',
            'content': data_key}
        return data
    # 小时榜
    elif message.method == 'WebcastSunDailyRankMessage':  # 小时榜
        SunDailyRankMessage = webcast_proto2_pb2.rwebcastimSunDailyRankMessage()
        SunDailyRankMessage.ParseFromString(message.payload)
        # print(parse_time(
        #     SunDailyRankMessage.common.createTime) + SunDailyRankMessage.afterContent + '   ' + SunDailyRankMessage.content)  # 小时榜
        data = {
            'type': 'WebcastSunDailyRankMessage',
            'content': SunDailyRankMessage.afterContent + '|' + SunDailyRankMessage.content}
        return data
    # 评论弹幕
    elif message.method == 'WebcastChatMessage':  # 评论弹幕
        ChatMessage = webcast_proto2_pb2.rwebcastimChatMessage()
        ChatMessage.ParseFromString(message.payload)
        data = {
            'type': 'WebcastChatMessage',
            'nickname': ChatMessage.user.nickname,  # 用户名
            'content': ChatMessage.content,  # 用户内容
            'sec_uid': ChatMessage.user.secUid,  # 用户sec_id
            'id': ChatMessage.user.id,  # 用户id
            'short_id': ChatMessage.user.shortId,  # 用户短id
            'gender': ChatMessage.user.gender,  # 1男2女0未知
            'unique_id': ChatMessage.user.displayId,  # 抖音id
        }
        return data
    # 关注主播
    elif message.method == 'WebcastSocialMessage':  # 关注主播
        SocialMessage = webcast_proto2_pb2.rwebcastimSocialMessage()
        SocialMessage.ParseFromString(message.payload)
        # print(parse_time(int(time.time() * 1000)) + SocialMessage.common.displayText.defaultPattern.replace(
        #     '{0:user}', SocialMessage.common.displayText.pieces[0].userValue.user.nickname) + '，总粉丝数：' + str(
        #     SocialMessage.followCount))
        data = {
            'type': 'WebcastSocialMessage',
            'nickname': SocialMessage.user.nickname,  # 用户名
            'content': "关注了主播",  # 用户内容
            'sec_uid': SocialMessage.user.secUid,  # 用户sec_id
            'id': SocialMessage.user.id,  # 用户id
            'short_id': SocialMessage.user.shortId,  # 用户短id
            'gender': SocialMessage.user.gender,  # 1男2女0未知
            'unique_id': SocialMessage.user.displayId,  # 抖音id
        }
        return data
    # 直播间欢迎语
    elif message.method == 'WebcastRoomMessage':  # 直播间欢迎语
        RoomMessage = webcast_proto2_pb2.rwebcastimRoomMessage()
        RoomMessage.ParseFromString(message.payload)
        # print(parse_time(RoomMessage.common.createTime) + RoomMessage.content)
        data = {
            'type': 'WebcastRoomMessage',
            'content': '未知type'}
        return data
    elif message.method == 'WebcastRoomIntroMessage':
        RoomIntroMessage = webcast_proto2_pb2.rwebcastimRoomIntroMessage()
        RoomIntroMessage.ParseFromString(message.payload)

        # print(parse_time(
        #     int(time.time() * 1000)) + RoomIntroMessage.user.nickname + ' [直播间简介] ' + RoomIntroMessage.intro)  # 直播间简介
        data = {
            'type': 'WebcastRoomIntroMessage',
            'content': RoomIntroMessage.intro}
        return data
    elif message.method == 'WebcastRoomNotifyMessage':
        RoomNotifyMessage = webcast_proto2_pb2.rwebcastimRoomNotifyMessage()
        RoomNotifyMessage.ParseFromString(message.payload)
        # print(RoomNotifyMessage)
        # print(RoomNotifyMessage.common.displayText.defaultPattern)
        # print(RoomNotifyMessage.common.displayText.pieces[0].stringValue)
        # print(RoomNotifyMessage.common.displayText.pieces[1].stringValue)
        # print(RoomNotifyMessage.common.displayText.pieces[2].stringValue)
        # print(RoomNotifyMessage.user.nickname)
        data = {
            'type': 'WebcastRoomNotifyMessage',
            'content': "未知type"}
        return data
    elif message.method == 'WebcastScreenChatMessage':  # 直播间欢迎语
        ScreenChatMessage = webcast_proto2_pb2.rwebcastimScreenChatMessage()
        ScreenChatMessage.ParseFromString(message.payload)
        # print(parse_time(
        #     int(time.time() * 1000)) + '【屏幕信息】 ' + ScreenChatMessage.user.nickname + '： ' + ScreenChatMessage.content)  # 公屏信息
        data = {
            'type': 'WebcastScreenChatMessage',
            'content': ScreenChatMessage.content}
        return data
    # 加入粉丝团
    elif message.method == 'WebcastFansclubMessage':
        FansclubMessage = webcast_proto2_pb2.rwebcastimFansclubMessage()
        FansclubMessage.ParseFromString(message.payload)
        # print(parse_time(FansclubMessage.common.createTime) + FansclubMessage.content)  # 加入粉丝团
        data = {
            'type': 'WebcastFansclubMessage',
            'nickname': FansclubMessage.user.nickname,  # 用户名
            'content': FansclubMessage.content.split(" ")[-1].strip(),  # 用户内容
            'sec_uid': FansclubMessage.user.secUid,  # 用户sec_id
            'id': FansclubMessage.user.id,  # 用户id
            'short_id': FansclubMessage.user.shortId,  # 用户短id
            'gender': FansclubMessage.user.gender,  # 1男2女0未知
            'unique_id': FansclubMessage.user.displayId,  #抖音id
        }

        return data
    elif message.method == 'WebcastAudioChatMessage':
        AudioChatMessage = webcast_proto2_pb2.rwebcastimAudioChatMessage()
        AudioChatMessage.ParseFromString(message.payload)
        # print(parse_time(
        #     int(time.time() * 1000)) + '【音频信息】 ' + AudioChatMessage.user.nickname + '： ' + AudioChatMessage.content)  # 音频信息
        # # audio_url = AudioChatMessage.audio_url
        data = {
            'type': 'WebcastAudioChatMessage',
            'content': '未知type'}
        return data
    # 总票数
    elif message.method == 'WebcastUpdateFanTicketMessage':
        UpdateFanTicketMessage = webcast_proto2_pb2.rwebcastimUpdateFanTicketMessage()
        UpdateFanTicketMessage.ParseFromString(message.payload)
        # print(UpdateFanTicketMessage)
        data_key = str(UpdateFanTicketMessage).split(":")[-1].strip()
        data = {
            'type': 'WebcastUpdateFanTicketMessage',
            'content': data_key}
        return data
    elif message.method == 'WebcastControlMessage':
        ControlMessage = webcast_proto2_pb2.rwebcastimControlMessage()
        ControlMessage.ParseFromString(message.payload)
        # print(ControlMessage)
        data = {
            'type': 'WebcastControlMessage',
            'content': '未知type'}
        return data
    # 表情
    elif message.method == 'WebcastEmojiChatMessage':
        EmojiChatMessage = webcast_proto2_pb2.rwebcastimEmojiChatMessage()
        EmojiChatMessage.ParseFromString(message.payload)
        # print(EmojiChatMessage)
        # print(EmojiChatMessage.user.nickname)
        # print(EmojiChatMessage.default_content)
        # print(parse_time(int(time.time() * 1000)) + '【表情信息】 ' +
        #       EmojiChatMessage.emoji_content.pieces[0].imageValue.image.urlList[0])  # 音频信息
        data = {
            'type': 'WebcastEmojiChatMessage',
            'content': '未知type'}
        return data
    elif message.method == 'WebcastDoubleLikeHeartMessage':
        DoubleLikeHeartMessage = webcast_proto2_pb2.rwebcastimDoubleLikeHeartMessage()
        DoubleLikeHeartMessage.ParseFromString(message.payload)
        # print(DoubleLikeHeartMessage)
        data = {
            'type': 'WebcastDoubleLikeHeartMessage',
            'content': '未知type'}
        return data
    # 送礼人气票
    elif message.method == 'WebcastGiftVoteMessage':
        GiftVoteMessage = webcast_proto2_pb2.rwebcastimGiftVoteMessage()
        GiftVoteMessage.ParseFromString(message.payload)
        print("人气票")
        print(GiftVoteMessage)
        data = {
            'type': 'WebcastGiftVoteMessage',
            'nickname': GiftVoteMessage.user.nickname,  # 用户名
            'content': GiftVoteMessage.content,  # 用户内容
            'sec_uid': GiftVoteMessage.user.secUid,  # 用户sec_id
            'id': GiftVoteMessage.id,  # 用户id
            'short_id': GiftVoteMessage.user.shortId,  # 用户短id
            'gender': GiftVoteMessage.user.gender,  # 1男2女0未知
            'unique_id': GiftVoteMessage.user.displayId,  # 抖音id
        }
        return data
    elif message.method == 'WebcastLinkMicGuideMessage':
        LinkMicGuideMessage = webcast_proto2_pb2.rwebcastimLinkMicGuideMessage()
        LinkMicGuideMessage.ParseFromString(message.payload)
        # print(LinkMicGuideMessage)
        data = {
            'type': 'WebcastLinkMicGuideMessage',
            'content': '未知type'}
        return data
    else:
        with open(message.method + '.base64', 'wb') as f:
            f.write(message.payload)
            '''
            https://live.douyin.com/webcast/user/?aid=6383&live_id=1&device_platform=web&language=zh-CN&target_uid=111111&sec_target_uid=MS4wLjABAAAAvOEA4the1TgVpfU5Fqb1deZnw4gfJ1oxOYMEZNIHwqU
            '''


def run():
    web_url = "https://live.douyin.com/662587836504"
    room_id, room_title, room_user_count, wss_url, ttwid = live_info(web_url)

    ws = WebSocketApp(
        url=wss_url,

        header={
            'Pragma': 'no-cache',
            'Origin': 'https://live.douyin.com',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'Sec-WebSocket-Key': 'IVcHb4wVkV7TD7K/iAWSdw==',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
            'Upgrade': 'websocket',
            'Cache-Control': 'no-cache',
            'Connection': 'Upgrade',
            'Sec-WebSocket-Version': '13',
            'Sec-WebSocket-Extensions': 'permessage-deflate; client_max_window_bits',
        },

            cookie=f"ttwid={ttwid}",
            on_open=on_open,
            on_message=on_message,
            on_error=on_error,
            on_close=on_close,
            #sslopt={"cert_reqs": ssl.CERT_NONE}
        )

    ws.on_message = on_message
    ws.on_error = on_error
    ws.on_close = on_close

    ws.run_forever(sslopt={"cert_reqs": ssl.CERT_NONE})




if __name__ == '__main__':
    run()

