const getMD5 = require('md5')

function getArray1(params) {
    let tempArray = hexToArray(getMD5(params))
    let arr1 = hexToArray(getMD5(tempArray))
    return arr1
}

function getArray2() {
    let tempArray = hexToArray("d41d8cd98f00b204e9800998ecf8427e")
    let arr2 = hexToArray(getMD5(tempArray))
    return arr2
}

function getArray3(userAgent) {

    let base64Str = generateGrowthString(userAgent)
    let arr3 = hexToArray(getMD5(base64Str))
    return arr3
}

function mixChar(a, b, c) {
    return String.fromCharCode(a) + String.fromCharCode(b) + c
}

// 用来生成随机数来模拟浏览器指纹
function browserFp() {
    return Math.floor(Math.random() * Math.pow(10, 10))
}

function generationArray19(params, userAgent) {
    let arr1 = getArray1(params)
    let arr2 = getArray2()
    let arr3 = getArray3(userAgent)

    // var timestamp = 1707373702.188  // 测试的时候固定时间戳
    let timestamp = Date.now() / 1000
    let longArray = new Array(19).fill(0) // 初始化数组
    let randomNum = browserFp()
    longArray[0] = 64 // 固定值
    longArray[1] = 0.00390625  // 固定值
    longArray[2] = 1   // 固定值
    longArray[3] = 12  // 这个值不是固定， 会发生变化要么是12要么是14 可能还有其他的情况
    longArray[4] = arr1[14]
    longArray[5] = arr1[15]
    longArray[6] = arr2[14]
    longArray[7] = arr2[15]
    longArray[8] = arr3[14]
    longArray[9] = arr3[15]
    longArray[10] = timestamp >> 24 & 255
    longArray[11] = timestamp >> 16 & 255
    longArray[12] = timestamp >> 8 & 255
    longArray[13] = timestamp >> 0 & 255
    longArray[14] = randomNum >> 24 & 255   
    longArray[15] = randomNum >> 16 & 255
    longArray[16] = randomNum >> 8 & 255
    longArray[17] = randomNum >> 0 & 255
    longArray[18] = longArray.reduce(function(a, b) { return a ^ b })
    return rearrangeArray(longArray)
}

// 索引为偶数的值放前面，奇数的值放后面
function rearrangeArray(arr) {
    let evenIndexes = [];
    let oddIndexes = [];
  
    for (let i = 0; i < arr.length; i++) {
        if (i % 2 === 0) {
            evenIndexes.push(arr[i]);
        } else {
            oddIndexes.push(arr[i]);
        }
    }
  
    return evenIndexes.concat(oddIndexes);
}

function hexToArray(a) {
    var baseArryay = [null, null, null, null, null, null, null, null, null, null, 
        null, null, null, null, null, null, null, null, null, null, null, null, 
        null, null, null, null, null, null, null, null, null, null, null, null, 
        null, null, null, null, null, null, null, null, null, null, null, null, 
        null, null, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, null, null, null, null, null, 
        null, null, null, null, null, null, null, null, null, null, null, null, 
        null, null, null, null, null, null, null, null, null, null, null, null, 
        null, null, null, null, null, null, null, null, null, null, 10, 11, 12, 13, 14, 15]
    for (var b = a.length >> 1, c = b << 1, e = new Uint8Array(b), d = 0, t = 0; t < c;) {
        e[d++] = baseArryay[a.charCodeAt(t++)] << 4 | baseArryay[a.charCodeAt(t++)];
    }
    return e
}

function getUnicodeStr(a, b) {
    var c = new Uint8Array(3);
    return c[0] = a / 256, 
    c[1] = a % 256, 
    c[2] = b % 256, 
    String.fromCharCode.apply(null, c);
}

function generateGarbledString(a, b) {
    for (var c, e = [], d = 0, t = "", f = 0; f < 256; f++) {
        e[f] = f;
    }
    for (var r = 0; r < 256; r++) {
        d = (d + e[r] + a.charCodeAt(r % a.length)) % 256, 
        c = e[r], 
        e[r] = e[d], 
        e[d] = c;
    }
    var n = 0;
    d = 0;
    for (var o = 0; o < b.length; o++) {
        d = (d + e[n = (n + 1) % 256]) % 256, 
        c = e[n], 
        e[n] = e[d], 
        e[d] = c, 
        t += String.fromCharCode(b.charCodeAt(o) ^ e[(e[n] + e[d]) % 256]);
    }
    return t;
}

function generateArray37(userAgent) {
    // 固定值，不知道后面会不会变化(1, 12)
    let a = getUnicodeStr(1, 12)
    let garbledStr = generateGarbledString(a ,userAgent)
    let longNumberArray = []
    for (let i = 0; i < garbledStr.length; i += 3) {
        let num  = (garbledStr.charCodeAt(i + 0) << 16) ^ (garbledStr.charCodeAt(i + 1) << 8) ^ (garbledStr.charCodeAt(i + 2) << 0)
        longNumberArray.push(num)
    }
    return longNumberArray;
}

function generateGrowthString(userAgent) {
    let array37 = generateArray37(userAgent)
    let longGrowthString = ""
    let shotStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
    for (let i of array37) {
        let str1 = shotStr[(i & 16515072) >> 18]
        let str2 = shotStr[(i & 258048) >> 12]
        let str3 = shotStr[(i & 4032) >> 6]
        let str4 = shotStr[(i & 63) >> 0]
        longGrowthString += str1 + str2 + str3 + str4
    }
    return longGrowthString 
}

function getGarbledString(a, b, c, e, d, t, f, r, n, o, i, _, x, u, s, l, v, h, p) {
    var y = new Uint8Array(19);
    return y[0] = a, 
    y[1] = i, 
    y[2] = b, 
    y[3] = _, 
    y[4] = c, 
    y[5] = x, 
    y[6] = e, 
    y[7] = u, 
    y[8] = d, 
    y[9] = s, 
    y[10] = t, 
    y[11] = l, 
    y[12] = f, 
    y[13] = v, 
    y[14] = r, 
    y[15] = h, 
    y[16] = n, 
    y[17] = p, 
    y[18] = o, 
    String.fromCharCode.apply(null, y);
}

getXBogus = function(params, userAgent) {
    let arr19 = generationArray19(params, userAgent)
    let garbledStr1 = getGarbledString(...arr19)
    let garbledStr2 = generateGarbledString('ÿ', garbledStr1)
    let finalGarbledString = mixChar(2, 255, garbledStr2)

    let XBogus = ""
    let shotStr = "Dkdpgh4ZKsQB80/Mfvw36XI1R25-WUAlEi7NLboqYTOPuzmFjJnryx9HVGcaStCe="
    for (let i = 0; i <= 20; i += 3) {
        let charCodeAtNum0 = finalGarbledString.charCodeAt(i + 0)
        let charCodeAtNum1 = finalGarbledString.charCodeAt(i + 1)
        let charCodeAtNum2 = finalGarbledString.charCodeAt(i + 2)
        let baseNum = charCodeAtNum2 << 0 | charCodeAtNum1 << 8 | charCodeAtNum0 << 16
        let str1 = shotStr[(baseNum & 16515072) >> 18]
        let str2 = shotStr[(baseNum & 258048) >> 12]
        let str3 = shotStr[(baseNum & 4032) >> 6]
        let str4 = shotStr[(baseNum & 63) >> 0]
        XBogus += str1 + str2 + str3 + str4
    }
    return XBogus
}

// console.log(getArray1("device_platform=webapp&aid=6383&channel=channel_pc_web&publish_video_strategy_type=2&pc_client_type=1&version_code=170400&version_name=17.4.0&cookie_enabled=true&screen_width=1536&screen_height=864&browser_language=zh-CN&browser_platform=Win32&browser_name=Chrome&browser_version=121.0.0.0&browser_online=true&engine_name=Blink&engine_version=121.0.0.0&os_name=Windows&os_version=10&cpu_core_num=8&device_memory=8&platform=PC&downlink=10&effective_type=4g&round_trip_time=50&webid=7313475644641150527&msToken=fUu3WznCzEXga5y59coCm6B8FmqZoES9FcueNlSR85x4HM0r93CjP5tJGwlM2bLl46AZhmyuiM6up2YgVad4OlqFEckvd8V4V76GSctXmaOSkf9zJ24="))
// console.log(getXBogus())
// console.log(hexToArray(JSON.stringify("6a66eb92e355519fef2283780e2ee7fe")))
// console.log(JSON.stringify(UserAgetnSignature("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36")))
// console.log(generateGrowthString("Mozilla/5.0 (windows nt 10.0; win64; x64) applewebkit/537.36 (khtml, like gecko) chrome/121.0.0.0 safari/537.36"))

var pa = "device_platform=webapp&aid=6383&channel=channel_pc_web&sec_user_id=MS4wLjABAAAAWCioQOehMko99M3f3stwpTNUkXMO-kHJsgRmXMzuw8c&max_cursor=1705574621000&locate_item_id=7309445163833773364&locate_query=false&show_live_replay_strategy=1&need_time_list=0&time_list_query=0&whale_cut_token=&cut_version=1&count=18&publish_video_strategy_type=2&pc_client_type=1&version_code=170400&version_name=17.4.0&cookie_enabled=true&screen_width=1536&screen_height=864&browser_language=zh-CN&browser_platform=Win32&browser_name=Chrome&browser_version=121.0.0.0&browser_online=true&engine_name=Blink&engine_version=121.0.0.0&os_name=Windows&os_version=10&cpu_core_num=8&device_memory=8&platform=PC&downlink=1.65&effective_type=4g&round_trip_time=200&webid=7313475644641150527&msToken="
var ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"
// var res1 = generationArray19(pa, ua)
// console.log(rearrangeArray(res1))

// 生成结果和日志一样
console.log(getXBogus(pa, ua))