import requests
from pymongo import MongoClient
import datetime
import time
MONGO_HOST: str = "39.175.169.130"
MONGO_PORT = 27015
MONGO_PASSWORD: str = 'boying321'
MONGO_USERNAME: str = 'boying'
MONGO_AUTH_DB = 'admin'
MONGO_DB = 'douyin_xu'
collection2= MongoClient(
    host=MONGO_HOST,
    port=MONGO_PORT,
    username=MONGO_USERNAME,
    password=MONGO_PASSWORD,
authSource=MONGO_AUTH_DB,
)[MONGO_DB]['抖音评论_南昌房子_付晓辉']

collection= MongoClient(
    host=MONGO_HOST,
    port=MONGO_PORT,
    username=MONGO_USERNAME,
    password=MONGO_PASSWORD,
authSource=MONGO_AUTH_DB,
)[MONGO_DB]['抖音评论_列表']


def get_comments(video_id, cursor, count):

    headers = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    # 'Accept-Encoding': 'gzip, deflate, br, zstd',
    'pragma': 'no-cache',
    'cache-control': 'no-cache',
    'sec-ch-ua': '"Chromium";v="122", "Not(A:Brand";v="24", "Google Chrome";v="122"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"macOS"',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': 'https://www.douyin.com/video/7346034987541499155',
    'accept-language': 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7',
    'cookie': 'xgplayer_user_id=170133754860; store-region=cn-zj; store-region-src=uid; my_rd=2; live_use_vvc=%22false%22; bd_ticket_guard_client_web_domain=2; passport_csrf_token=b2e33dfe3c921cee4f223ccb8e01d914; passport_csrf_token_default=b2e33dfe3c921cee4f223ccb8e01d914; sso_auth_status=1d03a8d76944578fc5940b5422355710; sso_auth_status_ss=1d03a8d76944578fc5940b5422355710; _bd_ticket_crypt_doamin=2; __security_server_data_status=1; __live_version__=%221.1.1.8649%22; publish_badge_show_info=%220%2C0%2C0%2C1710408241503%22; volume_info=%7B%22isUserMute%22%3Afalse%2C%22isMute%22%3Atrue%2C%22volume%22%3A0.5%7D; pwa2=%220%7C0%7C3%7C1%22; ttwid=1%7C3BeozogP8JLVjZMENOUsxvr0no_sY9h9vMRFStdYJZQ%7C1710410938%7Cd7261e0b54d36f52f59cb7c1c7fbbe80e66824a3e8a3b619e655236d8fa8ede0; FORCE_LOGIN=%7B%22videoConsumedRemainSeconds%22%3A180%2C%22isForcePopClose%22%3A1%7D; SEARCH_RESULT_LIST_TYPE=%22single%22; download_guide=%223%2F20240315%2F0%22; FOLLOW_LIVE_POINT_INFO=%22MS4wLjABAAAA1F521vQ9mfqUbwM5rzG9LxNYTcUDArro0BGgUBQS0LY%2F1710518400000%2F0%2F0%2F1710500915724%22; FOLLOW_NUMBER_YELLOW_POINT_INFO=%22MS4wLjABAAAA1F521vQ9mfqUbwM5rzG9LxNYTcUDArro0BGgUBQS0LY%2F1710518400000%2F0%2F1710500315725%2F0%22; live_can_add_dy_2_desktop=%221%22; xgplayer_device_id=49904174790; s_v_web_id=verify_ltsk5ins_78787f8f_86ae_369c_edc5_bebb69057856; d_ticket=caa5f1fd0c3292a124266d4b4a097e9d52b7e; dy_swidth=1440; dy_sheight=900; passport_assist_user=Cj1OSTUN8tSn_dgWTzk-t7FWL1Hl3Ykr-Qv1-mMvSIaaKD2AoHwwqNmdxyR5O23TvjKh3Ev65z1aPy7PAT8zGkoKPDYzR16IZfdj9jNZvgMnJ7hglEXOmclK0AlqpttyHUc7RjgqmYOH8EPxSaC3a9ewIPEKzEfCBqaxq1V_-BDKgMwNGImv1lQgASIBA4gOf1o%3D; n_mh=_RYSHi4mPB1DwV0pzT6TShzf_tdjckT5jQLNz5fpot0; sso_uid_tt=de2531324f912da1d4f314bde2a2a620; sso_uid_tt_ss=de2531324f912da1d4f314bde2a2a620; toutiao_sso_user=6a4be6dcbcf593b5f82f59397356d43e; toutiao_sso_user_ss=6a4be6dcbcf593b5f82f59397356d43e; sid_ucp_sso_v1=1.0.0-KDA2Y2EwZDkzZDQ3ZGMzNzk5ZGFlYTVlODllYmQ3YjMzOWU0YmRlMTUKHQiVu9HMggMQp__QrwYY7zEgDDDrt5ncBTgGQPQHGgJsZiIgNmE0YmU2ZGNiY2Y1OTNiNWY4MmY1OTM5NzM1NmQ0M2U; ssid_ucp_sso_v1=1.0.0-KDA2Y2EwZDkzZDQ3ZGMzNzk5ZGFlYTVlODllYmQ3YjMzOWU0YmRlMTUKHQiVu9HMggMQp__QrwYY7zEgDDDrt5ncBTgGQPQHGgJsZiIgNmE0YmU2ZGNiY2Y1OTNiNWY4MmY1OTM5NzM1NmQ0M2U; passport_auth_status=e5ec2da6f6304a15768d1e650c9f296c%2C94b36d5b46856cad60a2fad3c4df544a; passport_auth_status_ss=e5ec2da6f6304a15768d1e650c9f296c%2C94b36d5b46856cad60a2fad3c4df544a; uid_tt=0ceb40f3542ca2ebad0ffda2f262d37a; uid_tt_ss=0ceb40f3542ca2ebad0ffda2f262d37a; sid_tt=43ef414fc1d447fd2d441f3901f0c9c2; sessionid=43ef414fc1d447fd2d441f3901f0c9c2; sessionid_ss=43ef414fc1d447fd2d441f3901f0c9c2; LOGIN_STATUS=1; _bd_ticket_crypt_cookie=2513f50f4f813d18d9612a85c343959b; sid_guard=43ef414fc1d447fd2d441f3901f0c9c2%7C1710505901%7C5183997%7CTue%2C+14-May-2024+12%3A31%3A38+GMT; sid_ucp_v1=1.0.0-KDQ1MjczYzYwNGE2ZDdlN2ZiMjE3NDAwODAzMmU3OGVmMWNhYzY0NWIKGQiVu9HMggMQrf_QrwYY7zEgDDgGQPQHSAQaAmxmIiA0M2VmNDE0ZmMxZDQ0N2ZkMmQ0NDFmMzkwMWYwYzljMg; ssid_ucp_v1=1.0.0-KDQ1MjczYzYwNGE2ZDdlN2ZiMjE3NDAwODAzMmU3OGVmMWNhYzY0NWIKGQiVu9HMggMQrf_QrwYY7zEgDDgGQPQHSAQaAmxmIiA0M2VmNDE0ZmMxZDQ0N2ZkMmQ0NDFmMzkwMWYwYzljMg; strategyABtestKey=%221710521525.308%22; douyin.com; device_web_cpu_core=8; device_web_memory_size=8; csrf_session_id=4f6005705ca32f3da4dd01283a297183; __ac_nonce=065f4dc75007a52942e8a; __ac_signature=_02B4Z6wo00f01RazGzwAAIDCREw7J6LVxk0Wkx-AACBasPnpvR3w61zlRWnpedp-gNfQfpPt82x6FjuHa6X1r.aDb7hUyZLX3iv3bJrDKWDBrOY5ZclLafzaI59vO2P44xOghNZZH.9Ik2xh32; xg_device_score=6.6995675951156715; stream_recommend_feed_params=%22%7B%5C%22cookie_enabled%5C%22%3Atrue%2C%5C%22screen_width%5C%22%3A1440%2C%5C%22screen_height%5C%22%3A900%2C%5C%22browser_online%5C%22%3Atrue%2C%5C%22cpu_core_num%5C%22%3A8%2C%5C%22device_memory%5C%22%3A8%2C%5C%22downlink%5C%22%3A10%2C%5C%22effective_type%5C%22%3A%5C%224g%5C%22%2C%5C%22round_trip_time%5C%22%3A50%7D%22; stream_player_status_params=%22%7B%5C%22is_auto_play%5C%22%3A0%2C%5C%22is_full_screen%5C%22%3A0%2C%5C%22is_full_webscreen%5C%22%3A0%2C%5C%22is_mute%5C%22%3A1%2C%5C%22is_speed%5C%22%3A1%2C%5C%22is_visible%5C%22%3A0%7D%22; bd_ticket_guard_client_data=eyJiZC10aWNrZXQtZ3VhcmQtdmVyc2lvbiI6MiwiYmQtdGlja2V0LWd1YXJkLWl0ZXJhdGlvbi12ZXJzaW9uIjoxLCJiZC10aWNrZXQtZ3VhcmQtcmVlLXB1YmxpYy1rZXkiOiJCTktrYU8yYlB6N2hBcHZDZ2k1WEZRMndqeVJaK0RCZ0FZQUdXeHVTODkxeHNwdjNPbHVQS3QyT1NvOW1Sa280SDBSME9FdVU4OVRDRTZETEJRL3pDbDg9IiwiYmQtdGlja2V0LWd1YXJkLXdlYi12ZXJzaW9uIjoxfQ%3D%3D; msToken=3a76sKVbUv7-ySj_W9r51qvaHAa09ey-MzvgP5CmfBKmZvDvFUW25T5pkkk5cX0iKusxJx6cT7sapL3gHOr7-nvr_ljH2bLIaEFH1-H9IDHVG48g2vC_7WdKxnvt; tt_scid=wYgixXLpBfrZXak9Yt63G5mTC8uIWBfY55PhQvTqI2fBR5j7LnrT1Rlvo9H9L5PAaf60; passport_fe_beating_status=false; IsDouyinActive=true; home_can_add_dy_2_desktop=%220%22; odin_tt=e844ca4ebb908a23dcd8da0a57b63f957a9c9212128fab6cb6f170bd6d5bb53060ba6b2cad1d7f70c8fd9777a21b902b; msToken=L7vNVmQrWXrS12ADG1BQjNSVWqKYHG2gHnL2LZ-t9FVxB_UAnFTl6f5yIGJ4td8gTvriuYbQBAKW9M3LGIQRlzn0TPAq4_s9VsWWM74HzaljZGFhIYfAshoeAZln',
}

    url = f'https://www.douyin.com/aweme/v1/web/comment/list/?device_platform=webapp&aid=6383&channel=channel_pc_web&aweme_id={video_id}&cursor={cursor}&count={count}&item_type=0&whale_cut_token&cut_version=1&rcFT&pc_client_type=1&version_code=170400&version_name=17.4.0&cookie_enabled=true&screen_width=1440&screen_height=900&browser_language=en-US&browser_platform=MacIntel&browser_name=Chrome&browser_version=122.0.0'

    response = requests.get(url, headers=headers, verify=False)
    time.sleep(10)
    data = response.json()
    print(data)
    # 请求完的数据查看是否comments['comments'] is None:，若是则跳出循环，去请求下一个video_id，若有数据则插入数据库，并且cursor+=count,查看是否还有数据，若没有则跳出循环，若有则继续请求，但是每次请求前都要判断是否存在该video_id, cursor, count,若存在则跳过不去请求，若不存在则去请求
    #'comments': None则跳出循环，去请求下一个video_id
    if data['comments']==None:
        print('No comments found')
        return None
    else:
        item={
            'video_id':video_id,
            'cursor':cursor,
            'count':count,
            'comments':data['comments'],
            'create_time':datetime.datetime.now()
        }
        collection.insert_one(data)
        return data

def query_comments(video_id, cursor, count):
    # 查询数据库是否存在该video_id, cursor, count,若存在则返回数据，若不存在则返回None
    data = collection.find_one({'video_id':video_id,'cursor':cursor,'count':count})
    if data:
        return data
    else:
        return None

if __name__ == '__main__':
    #获取视频id
    for item in collection2.find():
        aweme_id = item['video_id']
        print(aweme_id)
        cursor = 0
        count = 50
        while True:  # 循环请求数据
            # 查询数据库是否存在该video_id, cursor, count,若存在则跳过这个cursor的请求
            existing_data = query_comments(aweme_id, cursor, count)
            if existing_data:
                print('Data already exists')
            else:
                data = get_comments(aweme_id, cursor, count)
                # 检查是否获取到评论数据
                if data is None or data.get('comments') is None:
                    print(f"No comments found for video ID: {aweme_id}")
                    break
                else:
                    item = {
                        "video_id": aweme_id,
                        "cursor": cursor,
                        "count": count,
                        "content": data,
                        "created_time": datetime.datetime.now()
                    }
                    collection.insert_one(item)
                    print('Insertion successful')
            # 检查是否还有评论数据，没有就去请求下一个video_id，这个时候cursor又是从0开始
                if data['comments'] is None:
                    print(f"No comments found for video ID: {aweme_id}")
                    break
                else:
                    break
    time.sleep(10)
#time.sleep(10)
# ---------------------
import requests
from pymongo import MongoClient
import datetime
import time
MONGO_HOST: str = "39.175.169.130"
MONGO_PORT = 27015
MONGO_PASSWORD: str = 'boying321'
MONGO_USERNAME: str = 'boying'
MONGO_AUTH_DB = 'admin'
MONGO_DB = 'douyin_xu'
collection2= MongoClient(
    host=MONGO_HOST,
    port=MONGO_PORT,
    username=MONGO_USERNAME,
    password=MONGO_PASSWORD,
authSource=MONGO_AUTH_DB,
)[MONGO_DB]['抖音评论_南昌房子_付晓辉']

collection= MongoClient(
    host=MONGO_HOST,
    port=MONGO_PORT,
    username=MONGO_USERNAME,
    password=MONGO_PASSWORD,
authSource=MONGO_AUTH_DB,
)[MONGO_DB]['抖音评论_列表']


def get_comments(video_id, cursor, count):

    headers = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    # 'Accept-Encoding': 'gzip, deflate, br, zstd',
    'pragma': 'no-cache',
    'cache-control': 'no-cache',
    'sec-ch-ua': '"Chromium";v="122", "Not(A:Brand";v="24", "Google Chrome";v="122"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"macOS"',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': 'https://www.douyin.com/video/7346034987541499155',
    'accept-language': 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7',
    'cookie': 'xgplayer_user_id=170133754860; store-region=cn-zj; store-region-src=uid; my_rd=2; live_use_vvc=%22false%22; bd_ticket_guard_client_web_domain=2; passport_csrf_token=b2e33dfe3c921cee4f223ccb8e01d914; passport_csrf_token_default=b2e33dfe3c921cee4f223ccb8e01d914; sso_auth_status=1d03a8d76944578fc5940b5422355710; sso_auth_status_ss=1d03a8d76944578fc5940b5422355710; _bd_ticket_crypt_doamin=2; __security_server_data_status=1; __live_version__=%221.1.1.8649%22; publish_badge_show_info=%220%2C0%2C0%2C1710408241503%22; volume_info=%7B%22isUserMute%22%3Afalse%2C%22isMute%22%3Atrue%2C%22volume%22%3A0.5%7D; pwa2=%220%7C0%7C3%7C1%22; ttwid=1%7C3BeozogP8JLVjZMENOUsxvr0no_sY9h9vMRFStdYJZQ%7C1710410938%7Cd7261e0b54d36f52f59cb7c1c7fbbe80e66824a3e8a3b619e655236d8fa8ede0; FORCE_LOGIN=%7B%22videoConsumedRemainSeconds%22%3A180%2C%22isForcePopClose%22%3A1%7D; SEARCH_RESULT_LIST_TYPE=%22single%22; download_guide=%223%2F20240315%2F0%22; FOLLOW_LIVE_POINT_INFO=%22MS4wLjABAAAA1F521vQ9mfqUbwM5rzG9LxNYTcUDArro0BGgUBQS0LY%2F1710518400000%2F0%2F0%2F1710500915724%22; FOLLOW_NUMBER_YELLOW_POINT_INFO=%22MS4wLjABAAAA1F521vQ9mfqUbwM5rzG9LxNYTcUDArro0BGgUBQS0LY%2F1710518400000%2F0%2F1710500315725%2F0%22; live_can_add_dy_2_desktop=%221%22; xgplayer_device_id=49904174790; s_v_web_id=verify_ltsk5ins_78787f8f_86ae_369c_edc5_bebb69057856; d_ticket=caa5f1fd0c3292a124266d4b4a097e9d52b7e; dy_swidth=1440; dy_sheight=900; passport_assist_user=Cj1OSTUN8tSn_dgWTzk-t7FWL1Hl3Ykr-Qv1-mMvSIaaKD2AoHwwqNmdxyR5O23TvjKh3Ev65z1aPy7PAT8zGkoKPDYzR16IZfdj9jNZvgMnJ7hglEXOmclK0AlqpttyHUc7RjgqmYOH8EPxSaC3a9ewIPEKzEfCBqaxq1V_-BDKgMwNGImv1lQgASIBA4gOf1o%3D; n_mh=_RYSHi4mPB1DwV0pzT6TShzf_tdjckT5jQLNz5fpot0; sso_uid_tt=de2531324f912da1d4f314bde2a2a620; sso_uid_tt_ss=de2531324f912da1d4f314bde2a2a620; toutiao_sso_user=6a4be6dcbcf593b5f82f59397356d43e; toutiao_sso_user_ss=6a4be6dcbcf593b5f82f59397356d43e; sid_ucp_sso_v1=1.0.0-KDA2Y2EwZDkzZDQ3ZGMzNzk5ZGFlYTVlODllYmQ3YjMzOWU0YmRlMTUKHQiVu9HMggMQp__QrwYY7zEgDDDrt5ncBTgGQPQHGgJsZiIgNmE0YmU2ZGNiY2Y1OTNiNWY4MmY1OTM5NzM1NmQ0M2U; ssid_ucp_sso_v1=1.0.0-KDA2Y2EwZDkzZDQ3ZGMzNzk5ZGFlYTVlODllYmQ3YjMzOWU0YmRlMTUKHQiVu9HMggMQp__QrwYY7zEgDDDrt5ncBTgGQPQHGgJsZiIgNmE0YmU2ZGNiY2Y1OTNiNWY4MmY1OTM5NzM1NmQ0M2U; passport_auth_status=e5ec2da6f6304a15768d1e650c9f296c%2C94b36d5b46856cad60a2fad3c4df544a; passport_auth_status_ss=e5ec2da6f6304a15768d1e650c9f296c%2C94b36d5b46856cad60a2fad3c4df544a; uid_tt=0ceb40f3542ca2ebad0ffda2f262d37a; uid_tt_ss=0ceb40f3542ca2ebad0ffda2f262d37a; sid_tt=43ef414fc1d447fd2d441f3901f0c9c2; sessionid=43ef414fc1d447fd2d441f3901f0c9c2; sessionid_ss=43ef414fc1d447fd2d441f3901f0c9c2; LOGIN_STATUS=1; _bd_ticket_crypt_cookie=2513f50f4f813d18d9612a85c343959b; sid_guard=43ef414fc1d447fd2d441f3901f0c9c2%7C1710505901%7C5183997%7CTue%2C+14-May-2024+12%3A31%3A38+GMT; sid_ucp_v1=1.0.0-KDQ1MjczYzYwNGE2ZDdlN2ZiMjE3NDAwODAzMmU3OGVmMWNhYzY0NWIKGQiVu9HMggMQrf_QrwYY7zEgDDgGQPQHSAQaAmxmIiA0M2VmNDE0ZmMxZDQ0N2ZkMmQ0NDFmMzkwMWYwYzljMg; ssid_ucp_v1=1.0.0-KDQ1MjczYzYwNGE2ZDdlN2ZiMjE3NDAwODAzMmU3OGVmMWNhYzY0NWIKGQiVu9HMggMQrf_QrwYY7zEgDDgGQPQHSAQaAmxmIiA0M2VmNDE0ZmMxZDQ0N2ZkMmQ0NDFmMzkwMWYwYzljMg; strategyABtestKey=%221710521525.308%22; douyin.com; device_web_cpu_core=8; device_web_memory_size=8; csrf_session_id=4f6005705ca32f3da4dd01283a297183; __ac_nonce=065f4dc75007a52942e8a; __ac_signature=_02B4Z6wo00f01RazGzwAAIDCREw7J6LVxk0Wkx-AACBasPnpvR3w61zlRWnpedp-gNfQfpPt82x6FjuHa6X1r.aDb7hUyZLX3iv3bJrDKWDBrOY5ZclLafzaI59vO2P44xOghNZZH.9Ik2xh32; xg_device_score=6.6995675951156715; stream_recommend_feed_params=%22%7B%5C%22cookie_enabled%5C%22%3Atrue%2C%5C%22screen_width%5C%22%3A1440%2C%5C%22screen_height%5C%22%3A900%2C%5C%22browser_online%5C%22%3Atrue%2C%5C%22cpu_core_num%5C%22%3A8%2C%5C%22device_memory%5C%22%3A8%2C%5C%22downlink%5C%22%3A10%2C%5C%22effective_type%5C%22%3A%5C%224g%5C%22%2C%5C%22round_trip_time%5C%22%3A50%7D%22; stream_player_status_params=%22%7B%5C%22is_auto_play%5C%22%3A0%2C%5C%22is_full_screen%5C%22%3A0%2C%5C%22is_full_webscreen%5C%22%3A0%2C%5C%22is_mute%5C%22%3A1%2C%5C%22is_speed%5C%22%3A1%2C%5C%22is_visible%5C%22%3A0%7D%22; bd_ticket_guard_client_data=eyJiZC10aWNrZXQtZ3VhcmQtdmVyc2lvbiI6MiwiYmQtdGlja2V0LWd1YXJkLWl0ZXJhdGlvbi12ZXJzaW9uIjoxLCJiZC10aWNrZXQtZ3VhcmQtcmVlLXB1YmxpYy1rZXkiOiJCTktrYU8yYlB6N2hBcHZDZ2k1WEZRMndqeVJaK0RCZ0FZQUdXeHVTODkxeHNwdjNPbHVQS3QyT1NvOW1Sa280SDBSME9FdVU4OVRDRTZETEJRL3pDbDg9IiwiYmQtdGlja2V0LWd1YXJkLXdlYi12ZXJzaW9uIjoxfQ%3D%3D; msToken=3a76sKVbUv7-ySj_W9r51qvaHAa09ey-MzvgP5CmfBKmZvDvFUW25T5pkkk5cX0iKusxJx6cT7sapL3gHOr7-nvr_ljH2bLIaEFH1-H9IDHVG48g2vC_7WdKxnvt; tt_scid=wYgixXLpBfrZXak9Yt63G5mTC8uIWBfY55PhQvTqI2fBR5j7LnrT1Rlvo9H9L5PAaf60; passport_fe_beating_status=false; IsDouyinActive=true; home_can_add_dy_2_desktop=%220%22; odin_tt=e844ca4ebb908a23dcd8da0a57b63f957a9c9212128fab6cb6f170bd6d5bb53060ba6b2cad1d7f70c8fd9777a21b902b; msToken=L7vNVmQrWXrS12ADG1BQjNSVWqKYHG2gHnL2LZ-t9FVxB_UAnFTl6f5yIGJ4td8gTvriuYbQBAKW9M3LGIQRlzn0TPAq4_s9VsWWM74HzaljZGFhIYfAshoeAZln',
}

    url = f'https://www.douyin.com/aweme/v1/web/comment/list/?device_platform=webapp&aid=6383&channel=channel_pc_web&aweme_id={video_id}&cursor={cursor}&count={count}&item_type=0&whale_cut_token&cut_version=1&rcFT&pc_client_type=1&version_code=170400&version_name=17.4.0&cookie_enabled=true&screen_width=1440&screen_height=900&browser_language=en-US&browser_platform=MacIntel&browser_name=Chrome&browser_version=122.0.0'

    response = requests.get(url, headers=headers, verify=False)
    time.sleep(10)
    data = response.json()
    print(data)
    # 请求完的数据查看是否comments['comments'] is None:，若是则跳出循环，去请求下一个video_id，若有数据则插入数据库，并且cursor+=count,查看是否还有数据，若没有则跳出循环，若有则继续请求，但是每次请求前都要判断是否存在该video_id, cursor, count,若存在则跳过不去请求，若不存在则去请求
    #'comments': None则跳出循环，去请求下一个video_id
    if data['comments']==None:
        print("data['comments']")
        print('No comments found')
        return None
    else:
        item={
            'video_id':video_id,
            'cursor':cursor,
            'count':count,
            'comments':data['comments'],
            'create_time':datetime.datetime.now()
        }
        collection.insert_one(data)
        return data

def query_comments(video_id, cursor, count):
    # 查询数据库是否存在该video_id, cursor, count,若存在则返回数据，若不存在则返回None
    data = collection.find_one({'video_id':video_id,'cursor':cursor,'count':count})
    print(data)
    #不存在则继续，存在则跳过
    if data:
        return data
    else:
        return None
if __name__ == '__main__':
    for item in collection2.find(): #获取视频id
        aweme_id = item['video_id']
        print(aweme_id)

        cursor = 0
        count = 50
        while True: # 循环请求数据
            data = query_comments(aweme_id, cursor, count)
            if data: #查询数据库是否存在该video_id, cursor, count,若存在则跳过这个cursor的请求
                print('Data already exists')
                break #这个break只会跳出while循环，而不会跳出for循环

            #请求数据
            data = get_comments(aweme_id, cursor, count)
            if data is None or data.get('comments') is None:
                print(f"No comments found for video ID: {aweme_id}")
                break # 没有更多评论，跳出while循环，处理下一个视频

            #插入数据
            item = {
                "video_id": aweme_id,
                "cursor": cursor,
                "count": count,
                "content": data,
                "created_time": datetime.datetime.now()
            }
            collection.insert_one(item)
            print('Insertion successful')

            if data.get('has_more', 0) == 0: # 检查是否还有评论数据，没有就跳出while循环，处理下一个视频
                break

            cursor += count # 否则，cursor增加，继续获取当前视频的下一批评论

            time.sleep(10) #此处的休眠位于while循环内，每获取一批评论数据后休眠，防止频繁请求被拒绝