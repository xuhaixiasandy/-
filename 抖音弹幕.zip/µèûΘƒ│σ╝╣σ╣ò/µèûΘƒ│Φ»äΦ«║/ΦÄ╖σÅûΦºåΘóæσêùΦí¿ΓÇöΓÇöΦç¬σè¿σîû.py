from playwright.sync_api import Playwright, sync_playwright, expect
import time
import re
from pymongo import MongoClient

MONGO_HOST = "localhost"
MONGO_PORY = 27017
MONGO_DATABASE = "mongodb"

mg_client = MongoClient(
    host=MONGO_HOST,
    port=MONGO_PORY,
)
db = mg_client['douyin_dm']
collection = db['抖音评论_列表']



def run(playwright: Playwright) -> None:
    browser = playwright.firefox.launch(headless=False)
    context = browser.new_context()
    page = context.new_page()
    page.goto("https://www.douyin.com/user/MS4wLjABAAAAbkVcP-pqyB54UGvPM6fP5hNjpA8ITUzVvdMX30V5aDU")
    page.get_by_text("保存", exact=True).click()
    time.sleep(3)
    content= page.content()
    print(content)
    # # 获取博主名称。通过正则表达式匹配
    # page.get_by_text("抖音号").click()



    # 慢慢下滑，直到底部加载出所有视频，在根据元素的
    for _ in range(100):
        page.evaluate('window.scrollBy(0, window.innerHeight)')
        time.sleep(10)
        # 获取所有视频的链接
        content = page.content()
        name = page.query_selector('#douyin-right-container > div.tQ0DXWWO.DAet3nqK.userNewUi > div > div > div.o1w0tvbC.F3jJ1P9_.InbPGkRv > div.mZmVWLzR > div.ds1zWG9C > h1 > span > span > span > span > span > span').text_content()
        print(name)
        user_info_follow=page.query_selector('#douyin-right-container > div.tQ0DXWWO.DAet3nqK.userNewUi > div > div > div.o1w0tvbC.F3jJ1P9_.InbPGkRv > div.mZmVWLzR > div.lAAqxPDf > div:nth-child(1) > div.sCnO6dhe').text_content()
        print(user_info_follow)
        fans=page.query_selector('#douyin-right-container > div.tQ0DXWWO.DAet3nqK.userNewUi > div > div > div.o1w0tvbC.F3jJ1P9_.InbPGkRv > div.mZmVWLzR > div.lAAqxPDf > div:nth-child(2) > div.sCnO6dhe').text_content()
        print(fans)
        like=page.query_selector('#douyin-right-container > div.tQ0DXWWO.DAet3nqK.userNewUi > div > div > div.o1w0tvbC.F3jJ1P9_.InbPGkRv > div.mZmVWLzR > div.lAAqxPDf > div:nth-child(3) > div.sCnO6dhe').text_content()
        print(like)
        # 选择每个包含视频的ul元素
        elements = page.query_selector_all(
            '#douyin-right-container > div.tQ0DXWWO.DAet3nqK.userNewUi > div > div > div.GE_yTyVX > div > div > div.lNYhMAbF > div.XjDZcrDT > div.LPv6KBIL > ul > li')

        for element in elements:
            # 获取视频链接
            video_link = element.query_selector('a').get_attribute('href')
            print(video_link)
            #获取视频点赞数
            video_like = element.query_selector('div > a > div > span > span').text_content()
            print(video_like)
            # 获取视频标题
            video_title = element.query_selector('div > a > div > p').text_content()
            print(video_title)
            #使用正则表达式匹配数字部分
            matches = re.findall(r'/video/(\d+)', video_link)
            for match in matches:
                print(match)

                #若数据库里面以及存在,则跳过
                if collection.find_one({"video_id": match}):
                    print("已经存在")
                    continue
                else:
                    item = {
                        "video_id": match,
                        "video_link": video_link,
                        "video_like": video_like,
                        "video_title": video_title,
                        "created_time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                    }
                    collection.insert_one(item)









        # # 使用正则表达式匹配数字部分
        # matches = re.findall(r'/video/(\d+)', content)
        #
        # for match in matches:
        #     print(match)
        #     #去重若数据库中已经存在，则不插入
        #     if collection.find_one({"video_id": match}):  # 如果数据库中已经存在，则不插入
        #         print("已经存在")
        #         continue
        #     #插入数据库
        #     item = {
        #         "video_id": match,
        #         "created_time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        #     }
        #     collection.insert_one(item)
        # else:
        #     print("未找到匹配的数字部分")
        # time.sleep(10)
        #




    # ---------------------
    context.close()
    browser.close()


with sync_playwright() as playwright:
    run(playwright)
