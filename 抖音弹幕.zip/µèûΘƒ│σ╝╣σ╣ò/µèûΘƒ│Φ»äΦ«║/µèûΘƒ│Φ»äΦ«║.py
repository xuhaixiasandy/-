import requests
from pymongo import MongoClient
import time
import loguru





MONGO_HOST: str = "39.175.169.130"
MONGO_PORT = 27015
MONGO_PASSWORD: str = 'boying321'
MONGO_USERNAME: str = 'boying'
MONGO_AUTH_DB = 'admin'
MONGO_DB = 'douyin_xu'
collection= MongoClient(
    host=MONGO_HOST,
    port=MONGO_PORT,
    username=MONGO_USERNAME,
    password=MONGO_PASSWORD,
authSource=MONGO_AUTH_DB,
)[MONGO_DB]['抖音评论_南昌房子_付晓辉']
collection2= MongoClient(
    host=MONGO_HOST,
    port=MONGO_PORT,
    username=MONGO_USERNAME,
    password=MONGO_PASSWORD,
authSource=MONGO_AUTH_DB,
)[MONGO_DB]['抖音视频列表']

#获取视频id
for item in collection2.find():
    aweme_id=item['video_id']
    #aweme_id = 7328741017925061915
    cursor = 0
    count = 20
    print(aweme_id)

    import requests


    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/plain, */*',
        # 'Accept-Encoding': 'gzip, deflate, br, zstd',
        'sec-ch-ua': '"Chromium";v="122", "Not(A:Brand";v="24", "Google Chrome";v="122"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"macOS"',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'cors',
        'sec-fetch-dest': 'empty',
        'referer': 'https://www.douyin.com/video/7328741017925061915',
        'accept-language': 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7',
        'cookie': 'xgplayer_user_id=170133754860; store-region=cn-zj; store-region-src=uid; my_rd=2; live_use_vvc=%22false%22; bd_ticket_guard_client_web_domain=2; passport_csrf_token=b2e33dfe3c921cee4f223ccb8e01d914; passport_csrf_token_default=b2e33dfe3c921cee4f223ccb8e01d914; sso_auth_status=1d03a8d76944578fc5940b5422355710; sso_auth_status_ss=1d03a8d76944578fc5940b5422355710; _bd_ticket_crypt_doamin=2; __security_server_data_status=1; __live_version__=%221.1.1.8649%22; publish_badge_show_info=%220%2C0%2C0%2C1710408241503%22; volume_info=%7B%22isUserMute%22%3Afalse%2C%22isMute%22%3Atrue%2C%22volume%22%3A0.5%7D; pwa2=%220%7C0%7C3%7C1%22; ttwid=1%7C3BeozogP8JLVjZMENOUsxvr0no_sY9h9vMRFStdYJZQ%7C1710410938%7Cd7261e0b54d36f52f59cb7c1c7fbbe80e66824a3e8a3b619e655236d8fa8ede0; FORCE_LOGIN=%7B%22videoConsumedRemainSeconds%22%3A180%2C%22isForcePopClose%22%3A1%7D; strategyABtestKey=%221710485090.872%22; SEARCH_RESULT_LIST_TYPE=%22single%22; download_guide=%223%2F20240315%2F0%22; FOLLOW_LIVE_POINT_INFO=%22MS4wLjABAAAA1F521vQ9mfqUbwM5rzG9LxNYTcUDArro0BGgUBQS0LY%2F1710518400000%2F0%2F0%2F1710500915724%22; FOLLOW_NUMBER_YELLOW_POINT_INFO=%22MS4wLjABAAAA1F521vQ9mfqUbwM5rzG9LxNYTcUDArro0BGgUBQS0LY%2F1710518400000%2F0%2F1710500315725%2F0%22; live_can_add_dy_2_desktop=%221%22; xgplayer_device_id=49904174790; s_v_web_id=verify_ltsk5ins_78787f8f_86ae_369c_edc5_bebb69057856; d_ticket=caa5f1fd0c3292a124266d4b4a097e9d52b7e; douyin.com; xg_device_score=7.541509673083398; device_web_cpu_core=8; device_web_memory_size=8; dy_swidth=1440; dy_sheight=900; csrf_session_id=bf86e03f4be3198d61a6c43ec9aded5b; __ac_signature=_02B4Z6wo00f01A6s-jQAAIDDXFPaLTLGaswOjP6AAGZlawMXJqL4ThuQM1A0N2QVEpBb9mj8AqvAue1WoShtjjU1G5bgDalrZlp2YV6CkvINxPJRHdi8mVznx6vyZN0vijxM3DQS05rmPrfA7b; stream_recommend_feed_params=%22%7B%5C%22cookie_enabled%5C%22%3Atrue%2C%5C%22screen_width%5C%22%3A1440%2C%5C%22screen_height%5C%22%3A900%2C%5C%22browser_online%5C%22%3Atrue%2C%5C%22cpu_core_num%5C%22%3A8%2C%5C%22device_memory%5C%22%3A8%2C%5C%22downlink%5C%22%3A10%2C%5C%22effective_type%5C%22%3A%5C%224g%5C%22%2C%5C%22round_trip_time%5C%22%3A100%7D%22; passport_assist_user=Cj1OSTUN8tSn_dgWTzk-t7FWL1Hl3Ykr-Qv1-mMvSIaaKD2AoHwwqNmdxyR5O23TvjKh3Ev65z1aPy7PAT8zGkoKPDYzR16IZfdj9jNZvgMnJ7hglEXOmclK0AlqpttyHUc7RjgqmYOH8EPxSaC3a9ewIPEKzEfCBqaxq1V_-BDKgMwNGImv1lQgASIBA4gOf1o%3D; n_mh=_RYSHi4mPB1DwV0pzT6TShzf_tdjckT5jQLNz5fpot0; sso_uid_tt=de2531324f912da1d4f314bde2a2a620; sso_uid_tt_ss=de2531324f912da1d4f314bde2a2a620; toutiao_sso_user=6a4be6dcbcf593b5f82f59397356d43e; toutiao_sso_user_ss=6a4be6dcbcf593b5f82f59397356d43e; sid_ucp_sso_v1=1.0.0-KDA2Y2EwZDkzZDQ3ZGMzNzk5ZGFlYTVlODllYmQ3YjMzOWU0YmRlMTUKHQiVu9HMggMQp__QrwYY7zEgDDDrt5ncBTgGQPQHGgJsZiIgNmE0YmU2ZGNiY2Y1OTNiNWY4MmY1OTM5NzM1NmQ0M2U; ssid_ucp_sso_v1=1.0.0-KDA2Y2EwZDkzZDQ3ZGMzNzk5ZGFlYTVlODllYmQ3YjMzOWU0YmRlMTUKHQiVu9HMggMQp__QrwYY7zEgDDDrt5ncBTgGQPQHGgJsZiIgNmE0YmU2ZGNiY2Y1OTNiNWY4MmY1OTM5NzM1NmQ0M2U; passport_auth_status=e5ec2da6f6304a15768d1e650c9f296c%2C94b36d5b46856cad60a2fad3c4df544a; passport_auth_status_ss=e5ec2da6f6304a15768d1e650c9f296c%2C94b36d5b46856cad60a2fad3c4df544a; uid_tt=0ceb40f3542ca2ebad0ffda2f262d37a; uid_tt_ss=0ceb40f3542ca2ebad0ffda2f262d37a; sid_tt=43ef414fc1d447fd2d441f3901f0c9c2; sessionid=43ef414fc1d447fd2d441f3901f0c9c2; sessionid_ss=43ef414fc1d447fd2d441f3901f0c9c2; LOGIN_STATUS=1; _bd_ticket_crypt_cookie=2513f50f4f813d18d9612a85c343959b; stream_player_status_params=%22%7B%5C%22is_auto_play%5C%22%3A0%2C%5C%22is_full_screen%5C%22%3A0%2C%5C%22is_full_webscreen%5C%22%3A0%2C%5C%22is_mute%5C%22%3A1%2C%5C%22is_speed%5C%22%3A1%2C%5C%22is_visible%5C%22%3A1%7D%22; sid_guard=43ef414fc1d447fd2d441f3901f0c9c2%7C1710505901%7C5183997%7CTue%2C+14-May-2024+12%3A31%3A38+GMT; sid_ucp_v1=1.0.0-KDQ1MjczYzYwNGE2ZDdlN2ZiMjE3NDAwODAzMmU3OGVmMWNhYzY0NWIKGQiVu9HMggMQrf_QrwYY7zEgDDgGQPQHSAQaAmxmIiA0M2VmNDE0ZmMxZDQ0N2ZkMmQ0NDFmMzkwMWYwYzljMg; ssid_ucp_v1=1.0.0-KDQ1MjczYzYwNGE2ZDdlN2ZiMjE3NDAwODAzMmU3OGVmMWNhYzY0NWIKGQiVu9HMggMQrf_QrwYY7zEgDDgGQPQHSAQaAmxmIiA0M2VmNDE0ZmMxZDQ0N2ZkMmQ0NDFmMzkwMWYwYzljMg; tt_scid=t.xfDwuciPyDvHb36IvcTZe3PTyLefecgyvgdf6U93wEdXb385RXUVsCsg..VXwpc096; odin_tt=67dee33f1e2f94138d3f0fb14f6428e57c4f9e8729f0a0f0e3ced9f3c71684d9836f9606ff40c0486211934704b673a0; msToken=Is3UAg_r9uQAGm7SOPyzHOLDhm-qIEqQuPFtrK3nPgIjDau5eX6U11cJ9t-E4Z9ZD0sBf9uCoROH62UikY4MkO_gyV_TPuV9tIodXHgVekppS5VyaA0=; __ac_nonce=065f441f000bbbf5522cf; IsDouyinActive=true; home_can_add_dy_2_desktop=%221%22; msToken=CXUyvlwAtWEFymQ7y3vgsudmrVRIFsi8jZq1L4N5VHSY3-Kj39qkevdAMw6vvYGeXR1zIEG0RPKwOn5I-Rx5VQOE49MQVRx40o2YygXetCnZE8jJGu8=; bd_ticket_guard_client_data=eyJiZC10aWNrZXQtZ3VhcmQtdmVyc2lvbiI6MiwiYmQtdGlja2V0LWd1YXJkLWl0ZXJhdGlvbi12ZXJzaW9uIjoxLCJiZC10aWNrZXQtZ3VhcmQtcmVlLXB1YmxpYy1rZXkiOiJCTktrYU8yYlB6N2hBcHZDZ2k1WEZRMndqeVJaK0RCZ0FZQUdXeHVTODkxeHNwdjNPbHVQS3QyT1NvOW1Sa280SDBSME9FdVU4OVRDRTZETEJRL3pDbDg9IiwiYmQtdGlja2V0LWd1YXJkLXdlYi12ZXJzaW9uIjoxfQ%3D%3D; passport_fe_beating_status=true',
    }
    #while True循环cursor进行翻页，直到没有评论为止
    while True:
        cursor += 20
        response = requests.get(
            'https://www.douyin.com/aweme/v1/web/comment/list/?device_platform=webapp&aid=6383&channel=channel_pc_web&aweme_id={}&cursor={}&count={}&item_type=0&whale_cut_token&cut_version=1&rcFT&pc_client_type=1&version_code=170400&version_name=17.4.0&cookie_enabled=true&screen_width=1440&screen_height=900&browser_language=en-US&browser_platform=MacIntel&browser_name=Chrome&browser_version=122.0.0.0&browser_online=true&engine_name=Blink&engine_version=122.0.0.0&os_name=Mac OS&os_version=10.15.7&cpu_core_num=8&device_memory=8&platform=PC&downlink=10&effective_type=4g&round_trip_time=100&webid=7260332573531260456&msToken=CXUyvlwAtWEFymQ7y3vgsudmrVRIFsi8jZq1L4N5VHSY3-Kj39qkevdAMw6vvYGeXR1zIEG0RPKwOn5I-Rx5VQOE49MQVRx40o2YygXetCnZE8jJGu8=&X-Bogus=DFSzswVYtR0ANc2EtLdDdjLNKBYn'.format(
                aweme_id, cursor, count),
            headers=headers,
            verify=False
        )



        print(response.text)

        ##进行判断{"status_code":0,"comments":null, 则跳出循环
        if response.json()['comments']==None:
            break
        else:
            item = {
                'aweme_id': aweme_id,
                'cursor': cursor,
                'count': count,
                "content": response.json(),
                "created_time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            }
            collection.insert_one(item)
            print("插入成功")
            time.sleep(20)




        #print(response.text)
        #进行判断，若数据库里的aweme_id,cursor,count三个值都相等则跳过
        if collection.find_one({"aweme_id": aweme_id,"cursor":cursor,"count":count}):
            print("重复的数据,不再插入")
        else:
            response = requests.get(
                'https://www.douyin.com/aweme/v1/web/comment/list/?device_platform=webapp&aid=6383&channel=channel_pc_web&aweme_id={}&cursor={}&count={}&item_type=0&whale_cut_token&cut_version=1&rcFT&pc_client_type=1&version_code=170400&version_name=17.4.0&cookie_enabled=true&screen_width=1440&screen_height=900&browser_language=en-US&browser_platform=MacIntel&browser_name=Chrome&browser_version=122.0.0.0&browser_online=true&engine_name=Blink&engine_version=122.0.0.0&os_name=Mac OS&os_version=10.15.7&cpu_core_num=8&device_memory=8&platform=PC&downlink=10&effective_type=4g&round_trip_time=100&webid=7260332573531260456&msToken=CXUyvlwAtWEFymQ7y3vgsudmrVRIFsi8jZq1L4N5VHSY3-Kj39qkevdAMw6vvYGeXR1zIEG0RPKwOn5I-Rx5VQOE49MQVRx40o2YygXetCnZE8jJGu8=&X-Bogus=DFSzswVYtR0ANc2EtLdDdjLNKBYn'.format(
                    aweme_id, cursor, count),
                headers=headers,
                verify=False
            )
            print(response.text)

            #获取评论内容
            #进行判断{"status_code":0,"comments":null, 则跳出循环
            if response.json()['comments']==None:
                break
            else:
                item = {
                    'aweme_id': aweme_id,
                    'cursor': cursor,
                    'count': count,
                    "content": response.json(),
                    "created_time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                }
                collection.insert_one(item)
                print("插入成功")
                time.sleep(20)

        loguru.logger.info("插入成功")

