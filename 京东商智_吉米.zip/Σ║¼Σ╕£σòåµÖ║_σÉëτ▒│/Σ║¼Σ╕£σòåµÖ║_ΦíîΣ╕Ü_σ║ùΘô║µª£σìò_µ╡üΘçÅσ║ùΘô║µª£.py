"""
极米——京东商智， 流量'type', 1  热榜'type', 2
"""

import pandas as pd
import time

from datetime import timedelta, datetime
import requests
from loguru import logger
from model import get_account
import model

def crawler(username: str):

    #username = "xgimi2020"
    account = get_account(username)
    if not account:
        logger.error(f"账号 {username} 不存在")

    cookies = account['cookies']['cookie_dict']

    current_date = datetime.now().date() - timedelta(days=1)
    current_date_str = current_date.strftime("%Y-%m-%d")

    t = int(time.time() * 1000)
    timestamp = t / 1000.0  # 将时间戳除以1000，转换为秒
    dt = datetime.fromtimestamp(timestamp)
    formatted_date = dt.strftime('%Y%m%d%H%M%S%f')[:-3]  # 格式化日期字符串，去掉最后三位微秒数
    #print(formatted_date)

    categoryName_all = [
        {'categoryName': '电脑、办公 > 办公设备 > 投影机', 'thirdCategoryId': '722'},
        {'categoryName': '电脑、办公 > 办公设备 > 投影配件', 'thirdCategoryId': '5010'}
    ]
    for categoryName in categoryName_all:
        # 遍历categoryName，和thirdCategoryId
        #print(categoryName['categoryName'], categoryName['thirdCategoryId'])


        if model.col_京东商智_行业_店铺榜单_流量店铺榜.count_documents(
                {
                    'meta.data.date': f'{current_date_str}',
                    'meta.data.categoryName': categoryName['categoryName'],
                    'meta.tk_account.username': username
                }
        ):
            logger.info(f"{current_date_str}京东商智_行业_店铺榜单_流量店铺榜{categoryName['categoryName']}已经存在")
        else:

            headers = {
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'application/json, text/plain, */*',
                'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
                'x-requested-with': 'XMLHttpRequest',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"macOS"',
                'sec-fetch-site': 'same-origin',
                'sec-fetch-mode': 'cors',
                'sec-fetch-dest': 'empty',
                'referer': 'https://ppzh.jd.com/brandweb/brand/view/industry/industryTrend.html',
                'accept-language': 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7',
                # 'cookie': 'unpl=JF8EALBnNSttWkgABRoKGBMRGFRXW1QBTx5UamUHVFlcS1BQHlFJR0B7XlVdWBRKFx9uZRRUW1NIVw4eAisSEXteXVdZDEsWC2tXVgQFDQ8VXURJQlZAFDNVCV9dSRZRZjJWBFtdT1xWSAYYRRMfDlAKDlhCR1FpMjVkXlh7VAQrAhgWEUhUUFtVCHsWM2hXNWRVXElXAh0yGiIRex8AAl4LTxYKbioFV1lZSF0BHgobIhF7Xg; __jdu=1250285491; shshshfpa=718fdc5a-c0d6-2d41-8de7-b1be8d60ffde-1704273762; shshshfpx=718fdc5a-c0d6-2d41-8de7-b1be8d60ffde-1704273762; ipLoc-djd=15-1213-3038-59931; TrackID=1yGnJRQw0nm3VKUa9mYGqrILc9h_ZH8vwwus-YH1J3G2sg5XsW4LchTQP_iYIV1SYbugLhMqR7vqtMQ_BvT6epHCrji6KrSi06VyPdC1N4Uduny-N24iatFdQCOIx0l09; __jdv=251704139|baidu|-|organic|notset|1706323469874; user-key=25e5ee6a-5256-4c3d-be48-ac9a5c174eb1; thor=77A7048AB7993D1BE58356798A3FBA73B7733877B9BDC9F984D7CD510A70CD5691FC0E07F6D3F0BA8E603B8BD9E084F36041EB8BEF3487A036100992BA13C4F3D37239C9BA9C5086A664027B4E5EAD40CBF1EF83E37C42A121342D3A15E6DD7E7DD99D7F1B7122CEBCBCE078CD02D8D881599D1B4E6AFAA572FA3022D3B338432ECF128E692F63B80D5361279B3F5DCA; flash=2_6YAL2ouVZInbXGYX1CT--rb3pT_XWWKJC27DgNAdSljsAQ1-X43pm6F1t5Wly2LVcysxqBobKZYXkvjsYJLrpRJHCk8fhOVKb3Y23ugMqIM*; pinId=M1dy9PdSWJV4t4Y06rqR_Q; pin=xgimi2020; unick=xgimi2020; ceshi3.com=000; _tp=mcXVLhd%2BaO4Z%2FV3Wuj%2FV%2FA%3D%3D; _pst=xgimi2020; 3AB9D23F7A4B3C9B=X5DFY7M5JG5RUCUSTHULCZIPBQ2YDQIZESMQFK6NIE4YFXBMFYIXFAIK4ZR7PNZGQW72O5YZERZS2WIMGUVN3IV74M; 3AB9D23F7A4B3CSS=jdd03X5DFY7M5JG5RUCUSTHULCZIPBQ2YDQIZESMQFK6NIE4YFXBMFYIXFAIK4ZR7PNZGQW72O5YZERZS2WIMGUVN3IV74MAAAAMNKQDPBDAAAAAADFAC3NFIDNI5W4X; PCSYCityID=US_0_0_0; shshshfpb=BApXeRtoPV-hAeXJKMpHD9T8u2Mk2pk4EBkZmME1u9xJ1Mn4ciIO2; is_sz_old_version=false; language=zh_CN; _base_=YKH2KDFHMOZBLCUV7NSRBWQUJPBI7JIMU5R3EFJ5UDHJ5LCU7R2NILKK5UJ6GLA2RGYT464UKXAI5TPYU4VBBBWDQX6FGO2MU2LUEVZ7M5LEFBINUAULUIISX3ZJ5L2XJSPVORIFTBUVPCJUAGQKI352LNKFPOR42WQALLUAOV5DRD6AHODT4JN7KE5J2UD5T3SGLS6K5KW2RKKT6PEDIJOL37SFS6BM5IL564HHYRAQKG5JOLCCHM7QDTRPK64AYBRKHS6ICOXUFE3BZV4WHMI5FFGKWOR75LD5OF2W3Z6KPYGEG4MLTNTBAVM3RZZMDE6GTYSO6Y3RG4BJDYJ2EZ7AKIYR6GUM3EQNUX5APT5PE7RQ257CL4HQ4AV3P35IGHWZDBNTMCWTDGE2J5RKVDORFLO6WK4T2QC3WPIBE32BJCQET6I2VDJOVZOORH4KJYPI3QL5RRBVZGPEI652OAXY3EEQQIBQB5VLHO54WFCYQLRBFLQ2G3TL6CAMO3IMGF3Y2EHMEKV2XA3DS42NFFI7NQYLZ2YTHSYIE5RYMXAWOY2XWQCYK7ULZHP7KMMJPZMNUQSESGMYLUXUEL53THN4KMOLDDSPGDQJP3OWACBC23OLLAER2VOLWYFORW42MWDLXENOBHJCW; __jdc=243891652; __jda=243891652.1250285491.1704273761.1706511426.1706515134.4; __jdb=243891652.1.1250285491|4.1706515134',
            }

            params = (
                ('flag', '1'),
                ('priceZoneId', '99999999'),
                ('indicators', 'DealAmtIndex,DealProNumIndex,PVIndex,UVIndex'),
                ('firstCategoryId', ''),
                ('secondCategoryId', ''),
                ('thirdCategoryId', categoryName['thirdCategoryId']),
                ('channel', '0'),
                ('brandId', 'all'),
                ('shopType', 'all'),
                ('date', current_date_str),
                ('startDate', current_date_str),
                ('endDate', current_date_str),
                ('User-mup', f'{int(time.time() * 1000)}'),
                ('User-mnp', '964d42525ba91ccb39a2ba6047070261'),
                ('uuid', '16c3cddb002bcb686a15-18d733b88ff'),
                ('categoryName', categoryName['categoryName']),
                ('h5st',formatted_date),
            )

            response = requests.get(
                'https://ppzh.jd.com/brand/industry/shopList/downLoadProListData.ajax',
                headers=headers,
                params=params,
                cookies=cookies,
                timeout=10,
            )
            content=response.content

            try:
                # 读取EXCEL文件
                df = pd.read_excel(content)
                data = df.to_dict(orient='records')
                item = {
                    "username": username,
                    "source_data": data,
                    "created_time": datetime.now(),
                    "meta": {
                        "tk_account": account,
                        "data": dict(params),
                    }
                }
                # 保存到数据库
                model.col_京东商智_行业_店铺榜单_流量店铺榜.insert_one(item)
                logger.info(f'{username}_京东商智_行业_店铺榜单_流量店铺榜{categoryName["categoryName"]}保存成功')
                time.sleep(90)
            except Exception as e:
                logger.error(f"保存到数据库失败{e}")




if __name__ == '__main__':
    crawler('xgimi2020')
