# -*-coding:utf-8 -*-
import asyncio
import random
import cv2
import os
import time
import pyppeteer
from pyppeteer import launch
from retrying import retry
from urllib import request
import re
from  cookie添加 import update_cookie


class Async_contextor:
    # 异步上下文管理器
    def __init__(self, browser, page):
        self.__browser = browser
        self.__page = page

    async def __aenter__(self):
        return self.__page, self.__browser

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        # try:
        # await self.__page.waiFor(30)
        # try:
        await self.__page.close()
        # except Exception as e:
        #     try:
        #         await self.__page.close()
        #     except Exception as e:
        #         pass
        await self.__browser.close()


# 不但这个地方需要新增, JD_CK_Save.py文件也需要 新增登录入口 直接搜  self.TestSites
url_dict = {
    'Srm': 'https://srmn.jd.com/#/dashboard',
    'VC': 'https://vcp.jd.com/index',
    'sz': 'https://sz.jd.com/sz/view/indexs.html',
    'ppzh': 'https://ppzh.jd.com/brand/homePage/index.html',
    'JDM': 'https://around.shop.jd.com/main/vcapp#!/',
    # 'VCP': 'https://srm.jd.com/logining/doVCLogin.action',  # 京麦,供应商平台
    'VCP': 'https://srmn.jd.com/#/dashboard',  # 京麦,供应商平台
    'CW': 'https://o.jdl.com/',  # 京东云仓  https://login.jdl.com/?ReturnUrl=http://o.jdl.com/&type=1
    "KF": 'https://kf.jd.com/#/32',  # 京东客服
}


# 滑块的缺口距离识别
async def get_distance(image_png, template_png):
    img = cv2.imread(image_png, 0)
    template = cv2.imread(template_png, 0)
    res = cv2.matchTemplate(img, template, cv2.TM_CCORR_NORMED)
    value = cv2.minMaxLoc(res)[2][0]
    distance = value * 278 / 360
    return distance


def retry_if_io_error(exception):
    return isinstance(exception, pyppeteer.errors.BrowserError)


@retry(stop_max_attempt_number=5, retry_on_exception=retry_if_io_error, wait_fixed=10000, wrap_exception=True)
async def register():
    path = r'./temporary'
    os.mkdir(path) if not os.path.exists(path) else 1
    browser = await launch({
        'headless': False,
        'dumpio': True,
        'autoClose': True,
        # 'userDataDir': path,
        'args': ['--no-sandbox',  # 取消沙盒模式 沙盒模式下权限太小
                 '--disable-infobars',  # 不显示信息栏  比如 chrome正在受到自动测试软件的控制 ...
                 '--window-size=1366,768',
                 '--ignore-certificate-errors',

                 '--hide-scrollbars',
                 '--disable-bundled-ppapi-flash',
                 '--mute-audio',
                 '--no-sandbox',
                 '--disable-setuid-sandbox',
                 '--disable-gpu',

                 '--ignore-certificate-errors-spki-list',
                 '--start-maximized'
                 ],
    })
    page = await browser.newPage()
    await page.setViewport({'width': 1366, 'height': 768})
    return page, browser


async def register_2(func, *args, **kwargs):
    path = r'./temporary'
    os.mkdir(path) if not os.path.exists(path) else 1
    browser = await launch({
        'headless': False,
        'dumpio': True,
        'autoClose': True,
        # 'executablePath': r'C:\Users\Administrator\AppData\Local\Google\Chrome\Application/chrome.exe',
        # 'userDataDir': path,
        'args': [
            '--no-sandbox',  # 取消沙盒模式 沙盒模式下权限太小
            '--disable-infobars',  # 不显示信息栏  比如 chrome正在受到自动测试软件的控制 ...
            '--window-size=1366,768',
            '--disable-extensions',
            '--hide-scrollbars',
            '--disable-bundled-ppapi-flash',
            '--mute-audio',
            '--disable-setuid-sandbox',
            '--disable-gpu',
            '--ignore-certificate-errors-spki-list',
            '--start-maximized'
        ],
    })
    # context = await browser.createIncognitoBrowserContext()
    # page = await context.newPage()
    page = await browser.newPage()
    await page.setViewport({'width': 1366, 'height': 768})
    async with Async_contextor(browser, page) as (page, browser):
        result = await func(page, browser, *args, **kwargs)
    return result


async def slidingblock(page, browser, user, taget_url):
    # 模拟人工拖动滑块、失败则重试

    imagePath = "./image"
    os.mkdir(imagePath) if not os.path.exists(imagePath) else 1

    base_file_name = "xgimi2020"  # 解决因为某些店铺名字是中文的问题,做了文件名映射
    bg_image_png = f"{imagePath}/{base_file_name}_image.png"
    template_png = f"{imagePath}/{base_file_name}_template.png"

    while True:
        await page.waitFor(10000)

        login_url_s = [
            "https://b.jd.com/?entry=jdb"
        ]
        page_url = page.url
        for login_url in login_url_s:
            if page_url in login_url:
                return True, '登录成功！'

        if await page.J('#ttbar-login') or await page.J('#ent-ttbar-login'):
            print('登录成功')
            return True, '登录成功！'

        element_s = await page.xpath('//h5[contains(@class, "tip-title")]')
        verify_code = False
        if element_s:
            for index, element in enumerate(element_s):
                title_str = await (await element.getProperty("textContent")).jsonValue()
                if '为确认是您本人操作' in title_str.lower():
                    print('需要手动验证')
                    verify_code = True
                    await page.waitFor(6000)
                    break

        if verify_code:
            continue

        print("即将开始滑动滑块")
        image_src = await page.Jeval('.JDJRV-bigimg >img', 'el => el.src')
        request.urlretrieve(image_src, bg_image_png)

        template_src = await page.Jeval('.JDJRV-smallimg >img', 'el => el.src')
        request.urlretrieve(template_src, template_png)

        distance = await get_distance(bg_image_png, template_png)  # 识别滑动距离

        # 滑动
        await page.waitFor(3000)
        el = await page.J('div.JDJRV-slide-btn')
        box = await el.boundingBox()
        await page.hover('.JDJRV-slide-inner.JDJRV-slide-btn')
        await page.mouse.down()

        # await page.mouse.move(box['x'] + distance + random.uniform(30, 33), box['y'], {'steps': 30})

        await page.mouse.move(box['x'] + distance + random.uniform(30, 32), box['y'], {'steps': 30})
        await page.waitFor(random.randint(300, 700))
        # await page.mouse.move(box['x'] + distance + 29, box['y'], {'steps': 30})
        await page.mouse.move(box['x'] + distance + 12, box['y'], {'steps': 30})
        await page.mouse.up()
        await page.waitFor(5000)


async def login(page, browser, user, pw, short_web):
    taget_url = 'https://passport.jd.com/login.aspx'
    try:
        await page.goto(taget_url)
    except pyppeteer.errors.TimeoutError:
        await page.waitFor(30000 * 2)
        await page.goto(taget_url)

    while True:  # 有些情况下, 会跳转到 首页, 而不是登录页, 所以要去检测
        await page.waitFor(3000)

        page_url = page.url  # https://www.jd.com/
        if page_url == taget_url:
            break
        await page.goto(taget_url)

    await page.click('#formlogin > div.item.item-fore1')
    await page.waitFor(1000)

    # TODO 模拟人工输入用户名、密码
    await page.evaluate('document.querySelector("input[id=loginname]").value=""')
    await page.type(
        '#loginname', user,
        {'delay': random.randint(60, 121)}
    )
    await page.type(
        '#nloginpwd', pw,
        {'delay': random.randint(100, 151)}
    )
    await page.waitFor(2000)
    await page.click('div.login-btn')
    await page.waitFor(3000)

    _, desc = await slidingblock(page, browser, user, taget_url)  # 负责处理滑块

    if _ and desc == '登录成功！':
        ALLcookie = ';'.join([f"{item['name']}={item['value']}" for item in await page.cookies()])
        return await WebAllot(page, ALLcookie, short_web, browser)


async def WebAllot(page, ALLcookie, short_web, browser):
    if url_dict.__contains__(short_web):  # short_web 其实就是跳转到固定的平台
        await page.goto(url_dict[short_web])
        # TODO 留出时间操作验证码

        await page.waitFor(10000)
        cookie_ = ';'.join([f"{item['name']}={item['value']}" for item in await page.cookies()])
        return {"ckALL": ALLcookie, "ck" + short_web: cookie_}
    else:
        return {"ckALL": ALLcookie}


async def conversion(page, browser, CookieALL, module=''):
    """
    用途是取到登录了且未过期的cookie来交换特定网站的新cookie
    Returns: cookies <class 'dict'>
    """
    # page, browser = await register()

    url = 'https://passport.jd.com/login.aspx'
    await page.goto(url)
    await page.cookies()
    await page.deleteCookie()
    s = CookieALL.replace(' ', '').replace(';', '\n')
    content = '{\"' + re.sub('(^|\n)([A-Za-z0-9_\.\-]+)=', '\\1\\2\": \"', s).replace('\n', '\", \"') + '\"}'
    # print(content)
    cookie_ = demjson.decode(content)
    for key, value in cookie_.items():
        # print(f"{key}: {value}")
        await page.setCookie({"url": "https://.jd.com", "name": key, "value": value})
    await page.goto(url_dict[module])
    CookieALL = ';'.join([f"{item['name']}={item['value']}" for item in await page.cookies()])
    data = await WebAllot(page, CookieALL, module, browser)
    return data


def GetCookie(user, pwd, platform):
    try:
        data = asyncio.get_event_loop().run_until_complete(register_2(login, user, pwd, platform))
    except pyppeteer.errors.NetworkError as e:
        time.sleep(60)
        data = asyncio.get_event_loop().run_until_complete(register_2(login, user, pwd, platform))

    return data


def swapCookie(CookieALL, module):
    data = asyncio.get_event_loop().run_until_complete(register_2(conversion, CookieALL, module))
    return data


if __name__ == '__main__':
    user_ = "xgimi2020"
    pw_ = "JDZY.xgimi.com2023"
    ShortWeb = "ppzh"
    cookie = GetCookie(user_, pw_, ShortWeb)
    #只要
    cookies=cookie['ckppzh']
    print(cookie['ckppzh'])
    update_cookie(cookies)

