import subprocess
import datetime
import time
def execute_scripts(script_list):
    for script in script_list:
        subprocess.call(script)


def main():


    # 执行脚本1
    script_list = [
        ['python', '京东商智_行业_品牌榜单_流量品牌榜.py'],
        ['python', '京东商智_行业_品牌榜单_热销品牌榜.py'],
        ['python', '京东商智_行业_商品榜单_流量商品榜.py'],
        ['python', '京东商智_行业_商品榜单_热销商品榜.py'],
        ['python', '京东商智_行业_店铺榜单_热销店铺榜.py'],
        ['python', '京东商智_行业_店铺榜单_流量店铺榜.py'],
        ['python', '京东商智_行业_行业概况.py']
    ]
    execute_scripts(script_list)

    # 执行以上所有脚本
    #execute_scripts(script_list)

    # Output completion message
    print("京东商智_极米_脚本执行完成")

if __name__ == "__main__":
    main()