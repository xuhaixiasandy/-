import hashlib
import http.cookies
from model import get_account
import requests
import json



def convert_dict_to_cookie_string(cookies):
    cookie_list = ["{}={}".format(k, v) for k, v in cookies.items()]
    cookie_string = "; ".join(cookie_list)
    return cookie_string


def convert_cookie_string_to_dict(cookie_string):
    cookie = http.cookies.SimpleCookie()
    cookie.load(cookie_string)

    cookie_dict = {}
    for key in cookie.keys():
        cookie_dict[key] = cookie[key].value

    return cookie_dict


def convert_cookie_list_to_dict(cookie_list):
    cookie_dict = dict()
    for cookie in cookie_list:
        cookie_dict[cookie['name']] = cookie['value']
    return cookie_dict


def convert_cookies(cookie_list):
    cookie_dict = convert_cookie_list_to_dict(cookie_list)
    cookie_str = convert_dict_to_cookie_string(cookie_dict)
    output = {
        "cookie_dict": cookie_dict,
        "cookie_str": cookie_str
    }
    return output


# 如果是周一，采集上一周数据
import datetime
import hashlib
import subprocess
import time
import socket
from pypinyin import lazy_pinyin

import arrow

from loguru import logger


def before_week():
    """
    如果当前日期是周一, 获取上周 周一和周日日期
    """
    current_time = arrow.now()
    weekday = current_time.isoweekday()
    sunday = -weekday
    monyday = -(weekday + 6)
    # 上周日
    stop_date = current_time.shift(days=sunday).date()
    # 上周一
    start_date = current_time.shift(days=monyday).date()
    return {"start_date": start_date, "stop_date": stop_date}


def before_week_date_range():
    week = before_week()
    if week:
        date_range = f'{week["start_date"]}|{week["stop_date"]}'
        return date_range


def before_day():
    """
    获取上一天的日期
    """
    day = arrow.now().shift(days=-2).date().strftime("%Y-%m-%d")
    return day


def before_day_date_range():
    day = before_day()
    date_range = f'{day}|{day}'
    return date_range




def before_month():
    """
    如果当前日期是1号, 获取上一月开始和结束日期
    """
    current_time = arrow.now()
    if current_time.day == 1:
        pass
    # 获取上个月第一天
    start_date = current_time.shift(months=-1).replace(day=1).strftime("%Y-%m-%d")
    # 获取上个月最后一天
    stop_date = current_time.replace(day=1).shift(days=-1).strftime("%Y-%m-%d")
    return {"start_date": start_date, "stop_date": stop_date}


def before_month_date_range():
    month = before_month()
    if month:
        date_range = f'{month["start_date"]}|{month["stop_date"]}'
        return date_range


def work_sleep(min_time, max_time, sleep=5):
    arw = arrow.now()
    while arw.replace(**max_time) >= arw >= arw.replace(**min_time):
        arw = arrow.now()
        logger.info(f"休眠时间段: {min_time} - {max_time}")
        time.sleep(sleep)


# 生成当前时间
current_datetime = lambda: datetime.datetime.now()

# 生成当前时间 str格式
current_datetime_str = lambda: datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# 根据字符串转换日期, 字符串格式示例: 2020-2-2
str_to_date = lambda x: datetime.datetime.strptime(x, '%Y-%m-%d')


# 字符串转换日期时间, 字符串格式示例: 2020-02-02 00:00:00
def str_to_datetime(x): return datetime.datetime.strptime(x, '%Y-%m-%d %H:%M:%S')


# datetiem转换字符串, 字符串格式示例：xxxx-xx-xx xx:xx:xx
datetime_to_str = lambda x: datetime.datetime.strftime(x, "%Y-%m-%d %H:%M:%S")

# datetime转换date字符串
datetime_to_date_str = lambda x: datetime.datetime.strftime(x, "%Y-%m-%d")

# 时间戳转换datetiem, 精确到毫秒
timestamp_to_datetime = lambda x: datetime.datetime.fromtimestamp(x / 1000)

# 时间戳转换日期字符串, 格式为: xxxx-xx-xx, 示例: 2020-10-25
timestamp_to_datestr = lambda x: datetime.datetime.strftime(timestamp_to_datetime(x), "%Y-%m-%d")


def timestamp_to_date(x): return datetime.datetime.strptime(timestamp_to_datestr(x), "%Y-%m-%d")


def current_date():
    """
    生成当前日期
    :return:
    """
    today = datetime.datetime.today()
    x = f"{today.year}-{today.month}-{today.day}"
    return str_to_date(x)


def current_date_str():
    """
    生成当前日期，格式为str类型
    :return:
    """
    today = datetime.datetime.today()
    day = str(today.day)
    if len(str(today.day)) == 1:
        day = "0%s" % day
    return f"{today.year}-{today.month}-{day}"


def to_date_range(start):
    """
    date_range参数列表
    用于修复数据使用, 传入开始时间， 结束时间由当前日期-2
    """
    date = arrow.now().shift(days=-2).date().__str__()
    rng = pd.date_range(start, end=date, freq='D')
    rng = rng.sort_values(ascending=False)
    rng = rng.astype("str")
    return [f"{i}|{i}" for i in rng.tolist()]

import datetime
import time
import hashlib
from hashlib import sha256
import hmac


class GenerateEncryptParams:
    def __init__(self):
        pass

    def get_key(self, date):
        """
        生成hmac256 盐值
        """
        str_ = f'tk03wc95a1c9d18nRYzC脱敏VWv5BmG2jYiq脱敏PWLit66JWj4ltExEI2b-wkXMyCLrv2b脱敏hvcMKYq脱敏脱敏4k9_yZl58380087754683脱敏{date}fb5dfpJxfS7yU脱敏脱敏'
        md5 = hashlib.md5(str_.encode())
        key = md5.hexdigest()
        return key

    def get_sign(self, data, key):
        key = key.encode('utf-8')
        message = data.encode('utf-8')
        sign = hmac.new(key, message, digestmod=sha256).hexdigest()
        return sign

    def get_encrypt_body(self, body,t):
        """
        加密params信息
        """
        sha256_ = hashlib.sha256(body.encode())
        encrypt_body = sha256_.hexdigest()
        data = f'appid:pc-item-soa&body:{encrypt_body}&client:pc&clientVersion:1.0.0&functionId:pc_detailpage_wareBusiness&t:{t}'
        return data

    def get_encrypt_info(self, body):
        t = int(time.time() * 1000)
        timestamp = t / 1000.0  # 将时间戳除以1000，转换为秒
        dt = datetime.datetime.fromtimestamp(timestamp)
        formatted_date = dt.strftime('%Y%m%d%H%M%S%f')[:-3]  # 格式化日期字符串，去掉最后三位微秒数
        key = self.get_key(formatted_date)
        data = self.get_encrypt_body(body,t)
        h5st = self.get_sign(data, key)
        print(h5st)
        return t, formatted_date, h5st






if __name__ == '__main__':
    from pprint import pprint

    cookie_str = "t=d8c7821291cc2e65eedcd1fcdeceb88f; arms_uid=cbe0863f-7aac-430a-894b-973c4955a137; ali_apache_id=33.62.30.202.1679639110563.389903.3; cookie2=1b5cc382e00b3b9314a8b4990763d01d; _tb_token_=337e34e334375; _samesite_flag_=true; sgcookie=E100kK6ii3cbATH0Pntq6Wvt9moi3h1GcDMN1kCBf0B4gwIEwbiJf3h2vrViWuOana45ZFYHs5lgx5ioGH64daxXYCq%2FO0bttQZ8xdYXgNMX%2BoA%3D; unb=2215646694985; sn=%E5%BD%A9%E6%A3%A0%E6%97%97%E8%88%B0%E5%BA%97%3A%E6%92%AD%E9%9F%B3%E6%9C%8D%E5%8A%A1%E5%95%86; uc1=cookie14=Uoe8jglRaByMMw%3D%3D&cookie21=UtASsssmfufd; csg=1d56598c; cancelledSubSites=empty; skt=17d10d22b4040a37; _cc_=W5iHLLyFfA%3D%3D; v=0; cna=bgWgHNTlegkCAXPCvdDuzrl2; XSRF-TOKEN=a509f584-604e-4bbd-9012-4adc6a5ce5c4; _m_h5_tk=7e79be9a99804c719f509c317d8fb7fb_1684137180805; _m_h5_tk_enc=266821e14e2c791243ff9cb539a54a30; tfstk=czDdBKiF4FYhfT8uQJdG4Xcab7dda6885Malevhrkr4hbOXRFscqnxhQQBZ7uyKO.; l=fBjRJkcPNN1HXkEvXO5a-urza77teIdfhkPzaNbMiIEGa1oFUF8HwNC_csYy0dtfgT5jaeKPZRBG4dHB504LRxNHFMR2kUJddnp6SeM3N7AN.; isg=BOLiRMtP8lwq3O54AKtewI_yM2hEM-ZNYuii5Cx6uNUS_4R5FcFUXak5L7sDdF7l/O0bttQZ8xdYXgNMX+oA=; unb=2215646694985; sn=彩棠旗舰店:播音服务商; uc1=cookie14=Uoe8jglRaByMMw==&cookie21=UtASsssmfufd; csg=1d56598c; cancelledSubSites=empty; skt=17d10d22b4040a37; _cc_=W5iHLLyFfA==; v=0; cna=bgWgHNTlegkCAXPCvdDuzrl2; XSRF-TOKEN=a509f584-604e-4bbd-9012-4adc6a5ce5c4; _m_h5_tk=7e79be9a99804c719f509c317d8fb7fb_1684137180805; _m_h5_tk_enc=266821e14e2c791243ff9cb539a54a30; tfstk=czDdBKiF4FYhfT8uQJdG4Xcab7dda6885Malevhrkr4hbOXRFscqnxhQQBZ7uyKO.; l=fBjRJkcPNN1HXkEvXO5a-urza77teIdfhkPzaNbMiIEGa1oFUF8HwNC_csYy0dtfgT5jaeKPZRBG4dHB504LRxNHFMR2kUJddnp6SeM3N7AN.; isg=BOLiRMtP8lwq3O54AKtewI_yM2hEM-ZNYuii5Cx6uNUS_4R5FcFUXak5L7sDdF7l"
    pprint(convert_cookie_string_to_dict(cookie_str))




