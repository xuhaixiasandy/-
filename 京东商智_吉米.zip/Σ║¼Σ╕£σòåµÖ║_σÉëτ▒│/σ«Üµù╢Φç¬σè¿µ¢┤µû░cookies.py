import schedule
import time
import subprocess

# 执行脚本列表
script_list = [
    ['/opt/homebrew/anaconda3/bin/python', '/Users/xuhaixia/Desktop/工作文件/京东商智_吉米/更新cookis.py'],
]


def run_script():
    print("I'm working...")
    # 依次执行脚本列表中的脚本
    for script in script_list:
        subprocess.run(script)


def wait_message():
    print("等待任务执行...设置每天早上9:50点执行任务")


# 设置每天早上9:50点执行任务
schedule.every().day.at("09:50").do(run_script)

while True:
    schedule.run_pending()
    time.sleep(60)  # 为了避免CPU负载过重，可以将等待时间设置为60秒
