from pymongo import MongoClient

from config import settings

mg_client = MongoClient(
    f'mongodb://{settings.MONGO_USERNAME}:{settings.MONGO_PASSWORD}@{settings.MONGO_HOST}:{settings.MONGO_PORY}/?authSource=admin'
)
# mg_client.authenticate(settings.MONGO_USERNAME, settings.MONGO_PASSWORD , mechanism='SCRAM-SHA-1')
db_jdsz_jm = mg_client['jdsz_jm']

col_tk_account = db_jdsz_jm['tk_account']
col_京东商智_行业_行业概况=db_jdsz_jm['京东商智_行业_行业概况']
col_京东商智_行业_品牌榜单_热销品牌榜=db_jdsz_jm['京东商智_行业_品牌榜单_热销品牌榜']
col_京东商智_行业_品牌榜单_流量品牌榜=db_jdsz_jm['京东商智_行业_品牌榜单_流量品牌榜']
col_京东商智_行业_商品榜单_热销商品榜=db_jdsz_jm['京东商智_行业_商品榜单_热销商品榜']
col_京东商智_行业_商品榜单_流量商品榜=db_jdsz_jm['京东商智_行业_商品榜单_流量商品榜']
col_京东商智_行业_店铺榜单_热销店铺榜=db_jdsz_jm['京东商智_行业_店铺榜单_热销店铺榜']
col_京东商智_行业_店铺榜单_流量店铺榜=db_jdsz_jm['京东商智_行业_店铺榜单_流量店铺榜']




def get_user_info():
    """拿到所有胡用户信息"""
    username_all = col_tk_account.find()
    return username_all


def get_username():
    """拿到所有用户名"""
    for user in get_user_info():
        yield user['username']



def get_account(username):
    # 0， 未登录， 1，已登录， 2，不可用
    account = col_tk_account.find_one(
        {
            "username": username,
            "status": 1
        },
        {
            "_id": 0,
            "username": 1,
            "cookies": 1
        }
    )
    return account


def save_cookie(cookie_dict):
    col_tk_account.insert_one(cookie_dict)



if __name__ == "__main__":
    pass

    # get_username()