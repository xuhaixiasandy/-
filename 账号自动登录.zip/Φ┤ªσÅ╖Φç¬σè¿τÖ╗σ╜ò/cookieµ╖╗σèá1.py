import fire
from loguru import logger

from utils import convert_dict_to_cookie_string, convert_cookie_string_to_dict
from model import col_tk_account
from playwright.sync_api import Playwright, sync_playwright, expect
import json
import time
from pymongo import MongoClient

def login_and_get_cookies(playwright: Playwright, username: str, password: str) -> str:
    browser = playwright.firefox.launch(headless=False)
    context = browser.new_context()
    page = context.new_page()
    page.goto("https://sycm.taobao.com/custom/login.htm?_target=http://sycm.taobao.com/")
    page.frame_locator("iframe").get_by_placeholder("账号名/邮箱/手机号").click()
    page.frame_locator("iframe").get_by_placeholder("账号名/邮箱/手机号").fill(username)
    page.frame_locator("iframe").get_by_placeholder("请输入登录密码").click()
    page.frame_locator("iframe").get_by_placeholder("请输入登录密码").fill(password)
    page.frame_locator("iframe").get_by_role("button", name="登录").click()
    time.sleep(20)
    cookies = context.cookies()
    context.close()
    browser.close()

    cookies = json.dumps([{cookie['name']: cookie['value']} for cookie in cookies])
    cookies = json.loads(cookies)
    result = []
    for item in cookies:
        key = list(item.keys())[0]
        value = item[key]
        result.append(f"{key}={value}")
    account = "; ".join(result)
    return account

def update_cookie(username: str, cookie_str: str):
    c = convert_cookie_string_to_dict(cookie_str)
    col_tk_account.update_many(
        {
            "username": username,
        },
        {
            "$set": {
                "cookies": {
                    "cookie_dict": c,
                    "cookie_str": convert_dict_to_cookie_string(c),
                }
            }
        }
    )
    logger.info("成功添加cookie: {}".format(cookie_str))

if __name__ == '__main__':
    account_list = [
        {
            "username": "珀莱雅官方旗舰店:安好",
            "password": "proya777"
        },
        {
            "username": "correctors科瑞肤旗舰店:boying",
            "password": "krfby1838619"
        },
        {
            "username": "hapsode悦芙媞旗舰店:boyingkf",
            "password": "yftbykf1838619"
        },
        {
            "username": "offrelax海外旗舰店:boyingkf",
            "password": "bykf1838619"
        },
        {
            "username": "offrelax旗舰店:boyingkf",
            "password": "bykf1838619"
        },
        {
            "username": "彩棠旗舰店:播音服务商",
            "password": "ct183619"
        },
        {
            "username": "timage彩棠专卖店:播音",
            "password": "ct18367158619"
        },


    ]

    with sync_playwright() as playwright:
        for account in account_list:
            username = account["username"]
            password = account["password"]
            cookies = login_and_get_cookies(playwright, username, password)
            update_cookie(username, cookies)
