#使用seleminu

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time
import json


def run():
    driver = webdriver.Chrome()
    driver.get('https://hot.taobao.com/')
    time.sleep(3)
    driver.find_element(By.XPATH, '//*[@id="fm-login-id"]').click()
    driver.find_element(By.XPATH,'//*[@id="fm-login-id"]').send_keys('珀莱雅官方旗舰店:boyin')
    time.sleep(1)
    driver.find_element(By.XPATH, '//*[@id="fm-login-password"]').click()
    driver.find_element(By.XPATH,'//*[@id="fm-login-password"]').send_keys('blyboyin167055')
    time.sleep(10)
    driver.find_element(By.XPATH, '//*[@id="login-form"]/div[4]/button').click()
    driver.find_element(By.XPATH, '//*[@id="login-form"]/div[4]/button').click()
    time.sleep(10)


if __name__ == '__main__':
    run()