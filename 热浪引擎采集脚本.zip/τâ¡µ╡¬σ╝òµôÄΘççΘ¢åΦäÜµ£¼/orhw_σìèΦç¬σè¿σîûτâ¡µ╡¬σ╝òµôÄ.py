import binascii

from playwright.sync_api import Playwright, sync_playwright, expect



import requests
import requests
import json
import time
import uuid
from datetime import timedelta, datetime

import requests
from loguru import logger


import model
from model import get_account

def run(playwright: Playwright) -> None:
    browser = playwright.firefox.launch(headless=False)
    context = browser.new_context()
    page = context.new_page()
    page.goto("https://hot.taobao.com/")
    page.get_by_placeholder("账号名/邮箱/手机号").click()
    time.sleep(1)
    page.get_by_placeholder("账号名/邮箱/手机号").fill("offrelax海外旗舰店:boyingbsj")
    page.get_by_placeholder("请输入登录密码").click()
    time.sleep(1)
    page.get_by_placeholder("请输入登录密码").fill("bybsj1675055")
    page.get_by_role("button", name="登录").click()
    time.sleep(20)
    page.goto("https://hot.taobao.com/")
    time.sleep(10)
    cookies = context.cookies()
    # print(cookies)
    cookie_values = []
    for cookie in cookies:
        if cookie.get("name") == "x5sec":
            x5sec_value = cookie.get("value")
            print(x5sec_value)
            cookie_bytes = binascii.unhexlify(cookie.get("value"))
            cookie_json = cookie_bytes.decode("utf-8")
            cookie_dict = json.loads(cookie_json)
            #print(cookie_dict)
            cookie_values.append(x5sec_value)
        elif cookie.get("name") == "cookie2":
            cookie2_value = cookie.get("value")
            print(cookie2_value)
            cookie_values.append(cookie2_value)

    # ---------------------
    context.close()
    browser.close()
    #print(cookies)
    return cookie_values



def crawler(username, cookie2_value, x5sec_value):
    # username = "珀莱雅官方旗舰店:安好"
    account = get_account(username=username)
    if not account:
        logger.error(f"账号 {username} 不存在")

    #cookies = account['cookies']['cookie_dict']
    # # x5sec = slider_get("h5api.m.taobao.com")
    current_date = datetime.now().date() - timedelta(days=1)
    current_date_str = current_date.strftime("%Y%m%d")

    csrf = uuid.uuid4().__str__()

    cookies = {
        't': '582910bf74983c6130f9780d6f54e748',
        'arms_uid': '35ef0196-7f3a-44ef-b8b9-cf55b34a2106',
        'ariaDefaultTheme': 'undefined',
        'thw': 'cn',
        'XSRF-TOKEN': '004fc3b0-8fc8-46d2-807a-fcd98c7d18ae',
        'cookie2': str(cookie2_value),
        '_tb_token_': '5e85b6aeea354',
        '_m_h5_tk': '5beb5ad02d17aff052c9e95292d835f7_1688447983952',
        '_m_h5_tk_enc': 'e30ceb5e649b0e242cc5694f40336d4c',
        'xlly_s': '1',
        '_samesite_flag_': 'true',
        'sgcookie': 'E1004EVkuW8n%2Fumi9VaisIEI3k5k33A1FxtKMH90cT1yIAJ%2BX4T8GFrkS6uHg9YmQTzORIwQvFaRH6eTNNO4cLviUUkaw3YFsp9fiju2IjJjiJ4%3D',
        'unb': '2215745472526',
        'sn': 'offrelax%E6%B5%B7%E5%A4%96%E6%97%97%E8%88%B0%E5%BA%97%3Aboyingbsj',
        'uc1': 'cookie14=Uoe8gqQP3A2ofA%3D%3D&cookie21=UIHiLt3xSalX',
        'csg': '28f5abc6',
        'cancelledSubSites': 'empty',
        'skt': '4fc9ddf39dde034d',
        '_cc_': 'UIHiLt3xSw%3D%3D',
        'cna': 'mKfPHL2QQwICAX14V8j2RZZ6',
        'x5sec': str(x5sec_value),
        'tfstk': 'd7L9zKZK3XFO0rGxSOnnudbjGQl3WFdwTdR7otXgcpppQpzcctmwHipDLiTGSCvLMQ6UjixGSnppFpWMoOA1kjpeBfSmQfJdMKAS_j7ibi1AdprDjifmkrQw-h4cIA7vGLbxEY0orCRN7ZMoErmxLu_Pqwdbm4Aw_ZPThbxIrsB-2AjtoAkqvSzw7Efsc1RZvNDb11jOFBnzkrNF98Xk19UblOIOQxYkycTbETC0fXhL0oS1TSI21D5..',
        'l': 'fBN_y36cTv7qWsTUXO5Courza779eQAbzsPzaNbMiIEGa6_dBdgC4NC1m4ikvdtjgTCbkeKPl_pr6dQ8snzZwWmF1IKgA8mIYxvtaQtJe',
        'isg': 'BAkJc1E4iRtBUHK7LmHlW9rhGDNjVv2Iq3_k-6t8t_AE8isE8qZGWsHkNFbEqpXA',
    }
    cookies['x5sec']=str(x5sec_value)
    cookies['cookie2']=str(cookie2_value)
    print(cookies)
    headers = {
        'authority': 'hot.taobao.com',
        'accept': 'application/json, text/plain, */*',
        'accept-language': 'zh-CN,zh;q=0.9',
        # Requests sorts cookies= alphabetically
        # 'cookie': 't=582910bf74983c6130f9780d6f54e748; arms_uid=35ef0196-7f3a-44ef-b8b9-cf55b34a2106; ariaDefaultTheme=undefined; thw=cn; xlly_s=1; XSRF-TOKEN=30cc3c14-1b32-4364-829a-ff458417df3e; cookie2=125d0b97fb396d2dc7eeea21eeba20a1; _tb_token_=e11b577756d76; _samesite_flag_=true; sgcookie=E100aktYKpgoG%2BUg0pPSuC%2FX%2B6wVzqXwotVmzrl3Lnbh1H8FTlWB9O7A8XWMk%2B2jHzJ%2FaWC7k0GvcaLmSEdWm1Qg2FrsIg8My6dV%2F3ocH6RNNOI%3D; unb=2215742276197; sn=offrelax%E6%B5%B7%E5%A4%96%E6%97%97%E8%88%B0%E5%BA%97%3Aboyingkf; uc1=cookie21=WqG3DMC9Eman&cookie14=Uoe8gqN%2FCNKFFw%3D%3D; csg=7aeb329c; cancelledSubSites=empty; skt=a2c3664678746073; _cc_=VT5L2FSpdA%3D%3D; cna=mKfPHL2QQwICAX14V8j2RZZ6; x5sec=7b22617365727665723b32223a226463373763373034333033363835646161386232386465616663366430313065434a652f69615547454b2b6d733876356d6f4c3870414561447a49794d5455334e4449794e7a59784f5463374d53494b59324677633278705a4756324d6a43487a76536c2f662f2f2f2f384251414d3d227d; _m_h5_tk=627aaa5a59ec4d1d9f4c9a58a43214a0_1688371715723; _m_h5_tk_enc=c9baed309febaa98472be3c3d7df1c17; l=fBN_y36cTv7qWOOWKOfwPurza77OSIRAguPzaNbMi9fP_QB65saGB1s2M6KBCnGVFsOMJ37fwLl9BeYBcIxnYo-kfzRKZbDmnmOk-Wf..; tfstk=dqWWrwmfLwBVZ7YCqYZVGX1cs_JINawapDtdjMHrvLp-AwsMuvrkUWvCRE_HzQJRL2QfbZSyzMJ-Rw_AWYR8ZwrQdw7VU_J8-ptd8w8zqBzhlws15HlFaumliNStUTPkLv9kKpUa7RyZqgvHpk-bQRlz-Usz7PyaQ7nvdzaNL5NHET5YbyazZGzjnxk9-10yR4MoEttY-FsWlnxch3OWWILfQ3Mw58usOmOidnTacoGntfpr2v1..; isg=BL6-0M8DVssmMoW6rXhKCmk4D9IA_4J52PbzumjHKoH8C17l0Y_SieTtg9fHM3qR',
        'origin': 'https://hot.taobao.com',
        'referer': 'https://hot.taobao.com/hw/union/goods-alliance/databoard/overview',
        'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"macOS"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
        'x-xsrf-token': '30cc3c14-1b32-4364-829a-ff458417df3e',

    }

    headers = {
        'authority': 'hot.taobao.com',
        'accept': 'application/json, text/plain, */*',
        'accept-language': 'zh-CN,zh;q=0.9',
        # Requests sorts cookies= alphabetically
        # 'cookie': 't=582910bf74983c6130f9780d6f54e748; arms_uid=35ef0196-7f3a-44ef-b8b9-cf55b34a2106; ariaDefaultTheme=undefined; thw=cn; XSRF-TOKEN=004fc3b0-8fc8-46d2-807a-fcd98c7d18ae; cookie2=1c3cfebdd021c11353e8af4802204675; _tb_token_=5e85b6aeea354; _m_h5_tk=5beb5ad02d17aff052c9e95292d835f7_1688447983952; _m_h5_tk_enc=e30ceb5e649b0e242cc5694f40336d4c; xlly_s=1; _samesite_flag_=true; sgcookie=E1004EVkuW8n%2Fumi9VaisIEI3k5k33A1FxtKMH90cT1yIAJ%2BX4T8GFrkS6uHg9YmQTzORIwQvFaRH6eTNNO4cLviUUkaw3YFsp9fiju2IjJjiJ4%3D; unb=2215745472526; sn=offrelax%E6%B5%B7%E5%A4%96%E6%97%97%E8%88%B0%E5%BA%97%3Aboyingbsj; uc1=cookie14=Uoe8gqQP3A2ofA%3D%3D&cookie21=UIHiLt3xSalX; csg=28f5abc6; cancelledSubSites=empty; skt=4fc9ddf39dde034d; _cc_=UIHiLt3xSw%3D%3D; cna=mKfPHL2QQwICAX14V8j2RZZ6; x5sec=7b22617365727665723b32223a223462383032373865353136306263303862666133316461613366323635353634434f75736a715547455075546f6f57652b4a485a78774561447a49794d5455334e4455304e7a49314d6a59374e79494b59324677633278705a4756324d6a43487a76536c2f662f2f2f2f384251414d3d227d; tfstk=d7L9zKZK3XFO0rGxSOnnudbjGQl3WFdwTdR7otXgcpppQpzcctmwHipDLiTGSCvLMQ6UjixGSnppFpWMoOA1kjpeBfSmQfJdMKAS_j7ibi1AdprDjifmkrQw-h4cIA7vGLbxEY0orCRN7ZMoErmxLu_Pqwdbm4Aw_ZPThbxIrsB-2AjtoAkqvSzw7Efsc1RZvNDb11jOFBnzkrNF98Xk19UblOIOQxYkycTbETC0fXhL0oS1TSI21D5..; l=fBN_y36cTv7qWsTUXO5Courza779eQAbzsPzaNbMiIEGa6_dBdgC4NC1m4ikvdtjgTCbkeKPl_pr6dQ8snzZwWmF1IKgA8mIYxvtaQtJe; isg=BAkJc1E4iRtBUHK7LmHlW9rhGDNjVv2Iq3_k-6t8t_AE8isE8qZGWsHkNFbEqpXA',
        'origin': 'https://hot.taobao.com',
        'referer': 'https://hot.taobao.com/hw/union/goods-alliance/databoard/overview',
        'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"macOS"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
        'x-xsrf-token': '004fc3b0-8fc8-46d2-807a-fcd98c7d18ae',
    }

    params = {
        '_csrf': '004fc3b0-8fc8-46d2-807a-fcd98c7d18ae',
    }

    data = {
        'period': '0',
        'planType': '0',
        'queryDate': '20230703',
    }

    response = requests.post('https://hot.taobao.com/commission/panel/shop/item/detail.do?_csrf=004fc3b0-8fc8-46d2-807a-fcd98c7d18ae',params=params, cookies=cookies, headers=headers, data=data)
    print(response)
    content = response.json()
    print(content)
    if content['msg'] != '成功':
        raise Exception(f'数据插入失败{content}')
    item = {
            "username": username,
            "source_data": content,
            "created_time": datetime.now(),
            "meta": {
                "tk_account": account,
                "data": data
            }
        }
    model.col_热浪引擎_热浪引擎_推广数据总览_全部订单数据总览.insert_one(item)
    logger.info(f"账号 {username} 采集成功")
    #time.sleep(90)


if __name__ == '__main__':
    with sync_playwright() as playwright:
        cookies=run(playwright)
        x5sec_value=cookies[0]
        cookie2_value=cookies[1]

        crawler('offrelax海外旗舰店:boyingkf', x5sec_value, cookie2_value,)



