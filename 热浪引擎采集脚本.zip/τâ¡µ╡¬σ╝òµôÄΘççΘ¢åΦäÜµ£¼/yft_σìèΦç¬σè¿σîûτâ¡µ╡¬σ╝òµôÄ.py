import binascii

from playwright.sync_api import Playwright, sync_playwright, expect




import json
import time
import uuid
from datetime import timedelta, datetime

import requests
from loguru import logger
import model
from model import get_account




def run(playwright: Playwright) -> None:
    browser = playwright.firefox.launch(headless=False)
    context = browser.new_context()
    page = context.new_page()
    page.goto("https://hot.taobao.com/")
    page.get_by_placeholder("账号名/邮箱/手机号").click()
    time.sleep(1)
    page.get_by_placeholder("账号名/邮箱/手机号").fill("hapsode悦芙媞旗舰店:boyingbsj")
    page.get_by_placeholder("请输入登录密码").click()
    time.sleep(1)
    page.get_by_placeholder("请输入登录密码").fill("yftbybsj1675055")
    page.get_by_role("button", name="登录").click()
    time.sleep(20)
    page.goto("https://hot.taobao.com/")
    time.sleep(10)
    cookies = context.cookies()
    # print(cookies)
    cookie_values = []
    for cookie in cookies:
        if cookie.get("name") == "x5sec":
            x5sec_value = cookie.get("value")
            print(x5sec_value)
            cookie_bytes = binascii.unhexlify(cookie.get("value"))
            cookie_json = cookie_bytes.decode("utf-8")
            cookie_dict = json.loads(cookie_json)
            #print(cookie_dict)
            cookie_values.append(x5sec_value)
        elif cookie.get("name") == "cookie2":
            cookie2_value = cookie.get("value")
            print(cookie2_value)
            cookie_values.append(cookie2_value)

    # ---------------------
    context.close()
    browser.close()
    #print(cookies)
    return cookie_values

def crawler(username,cookie2_value,x5sec_value):
    # username = "珀莱雅官方旗舰店:安好"
    account = get_account(username=username)
    if not account:
        logger.error(f"账号 {username} 不存在")

    cookies = account['cookies']['cookie_dict']

    current_date = datetime.now().date() - timedelta(days=1)
    current_date_str = current_date.strftime("%Y%m%d")

    csrf = uuid.uuid4().__str__()


    cookies = {
        't': '582910bf74983c6130f9780d6f54e748',
        'arms_uid': '35ef0196-7f3a-44ef-b8b9-cf55b34a2106',
        'ariaDefaultTheme': 'undefined',
        'thw': 'cn',
        'xlly_s': '1',
        'XSRF-TOKEN': '30cc3c14-1b32-4364-829a-ff458417df3e',
        'cookie2': '162808e8227186dfe15b044c341253d7',
        '_tb_token_': 'e11b577756d76',
        '_samesite_flag_': 'true',
        '_m_h5_tk': '5aeaacc47a50c67d30ac308acdbe52a6_1688387525181',
        '_m_h5_tk_enc': '8c6dbeb5a2356c6bf84f95f754e034e8',
        'sgcookie': 'E100QjmmwbzjnJ5z7fzZam7fqc4U1IZxjqI6ZJDMxWSSDADKxCrvPxSjsnZvhQa9YYqstOETg0mMlmSiPKLEh5lur%2F2sOCbi8ez23s6IZhF7OnA%3D',
        'unb': '2215814587512',
        'sn': 'hapsode%E6%82%A6%E8%8A%99%E5%AA%9E%E6%97%97%E8%88%B0%E5%BA%97%3Aboyingbsj',
        'uc1': 'cookie14=Uoe8gqNx%2FnQI8w%3D%3D&cookie21=V32FPkk%2FhSg%2F',
        'csg': '425e1997',
        'cancelledSubSites': 'empty',
        'skt': 'd20c0c9823dafec8',
        '_cc_': 'UtASsssmfA%3D%3D',
        'cna': 'mKfPHL2QQwICAX14V8j2RZZ6',
        'x5sec': '7b22617365727665723b32223a226663393039393563666364323534366164303465313135346631306263623832434f7a41387155474550545a6b596a686762547a57686f504d6a49784e5467784e4455344e7a55784d6a73784967706a5958427a62476c6b5a5859794d49664f394b58392f2f2f2f2f77464141773d3d227d',
        'isg': 'BHp6iKA_ylcFz0FugaxGBk2ky6acK_4FvJq3ToRzuY3YdxixbbsbF8vBxwOrZ3ad',
        'tfstk': 'dsGBzvbsa0hZqXES-6TZCMsNIZV5RDO2waa-o4CFyWFdP0g0b_83TLVSVliuYJPKagnsucuUY4PdV0itD6ypK08WN0oZTvPpq7a-40re-8-of0gjczWrLebnImuATXJ3a_N3Z7K20IRV-2VuwZ6u-c1hLBEFznR2g2vL-7u903vfGqSOjLXWXt0Bf1fNMulZ4CLTCRh_RRpZRlHiQUz3do3LfnKAQ014cBSfFNwcNPZ25F6lEtFFJ_1..',
        'l': 'fBN_y36cTv7qWGPjXO5CFurza77O0IRbzsPzaNbMiIEGa1khQF65gNC10b2BYdtjgTCjKeKPl_pr6dIazn4NwWmF1IKgA8mIjxvtaQtJe',
    }
    cookies['x5sec'] = str(x5sec_value)
    cookies['cookie2'] = str(cookie2_value)
    print(cookies)
    headers = {
        'authority': 'hot.taobao.com',
        'accept': 'application/json, text/plain, */*',
        'accept-language': 'zh-CN,zh;q=0.9',
        # Requests sorts cookies= alphabetically
        # 'cookie': 't=582910bf74983c6130f9780d6f54e748; arms_uid=35ef0196-7f3a-44ef-b8b9-cf55b34a2106; ariaDefaultTheme=undefined; thw=cn; xlly_s=1; XSRF-TOKEN=30cc3c14-1b32-4364-829a-ff458417df3e; cookie2=125d0b97fb396d2dc7eeea21eeba20a1; _tb_token_=e11b577756d76; _samesite_flag_=true; _m_h5_tk=5aeaacc47a50c67d30ac308acdbe52a6_1688387525181; _m_h5_tk_enc=8c6dbeb5a2356c6bf84f95f754e034e8; sgcookie=E1006z0%2B52zMLi0H7e%2BPiqUIxgoijzrO4pShmquQyvbgn8UhcMAef4Os1dlFoI7R0WiQz4ZWrVdX4yoJfuNOQpP2hoF%2FBpuo6AQkGMUZURGvrmI%3D; unb=2215814587512; sn=hapsode%E6%82%A6%E8%8A%99%E5%AA%9E%E6%97%97%E8%88%B0%E5%BA%97%3Aboyingbsj; uc1=cookie14=Uoe8gqNx%2FnQI8w%3D%3D&cookie21=V32FPkk%2FhSg%2F; csg=425e1997; cancelledSubSites=empty; skt=d20c0c9823dafec8; _cc_=UtASsssmfA%3D%3D; cna=mKfPHL2QQwICAX14V8j2RZZ6; x5sec=7b22617365727665723b32223a223632353136333365353832623236326531373965633832303534363734313734434b2f4c69715547454c794672746d657966446d2f774561447a49794d5455344d5451314f4463314d5449374d69494b59324677633278705a4756324d6a43487a76536c2f662f2f2f2f384251414d3d227d; isg=BHp6iKA_ylcFz0FugaxGBk2ky6acK_4FvJq3ToRzuY3YdxixbbsbF8vBxwOrZ3ad; tfstk=dsGBzvbsa0hZqXES-6TZCMsNIZV5RDO2waa-o4CFyWFdP0g0b_83TLVSVliuYJPKagnsucuUY4PdV0itD6ypK08WN0oZTvPpq7a-40re-8-of0gjczWrLebnImuATXJ3a_N3Z7K20IRV-2VuwZ6u-c1hLBEFznR2g2vL-7u903vfGqSOjLXWXt0Bf1fNMulZ4CLTCRh_RRpZRlHiQUz3do3LfnKAQ014cBSfFNwcNPZ25F6lEtFFJ_1..; l=fBN_y36cTv7qWGPjXO5CFurza77O0IRbzsPzaNbMiIEGa1khQF65gNC10b2BYdtjgTCjKeKPl_pr6dIazn4NwWmF1IKgA8mIjxvtaQtJe',
        'origin': 'https://hot.taobao.com',
        'referer': 'https://hot.taobao.com/hw/union/goods-alliance/databoard/overview',
        'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"macOS"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
        'x-xsrf-token': '30cc3c14-1b32-4364-829a-ff458417df3e',
    }

    params = {
        '_csrf': '30cc3c14-1b32-4364-829a-ff458417df3e',
    }

    data = {
        'period': '3',
        'planType': '0',
        'queryDate': current_date_str,
    }

    response = requests.post(
        'https://hot.taobao.com/commission/panel/shop/item/detail.do?_csrf=30cc3c14-1b32-4364-829a-ff458417df3e',
        params=params, cookies=cookies, headers=headers, data=data)

    print(response.text)

    if "" not in response.text:
        raise Exception(response.text)

    content = response.json()
    if content['msg'] != "成功":
        raise Exception(f'数据插入失败{content}')
    item = {
        "username": username,
        "source_data": content,
        "created_time": datetime.now(),
        "meta": {
            "tk_account": account,
            "data": data
        }
    }
    model.col_热浪引擎_热浪引擎_推广数据总览_全部订单数据总览.insert_one(item)
    logger.info(f"账号 {username} 采集成功")
    # time.sleep(90)


if __name__ == '__main__':
    with sync_playwright() as playwright:
        cookies=run(playwright)
        x5sec_value=cookies[0]
        cookie2_value=cookies[1]
    crawler('hapsode悦芙媞旗舰店:boyingkf',x5sec_value,cookie2_value,)

