import binascii
from playwright.sync_api import Playwright, sync_playwright
import json
import time
import uuid
from datetime import timedelta, datetime
import requests
from loguru import logger
import model
from model import get_account


# cookie_values= []
def run(playwright: Playwright) -> None:
    browser = playwright.chromium.launch(headless=False)
    context = browser.new_context()
    page = context.new_page()
    page.goto("https://hot.taobao.com/")
    page.get_by_placeholder("账号名/邮箱/手机号").click()
    time.sleep(1)
    page.get_by_placeholder("账号名/邮箱/手机号").fill("珀莱雅官方旗舰店:boyin")
    page.get_by_placeholder("请输入登录密码").click()
    time.sleep(1)
    page.get_by_placeholder("请输入登录密码").fill("blyboyin167055")
    page.get_by_role("button", name="登录").click()
    time.sleep(60)
    page.goto("https://hot.taobao.com/")
    time.sleep(10)
    cookies = context.cookies()
    # print(cookies)
    cookie_values = []
    for cookie in cookies:
        if cookie.get("name") == "x5sec":
            x5sec_value = cookie.get("value")
            print(x5sec_value)
            cookie_bytes = binascii.unhexlify(cookie.get("value"))
            cookie_json = cookie_bytes.decode("utf-8")
            cookie_dict = json.loads(cookie_json)
            #print(cookie_dict)
            cookie_values.append(x5sec_value)
        elif cookie.get("name") == "cookie2":
            cookie2_value = cookie.get("value")
            print(cookie2_value)
            cookie_values.append(cookie2_value)

    # ---------------------
    context.close()
    browser.close()
    #print(cookies)
    return cookie_values




def crawler(username,cookie2_value,x5sec_value):
    # username = "珀莱雅官方旗舰店:安好"
    account = get_account(username=username)
    if not account:
        logger.error(f"账号 {username} 不存在")

    #cookies = account['cookies']['cookie_dict']

    current_date = datetime.now().date() - timedelta(days=1)
    current_date_str = current_date.strftime("%Y%m%d")
    #print(cookies)

    csrf = uuid.uuid4().__str__()

    cookies = {
        't': '582910bf74983c6130f9780d6f54e748',
        'arms_uid': '35ef0196-7f3a-44ef-b8b9-cf55b34a2106',
        'ariaDefaultTheme': 'undefined',
        'thw': 'cn',
        'xlly_s': '1',
        'XSRF-TOKEN': '30cc3c14-1b32-4364-829a-ff458417df3e',
        'cookie2': '1f986918c50210f55e75dad13a2bc826',
        '_tb_token_': 'e11b577756d76',
        '_samesite_flag_': 'true',
        '_m_h5_tk': '627aaa5a59ec4d1d9f4c9a58a43214a0_1688371715723',
        '_m_h5_tk_enc': 'c9baed309febaa98472be3c3d7df1c17',
        'sgcookie': 'E100PYFCDwb9XU5%2B9mht8WBaKytYQTIn%2BBA2fywzY%2FhnVnMXkEI2yrqLebrRDsS6u3B4%2FTtIM9JLBmIA6nCf%2FqlO%2BNyFkV6O6fQb0PC2mtWVjfg%3D',
        'unb': '2215679497540',
        'sn': '%E7%8F%80%E8%8E%B1%E9%9B%85%E5%AE%98%E6%96%B9%E6%97%97%E8%88%B0%E5%BA%97%3Aboyin',
        'uc1': 'cookie14=Uoe8gqN%2FD3ln8Q%3D%3D&cookie21=VT5L2FSpdA%3D%3D',
        'csg': '6f331984',
        'cancelledSubSites': 'empty',
        'skt': '64edc1de4cf02d76',
        '_cc_': 'URm48syIZQ%3D%3D',
        'cna': 'mKfPHL2QQwICAX14V8j2RZZ6',
        'x5sec': '7b22617365727665723b32223a223039623361393465323463383336326131393334303938343165636138303263434b6e6130715547454c726968376d6a7236616464786f504d6a49784e5459334f5451354e7a55304d4473784967706a5958427a62476c6b5a5859794d49664f394b58392f2f2f2f2f77464141773d3d227d',
        'tfstk': 'dp4wpPs_Eq2BhEoFnm04TNkTTPgtD4BWQrMjiSVm1ADglVG0Y7eqCsIt5kk4KJkg3SCtix203xZ1AaNT6q3cF-75P5FiwqX72lH3u53xoTOBog_z68BbrTXyrYWkA_ifE7H37oiCZ4AY9v8DzQhZjY_-LEY08fPEEOWpHX0_7rEwnnoi9Xk5T6kdPH-G.',
        'l': 'fBN_y36cTv7qWMWAXOfwourza77tJIRAguPzaNbMi9fP_vW65gFRW1s29aKBCnGVFs_eR37fwLl9BeYBcIxnYo-kfzRKZXMmnmOk-Wf..',
        'isg': 'BLKy_zWXAm92jjkGmbQeLsU8A_6UQ7bdJHJv5nyL5mVQD1IJZNFL7eVp_6uzfy51',
    }
    cookies['x5sec']= str(x5sec_value)
    cookies['cookie2'] = str(cookie2_value)

    headers = {
        'authority': 'hot.taobao.com',
        'accept': 'application/json, text/plain, */*',
        'accept-language': 'zh-CN,zh;q=0.9',
        # Requests sorts cookies= alphabetically
        # 'cookie': 't=582910bf74983c6130f9780d6f54e748; arms_uid=35ef0196-7f3a-44ef-b8b9-cf55b34a2106; ariaDefaultTheme=undefined; thw=cn; xlly_s=1; XSRF-TOKEN=30cc3c14-1b32-4364-829a-ff458417df3e; cookie2=125d0b97fb396d2dc7eeea21eeba20a1; _tb_token_=e11b577756d76; _samesite_flag_=true; _m_h5_tk=627aaa5a59ec4d1d9f4c9a58a43214a0_1688371715723; _m_h5_tk_enc=c9baed309febaa98472be3c3d7df1c17; sgcookie=E100k6%2Fl%2FqRtdylonQVmKjmI%2BWuTvocT5asCibIuJoD4efUhRh7J7pQJcOmDEAnQhHiy1UwPx9t93xyWkqhC3rt6U3PcxoLdSI4lHZRGrxQXiTo%3D; unb=2215679497540; sn=%E7%8F%80%E8%8E%B1%E9%9B%85%E5%AE%98%E6%96%B9%E6%97%97%E8%88%B0%E5%BA%97%3Aboyin; uc1=cookie14=Uoe8gqN%2FD3ln8Q%3D%3D&cookie21=VT5L2FSpdA%3D%3D; csg=6f331984; cancelledSubSites=empty; skt=64edc1de4cf02d76; _cc_=URm48syIZQ%3D%3D; cna=mKfPHL2QQwICAX14V8j2RZZ6; x5sec=7b22617365727665723b32223a223162323930346166316466626534396539343764346362353932306237346530434f6a5869615547454a4f4132654b2f6e4e504a48526f504d6a49784e5459334f5451354e7a55304d4473794967706a5958427a62476c6b5a5859794d49664f394b58392f2f2f2f2f77464141773d3d227d; tfstk=d2tvrE4-_YexV8Mtms3obqv-0MklBnp2UIJQj1f05QdJgQrG51026NdMaNtcmKA8Bp1zoNYcmFdJOQ5DjsvfXAdyMx7igxRRBCvI3ASmuN6ONQzMoNXiXlI2qEqGijS9CBjttXmnxKJV0GGntI6W3K7K0dwixDv23-XjKLin_wLOnTxQEADDlhtyVAswoRP9reKRHagkh_wfY3BAk69XDl6NiHxKlhNh9O4jeYUa7Z6zBNJjz; l=fBN_y36cTv7qWMWAXOfwourza77tJIRAguPzaNbMi9fP_vW65gFRW1s29aKBCnGVFs_eR37fwLl9BeYBcIxnYo-kfzRKZXMmnmOk-Wf..; isg=BLKy_zWXAm92jjkGmbQeLsU8A_6UQ7bdJHJv5nyL5mVQD1IJZNFL7eVp_6uzfy51',
        'origin': 'https://hot.taobao.com',
        'referer': 'https://hot.taobao.com/hw/union/goods-alliance/databoard/overview',
        'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"macOS"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
        'x-xsrf-token': '30cc3c14-1b32-4364-829a-ff458417df3e',
    }

    params = {
        '_csrf': '30cc3c14-1b32-4364-829a-ff458417df3e',
    }

    data = {
        'period': '3',
        'planType': '0',
        'queryDate':  current_date_str,
    }

    response = requests.post(
        'https://hot.taobao.com/commission/panel/shop/item/detail.do?_csrf=30cc3c14-1b32-4364-829a-ff458417df3e',
        params=params, cookies=cookies, headers=headers, data=data)
    print(response.text)

    if "" not in response.text:
        raise Exception(response.text)

    content = response.json()
    if content['msg'] != "成功":
        raise Exception(f'数据插入失败{content}')
    item = {
        "username": username,
        "source_data": content,
        "created_time": datetime.now(),
        "meta": {
            "tk_account": account,
            "data": data
        }
    }
    model.col_热浪引擎_热浪引擎_推广数据总览_全部订单数据总览.insert_one(item)
    logger.info(f"账号 {username} 采集成功")
    # time.sleep(90)


if __name__ == '__main__':
    with sync_playwright() as playwright:
        cookies=run(playwright)
        x5sec_value=cookies[0]
        cookie2_value=cookies[1]
    crawler("珀莱雅官方旗舰店:安好",x5sec_value,cookie2_value,)