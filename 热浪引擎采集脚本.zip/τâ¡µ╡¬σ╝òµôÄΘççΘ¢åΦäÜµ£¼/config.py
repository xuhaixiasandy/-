import os
import sys
from pathlib import Path

from pydantic import BaseSettings, RedisDsn

sys.path.insert(0, Path(__file__).parent.as_posix())


class Settings(BaseSettings):
    LOG_PATH: str = Path(Path(__file__).parent.as_posix(), "log").as_posix()
    LOG_NAME: str = "log"

    MONGO_HOST: str = "39.175.169.130"
    MONGO_PORY: int = 27015
    MONGO_PASSWORD: str = 'boying321'
    MONGO_USERNAME: str = "boying"

    LOG_DATA_FILE_PATH = Path(Path(__file__).resolve().parent, "data").as_posix()


settings = Settings()
