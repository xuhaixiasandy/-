import binascii

from playwright.sync_api import Playwright, sync_playwright, expect

import json
import time
import uuid
from datetime import timedelta, datetime

import requests
from loguru import logger
import model
from model import get_account


def run(playwright: Playwright) -> None:
    browser = playwright.firefox.launch(headless=False)
    context = browser.new_context()
    page = context.new_page()
    page.goto("https://hot.taobao.com/")
    page.get_by_placeholder("账号名/邮箱/手机号").click()
    time.sleep(1)
    page.get_by_placeholder("账号名/邮箱/手机号").fill("彩棠旗舰店:boying")
    page.get_by_placeholder("请输入登录密码").click()
    time.sleep(1)
    page.get_by_placeholder("请输入登录密码").fill("ct1675055")
    page.get_by_role("button", name="登录").click()
    time.sleep(60)
    page.goto("https://hot.taobao.com/")
    time.sleep(10)
    cookies = context.cookies()
    # print(cookies)
    cookie_values = []
    for cookie in cookies:
        if cookie.get("name") == "x5sec":
            x5sec_value = cookie.get("value")
            print(x5sec_value)
            cookie_bytes = binascii.unhexlify(cookie.get("value"))
            cookie_json = cookie_bytes.decode("utf-8")
            cookie_dict = json.loads(cookie_json)
            #print(cookie_dict)
            cookie_values.append(x5sec_value)
        elif cookie.get("name") == "cookie2":
            cookie2_value = cookie.get("value")
            print(cookie2_value)
            cookie_values.append(cookie2_value)

    # ---------------------
    context.close()
    browser.close()
    #print(cookies)
    return cookie_values


def crawler(username,cookie2_value,x5sec_value):
    # username = "珀莱雅官方旗舰店:安好"
    account = get_account(username=username)
    if not account:
        logger.error(f"账号 {username} 不存在")

    cookies = account['cookies']['cookie_dict']
    current_date = datetime.now().date() - timedelta(days=1)
    current_date_str = current_date.strftime("%Y%m%d")

    csrf = uuid.uuid4().__str__()

    cookies = {
    't': '582910bf74983c6130f9780d6f54e748',
    'arms_uid': '35ef0196-7f3a-44ef-b8b9-cf55b34a2106',
    'ariaDefaultTheme': 'undefined',
    'thw': 'cn',
    'xlly_s': '1',
    'XSRF-TOKEN': '30cc3c14-1b32-4364-829a-ff458417df3e',
    'cookie2': '162808e8227186dfe15b044c341253d7',
    '_tb_token_': 'e11b577756d76',
    '_samesite_flag_': 'true',
    '_m_h5_tk': '627aaa5a59ec4d1d9f4c9a58a43214a0_1688371715723',
    '_m_h5_tk_enc': 'c9baed309febaa98472be3c3d7df1c17',
    'sgcookie': 'E100Yq0YucBn9mTDGy8omoMQWFlp5Ync5Mguij50zz%2FHuGzxSXsSMjW1T413RZvEU6wZR0d%2By9VfYdlzo4VqHSIdFyV%2BeiyNg1T3jtKaxm3U6rk%3D',
    'unb': '2215736082184',
    'sn': '%E5%BD%A9%E6%A3%A0%E6%97%97%E8%88%B0%E5%BA%97%3Aboying',
    'uc1': 'cookie14=Uoe8gqN%2FCRurWA%3D%3D&cookie21=URm48syIZx9a',
    'csg': '24633cb9',
    'cancelledSubSites': 'empty',
    'skt': '5b56bc7f1d1db5dc',
    '_cc_': 'U%2BGCWk%2F7og%3D%3D',
    'cna': 'mKfPHL2QQwICAX14V8j2RZZ6',
    'x5sec': '7b22617365727665723b32223a226563613065346565646136383137353130303535303934616338363031663763434a322b3871554745502f48714c4361344f374852686f504d6a49784e54637a4e6a41344d6a45344e4473784967706a5958427a62476c6b5a5859794d49664f394b58392f2f2f2f2f77464141773d3d227d',
    'l': 'fBN_y36cTv7qWIWfKOfwPurza77OSIRAguPzaNbMi9fPOTB65KzRW1s2GExBC3GVFsO9R37fwLl9BeYBcIxnYo-kfzRKZbDmnmOk-Wf..',
    'isg': 'BI-PxyunNyQORjSNpIML1bDjHiWZtOPWsT0iLaGcK_4FcK9yqYRzJo1mcqBOCLtO',
    'tfstk': 'duKDrjiOI_NCSd0gMsIjDZEs-C38DSs6bCEO6GCZz_5W6sC9QOSMaCHfMdlXshfygSCVHdnMsQfWMsIx11-k6QS9Hq9OslfyTxZtlVOGjdAFgsBthNzwMBAG5x1O_1A9QEH-vDpXhGswsXnKv8Z1fGzGqFz9hKs1b8FZJUJfIfAsWTuIa4S-hHkcJ62Gd2SAskQOTK5yHKKPnWCe3_qabsXcQMzz8_TafTk94Pa1uT6l9dxFJo5..',
    }
    cookies['x5sec'] = str(x5sec_value)
    cookies['cookie2'] = str(cookie2_value)


    headers = {
    'authority': 'hot.taobao.com',
    'accept': 'application/json, text/plain, */*',
    'accept-language': 'zh-CN,zh;q=0.9',
    # Requests sorts cookies= alphabetically
    # 'cookie': 't=582910bf74983c6130f9780d6f54e748; arms_uid=35ef0196-7f3a-44ef-b8b9-cf55b34a2106; ariaDefaultTheme=undefined; thw=cn; xlly_s=1; XSRF-TOKEN=30cc3c14-1b32-4364-829a-ff458417df3e; cookie2=125d0b97fb396d2dc7eeea21eeba20a1; _tb_token_=e11b577756d76; _samesite_flag_=true; _m_h5_tk=627aaa5a59ec4d1d9f4c9a58a43214a0_1688371715723; _m_h5_tk_enc=c9baed309febaa98472be3c3d7df1c17; sgcookie=E100znN1RLx7weS1DNHRxh9mNtpUwcBQ5C0Uz4O2%2FnM%2BIHsCEulK4KSr%2BgIbG2Q0y2L%2F4BgJHXUCA9HnEsv6r45gcrFRl63QD4wph16khC3PyB8%3D; unb=2215736082184; sn=%E5%BD%A9%E6%A3%A0%E6%97%97%E8%88%B0%E5%BA%97%3Aboying; uc1=cookie14=Uoe8gqN%2FCRurWA%3D%3D&cookie21=URm48syIZx9a; csg=24633cb9; cancelledSubSites=empty; skt=5b56bc7f1d1db5dc; _cc_=U%2BGCWk%2F7og%3D%3D; cna=mKfPHL2QQwICAX14V8j2RZZ6; x5sec=7b22617365727665723b32223a226339313238636334396337643736646365383733383064376261383530663365434f33476961554745496d7132397154304b2b6d57426f504d6a49784e54637a4e6a41344d6a45344e4473784967706a5958427a62476c6b5a5859794d49664f394b58392f2f2f2f2f77464141773d3d227d; l=fBN_y36cTv7qWIWfKOfwPurza77OSIRAguPzaNbMi9fPOTB65KzRW1s2GExBC3GVFsO9R37fwLl9BeYBcIxnYo-kfzRKZbDmnmOk-Wf..; isg=BI-PxyunNyQORjSNpIML1bDjHiWZtOPWsT0iLaGcK_4FcK9yqYRzJo1mcqBOCLtO; tfstk=duKDrjiOI_NCSd0gMsIjDZEs-C38DSs6bCEO6GCZz_5W6sC9QOSMaCHfMdlXshfygSCVHdnMsQfWMsIx11-k6QS9Hq9OslfyTxZtlVOGjdAFgsBthNzwMBAG5x1O_1A9QEH-vDpXhGswsXnKv8Z1fGzGqFz9hKs1b8FZJUJfIfAsWTuIa4S-hHkcJ62Gd2SAskQOTK5yHKKPnWCe3_qabsXcQMzz8_TafTk94Pa1uT6l9dxFJo5..',
    'origin': 'https://hot.taobao.com',
    'referer': 'https://hot.taobao.com/hw/union/goods-alliance/databoard/overview',
    'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"macOS"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
    'x-xsrf-token': '30cc3c14-1b32-4364-829a-ff458417df3e',
    }

    params = {
    '_csrf': '30cc3c14-1b32-4364-829a-ff458417df3e',
    }

    data = {
    'period': '3',
    'planType': '0',
    'queryDate': current_date_str,
    }

    response = requests.post('https://hot.taobao.com/commission/panel/shop/item/detail.do?_csrf=30cc3c14-1b32-4364-829a-ff458417df3e', params=params, cookies=cookies, headers=headers, data=data)
    content = response.json()
    print(content)
    if content['msg'] != '成功':
        raise Exception(f'数据插入失败{content}')
    item = {
        "username": username,
        "source_data": content,
        "created_time": datetime.now(),
        "meta": {
            "tk_account": account,
            "data": data
        }
    }
    model.col_热浪引擎_热浪引擎_推广数据总览_全部订单数据总览.insert_one(item)
    logger.info(f"账号 {username} 采集成功")
    #time.sleep(90)


if __name__ == '__main__':
    with sync_playwright() as playwright:
        cookies=run(playwright)
        x5sec_value=cookies[0]
        cookie2_value=cookies[1]
    crawler("彩棠旗舰店:播音服务商",x5sec_value,cookie2_value,)