import binascii

from playwright.sync_api import Playwright, sync_playwright, expect



import json
import time
import uuid
from datetime import timedelta, datetime

import requests
from loguru import logger

import model
from model import get_account


# cookie_values= []
def run(playwright: Playwright) -> None:
    browser = playwright.firefox.launch(headless=False)
    context = browser.new_context()
    page = context.new_page()
    page.goto("https://hot.taobao.com/")
    page.get_by_placeholder("账号名/邮箱/手机号").click()
    time.sleep(1)
    page.get_by_placeholder("账号名/邮箱/手机号").fill("offrelax旗舰店:boyingbsj")
    page.get_by_placeholder("请输入登录密码").click()
    time.sleep(1)
    page.get_by_placeholder("请输入登录密码").fill("bybsj1675055")
    page.get_by_role("button", name="登录").click()
    time.sleep(20)
    page.goto("https://hot.taobao.com/")
    time.sleep(10)
    cookies = context.cookies()
    # print(cookies)
    cookie_values = []
    for cookie in cookies:
        if cookie.get("name") == "x5sec":
            x5sec_value = cookie.get("value")
            print(x5sec_value)
            cookie_bytes = binascii.unhexlify(cookie.get("value"))
            cookie_json = cookie_bytes.decode("utf-8")
            cookie_dict = json.loads(cookie_json)
            #print(cookie_dict)
            cookie_values.append(x5sec_value)
        elif cookie.get("name") == "cookie2":
            cookie2_value = cookie.get("value")
            print(cookie2_value)
            cookie_values.append(cookie2_value)

    # ---------------------
    context.close()
    browser.close()
    #print(cookies)
    return cookie_values





def crawler(username,x5sec_value,cookie2_value):
    # username = "珀莱雅官方旗舰店:安好"
    account = get_account(username=username)
    if not account:
        logger.error(f"账号 {username} 不存在")

    cookies = account['cookies']['cookie_dict']
    current_date = datetime.now().date() - timedelta(days=1)
    current_date_str = current_date.strftime("%Y%m%d")

    csrf = uuid.uuid4().__str__()

    cookies = {
        't': '582910bf74983c6130f9780d6f54e748',
        'arms_uid': '35ef0196-7f3a-44ef-b8b9-cf55b34a2106',
        'ariaDefaultTheme': 'undefined',
        'thw': 'cn',
        'xlly_s': '1',
        'XSRF-TOKEN': '30cc3c14-1b32-4364-829a-ff458417df3e',
        'cookie2': '162808e8227186dfe15b044c341253d7',
        '_tb_token_': 'e11b577756d76',
        '_m_h5_tk': '3cd44e2768b99178d57e74e96be16b75_1688363155186',
        '_m_h5_tk_enc': '2c162569a923b95d1e5fbab1323ac75e',
        '_samesite_flag_': 'true',
        'sgcookie': '7b22617365727665723b32223a223365616561353830613233613135366665623734613436336361393734646261434b336476615547454a4b367462696b306279337a514561447a49794d5455344d5451314f4463314d5449374d53494b59324677633278705a4756324d6a43487a76536c2f662f2f2f2f384251414d3d227d',
        'unb': '2215748250423',
        'sn': 'offrelax%E6%97%97%E8%88%B0%E5%BA%97%3Aboyingkf',
        'uc1': 'cookie14=Uoe8gqN84PXuCA%3D%3D&cookie21=V32FPkk%2FhSg%2F',
        'csg': 'ad3b465c',
        'cancelledSubSites': 'empty',
        'skt': '67decf9d6c8dab56',
        '_cc_': 'U%2BGCWk%2F7og%3D%3D',
        'cna': 'mKfPHL2QQwICAX14V8j2RZZ6',
        'l': 'fBN_y36cTv7qW6CUmOfwPurza77OSIRAguPzaNbMi9fPO7B65xzcB1s25l-BC3GVFsO9R37fwLl9BeYBcIxnYo-kfzRKZbDmnmOk-Wf..',
        'tfstk': 'dHhwpQvsqSmCVgeem-Vq8Kr5-nPT97K5bjZboq005lqiG5amL4n4fEpT1vrqxDri0qLToomm0oM6dQgtWSFDVmRWNVUQfSxSeAEngVFYi3_CiLOrW0KYzHWzYm5ltheDq4En_YLwZqTI-k5caaUaIkO8YsfmTPuUqO7dDyVs_jHNmtygJyrW8erpN9WG.',
        'isg': 'BAIC7kPb0n-zoMn2ScROHhVMUw5k0wbtdOI_9kwbLnUgn6IZNGNW_YjZT5vjz36F',
        'x5sec': '7b22617365727665723b32223a223861346538346665343461626230326562656639613266623538393262326264434b6e4239365547454c4c426b62762b724b535451686f504d6a49784e5463304f4449314d4451794d7a73784967706a5958427a62476c6b5a5859794d49664f394b58392f2f2f2f2f77464141773d3d227d'
    }
    cookies['x5sec'] = str(x5sec_value)
    cookies['cookie2'] = str(cookie2_value)
    print(cookies)
    headers = {
        'authority': 'hot.taobao.com',
        'accept': 'application/json, text/plain, */*',
        'accept-language': 'zh-CN,zh;q=0.9',
        # Requests sorts cookies= alphabetically
        # 'cookie': 't=582910bf74983c6130f9780d6f54e748; arms_uid=35ef0196-7f3a-44ef-b8b9-cf55b34a2106; ariaDefaultTheme=undefined; thw=cn; xlly_s=1; XSRF-TOKEN=30cc3c14-1b32-4364-829a-ff458417df3e; cookie2=125d0b97fb396d2dc7eeea21eeba20a1; _tb_token_=e11b577756d76; _m_h5_tk=3cd44e2768b99178d57e74e96be16b75_1688363155186; _m_h5_tk_enc=2c162569a923b95d1e5fbab1323ac75e; _samesite_flag_=true; sgcookie=E100xrPs4a4ryANIYQFC8ccab7ky6ATTJ%2FcH534TuSpVX%2BmovsJZgbv6v6Flm8q2umeT5XIodgIFfHHBwvZ1d3OGlGFuc0i9qONMuGJdtlDF3Yo%3D; unb=2215748250423; sn=offrelax%E6%97%97%E8%88%B0%E5%BA%97%3Aboyingkf; uc1=cookie14=Uoe8gqN84PXuCA%3D%3D&cookie21=V32FPkk%2FhSg%2F; csg=ad3b465c; cancelledSubSites=empty; skt=67decf9d6c8dab56; _cc_=U%2BGCWk%2F7og%3D%3D; cna=mKfPHL2QQwICAX14V8j2RZZ6; l=fBN_y36cTv7qW6CUmOfwPurza77OSIRAguPzaNbMi9fPO7B65xzcB1s25l-BC3GVFsO9R37fwLl9BeYBcIxnYo-kfzRKZbDmnmOk-Wf..; tfstk=dYBDrMw9jUgIejFikEpbHIhZe8F-kq91QNH9WdLaaU85WELObhJGzNEXkGzfSOYPuqL2DGeGSaY5kEpY5FWlWaJODSs9SAYP8oMTG5_MIGbeuEKTcClNkwbM1oT97FbObsE8pJIfcd9NSyeLpoEvCdlME1lOci96Q03a9_SXjPffyTJT58Y-4trD9emMADp3XyvW8i8PDiBym2LF0UDZQExcQBlrTU1ZC3rOUfG6g3tkJGXe9x5..; isg=BAIC7kPb0n-zoMn2ScROHhVMUw5k0wbtdOI_9kwbLnUgn6IZNGNW_YjZT5vjz36F',
        'origin': 'https://hot.taobao.com',
        'referer': 'https://hot.taobao.com/hw/union/goods-alliance/databoard/overview?activeKey=0',
        'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"macOS"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
        'x-xsrf-token': '30cc3c14-1b32-4364-829a-ff458417df3e',
        # "x5sec":'7b22617365727665723b32223a223064376266623333363135356361393132653065303636666634373738353661434d48456b365547454f756a336648357459573949526f504d6a49784e5463304f4449314d4451794d7a73794967706a5958427a62476c6b5a5859794d49664f394b58392f2f2f2f2f77464141773d3d227d'
    }

    params = {
        '_csrf': '004fc3b0-8fc8-46d2-807a-fcd98c7d18ae',
    }

    data = {
        'period': '3',
        'planType': '0',
        'queryDate': current_date_str,
    }

    response = requests.post(
        'https://hot.taobao.com/commission/panel/shop/item/detail.do?_csrf=004fc3b0-8fc8-46d2-807a-fcd98c7d18ae',
        params=params, cookies=cookies, headers=headers, data=data)
    content = response.json()
    print(content)
    if content['msg'] != '成功':
        raise Exception(f'数据插入失败{content}')
    item = {
        "username": username,
        "source_data": content,
        "created_time": datetime.now(),
        "meta": {
            "tk_account": account,
            "data": data
        }
    }
    model.col_热浪引擎_热浪引擎_推广数据总览_全部订单数据总览.insert_one(item)
    logger.info(f"账号 {username} 采集成功")
    # time.sleep(90)


if __name__ == '__main__':
    with sync_playwright() as playwright:
        cookies=run(playwright)
        x5sec_value=cookies[0]
        cookie2_value=cookies[1]
    crawler('offrelax旗舰店:boyingkf',cookie2_value,x5sec_value,)