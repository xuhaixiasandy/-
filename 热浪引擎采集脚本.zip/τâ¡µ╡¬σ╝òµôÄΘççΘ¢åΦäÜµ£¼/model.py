from pymongo import MongoClient

from config import settings

mg_client = MongoClient(
    f'mongodb://{settings.MONGO_USERNAME}:{settings.MONGO_PASSWORD}@{settings.MONGO_HOST}:{settings.MONGO_PORY}/?authSource=admin'
)
# mg_client.authenticate(settings.MONGO_USERNAME, settings.MONGO_PASSWORD , mechanism='SCRAM-SHA-1')
db_bly_tm = mg_client['bly_tm']
db_bly_tm_cf = mg_client['bly_tm_cf']

col_tk_account = db_bly_tm_cf['tk_account']
col_tk_syj_account = db_bly_tm_cf['tk_syj_account']
col_tk_live = db_bly_tm_cf['tk_live']
col_tk_log = db_bly_tm_cf['tk_log']

col_淘宝直播_直播详情_数据大屏_核心数据 = db_bly_tm['淘宝直播_直播详情_数据大屏_核心数据']
col_淘宝直播_数据_直播业绩_直播间大盘 = db_bly_tm['淘宝直播_数据_直播业绩_直播间大盘']
col_淘宝直播_数据_本店成交_合作直播间 = db_bly_tm['淘宝直播_数据_本店成交_合作直播间']
col_淘宝直播_数据_本店成交_本店商品直播间成交 = db_bly_tm['淘宝直播_数据_本店成交_本店商品直播间成交']
col_淘宝直播_数据_直播间业绩_直播订单明细 = db_bly_tm['淘宝直播_数据_直播间业绩_直播订单明细']
col_热浪引擎_热浪引擎_推广数据总览_全部订单数据总览 = db_bly_tm['热浪引擎_热浪引擎_推广数据总览_全部订单数据总览']
col_生意参谋_直播_直播概况 = db_bly_tm['生意参谋_直播_直播概况']
col_生意参谋_市场_市场大盘_行业趋势 = db_bly_tm['生意参谋_市场_市场大盘_行业趋势']
col_生意参谋_竞争_竞品分析_入店搜索词_引流关键词 = db_bly_tm['生意参谋_竞争_竞品分析_入店搜索词_引流关键词']
col_生意参谋_业务专区_会员分析_会员分析 = db_bly_tm['生意参谋_业务专区_会员分析_会员分析']
col_生意参谋_市场_市场排行_商品_高交易 = db_bly_tm['生意参谋_市场_市场排行_商品_高交易']
col_生意参谋_市场_市场排行_商品_高流量 = db_bly_tm['生意参谋_市场_市场排行_商品_高流量']
col_生意经_宝贝分析 = db_bly_tm['生意经_宝贝分析']


def get_user_info():
    """拿到所有胡用户信息"""
    username_all = col_tk_account.find()
    return username_all


def get_username():
    """拿到所有用户名"""
    for user in get_user_info():
        yield user['username']


def get_account(username):
    # 0， 未登录， 1，已登录， 2，不可用
    account = col_tk_account.find_one(
        {
            "username": username,
            "status": 1
        },
        {
            "_id": 0,
            "username": 1,
            "cookies": 1
        }
    )
    return account


def save_cookie(cookie_dict):
    col_tk_account.insert_one(cookie_dict)


def get_syj_account(username):
    account = col_tk_syj_account.find_one(
        {
            "username": username,
            "status": 1
        },
        {
            "_id": 0,
            "username": 1,
            "cookies": 1
        }
    )
    return account


def get_oneline_live(username):
    for item in col_tk_live.find(
            {
                "username": username,
                "live_status": "1"
            }
    ):
        yield item


if __name__ == "__main__":
    pass

    # get_username()