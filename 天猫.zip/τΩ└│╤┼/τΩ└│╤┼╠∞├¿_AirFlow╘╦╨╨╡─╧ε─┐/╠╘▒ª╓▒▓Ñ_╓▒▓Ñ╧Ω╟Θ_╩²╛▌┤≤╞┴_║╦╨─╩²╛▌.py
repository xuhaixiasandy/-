import datetime
import json
import time
from pprint import pprint

from loguru import logger

import model
from helper import fetch_api


def crawler():
    username = "珀莱雅官方旗舰店:安好"
    account = model.get_account(username=username)
    if not account:
        logger.error(f"账号 {username} 不存在")

    for tk_live in model.get_oneline_live(username=username):
        live_id = tk_live['live_id']
        cookies = account['cookies']['cookie_dict']
        params = {
            'endTime': 1675403197000,
            'liveId': f'{live_id}',
            'searchType': '1',
            'startTime': 1675402897000,
            'timeType': 5,
            'types': 'flowStats,dealStats,flowScoreStats'
        }
        data = json.dumps(params)
        text = fetch_api("mtop.taobao.iliad.live.user.assistant.data.get", "1.0", data, cookies)
        content = json.loads(text)
        item = {
            "live_id": live_id,
            "username": username,
            "author_id": tk_live['author_id'],
            "source_data": content,
            "created_time": datetime.datetime.now(),
            "meta": {
                "tk_live": tk_live,
                "tk_account": account
            }
        }
        model.col_淘宝直播_直播详情_数据大屏_核心数据.insert_one(item)
        logger.info(f"直播详情: live_id: {live_id} username: {username} author_id: {tk_live['author_id']}")


if __name__ == '__main__':
    crawler()
