import fire
from loguru import logger

from utils import convert_dict_to_cookie_string, convert_cookie_string_to_dict
from model import col_tk_syj_account


def update_cookie(cookie_str):
    c = convert_cookie_string_to_dict(cookie_str)

    col_tk_syj_account.update_many(
        {
            "username": "珀莱雅官方旗舰店:安好",
        },
        {
            "$set": {
                "cookies": {
                    "cookie_dict": c,
                    "cookie_str": convert_dict_to_cookie_string(c),
                }
            }
        }
    )

    logger.info("成功添加cookie: {}".format(cookie_str))


if __name__ == '__main__':
    fire.Fire(update_cookie)
