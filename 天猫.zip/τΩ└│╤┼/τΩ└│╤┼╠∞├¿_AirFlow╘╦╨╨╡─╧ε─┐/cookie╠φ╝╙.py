import fire
from loguru import logger

from utils import convert_dict_to_cookie_string, convert_cookie_string_to_dict
from model import col_tk_account


def update_cookie(cookie_str):
    c = convert_cookie_string_to_dict(cookie_str)

    col_tk_account.update_many(
        {
            "username": "珀莱雅官方旗舰店:安好",
        },
        {
            "$set": {
                "cookies": {
                    "cookie_dict": c,
                    "cookie_str": convert_dict_to_cookie_string(c),
                }
            }
        }
    )

    logger.info("成功添加cookie: {}".format(cookie_str))


if __name__ == '__main__':
    # fire.Fire(update_cookie)
    update_cookie("t=d8c7821291cc2e65eedcd1fcdeceb88f; ali_apache_id=33.62.30.202.1679639110563.389903.3; xlly_s=1; _samesite_flag_=true; cookie2=1ad13044d4edb78d7ca6eb63f3a8d5f9; _tb_token_=e75ea38d373b0; XSRF-TOKEN=88a1350a-9e0d-4dee-9338-a6bff8e2373c; sgcookie=E100S2ba5qPLz9ZsywWgyrYp3sA30BxOMXbqZHwnSKHNxsk1l7nuIrhAjYzqa%2BXc%2BM9BaYSbh2WDc1nOeokooc4c7VGlUhTsfqLjCI%2Ffb9pNa4c%3D; unb=2215437797594; sn=%E7%8F%80%E8%8E%B1%E9%9B%85%E5%AE%98%E6%96%B9%E6%97%97%E8%88%B0%E5%BA%97%3A%E5%AE%89%E5%A5%BD; uc1=cookie21=UtASsssmfufd&cookie14=Uoe8izHeZ0F65g%3D%3D; csg=8d9b155a; cancelledSubSites=empty; skt=2a8f85281d1791e8; _cc_=VT5L2FSpdA%3D%3D; _euacm_ac_l_uid_=2215437797594; 2215437797594_euacm_ac_c_uid_=379424083; 2215437797594_euacm_ac_rs_uid_=379424083; _portal_version_=new; cc_gray=1; v=0; cna=bgWgHNTlegkCAXPCvdDuzrl2; x5sec=7b226f702d6d633b32223a223364326166663466376234623731376433373838653961666133313638386464434a53307a714547454f766d785a6253745a626944686f504d6a49784e54517a4e7a63354e7a55354e4473794d49754e376454352f2f2f2f2f77464141773d3d227d; _m_h5_tk=d75515e446b14229adb563c64ed7b276_1681110589350; _m_h5_tk_enc=a5f3f7a1c966fbf054087970a9afb87b; _euacm_ac_rs_sid_=60637940; isg=BJaWK_8W7lLG39rcbC_SbPuu50yYN9pxsMl-mgD_vHkWwzZdacdvgf3yW18v69KJ; tfstk=cqF1BJDGnhx1ra1Dsc_UORk2vukPZTTSlOig5GSsSPypNkz1iiOrVCrznnhqk21..; l=fBjRJkcPNN1HXOt-BOfwnurza77OpIRAguPzaNbMi9fPOtXM5yv1W1gcfNtHCnGVF6opJ3-bnsqvBeYBq_C-nxv9akQWBLHmnmOk-Wf..; JSESSIONID=F6E9DBAEE341B61BCCB8BB0110AA944B")