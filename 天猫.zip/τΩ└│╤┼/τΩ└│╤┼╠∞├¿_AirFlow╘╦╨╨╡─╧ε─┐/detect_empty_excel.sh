#!/bin/bash

find /data/lsg/珀莱雅天猫/data -name '*' -type f -size 0c
