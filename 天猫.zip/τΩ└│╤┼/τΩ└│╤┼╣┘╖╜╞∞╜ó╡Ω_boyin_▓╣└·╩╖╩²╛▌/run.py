import loguru
import fire
from model import get_username
import 淘宝直播_数据_本店成交_合作直播间
import 淘宝直播_数据_本店成交_本店商品直播间成交
import 淘宝直播_数据_直播业绩_直播间大盘
import 淘宝直播_数据_直播间业绩_直播订单明细
import 热浪引擎_热浪引擎_推广数据总览_全部订单数据总览
import 生意参谋_业务专区_会员分析_会员分析
import 生意参谋_品类_品类360_品类排行
import 生意参谋_品类_商品360_流量来源_新版api
import 生意参谋_品类_商品排行
import 生意参谋_品类_宏观监控_全量商品排行
import 生意参谋_市场_市场大盘_行业趋势
import 生意参谋_市场_市场排行_商品_高交易
import 生意参谋_市场_市场排行_商品_高流量
import 生意参谋_流量_店铺来源_构成_流量来源构成
import 生意参谋_直播_直播概况
import 生意参谋_竞争_竞品分析_入店搜索词_引流关键词
import 生意经_宝贝分析

from utils import DateRange


def crawler(spider, *args, **kwargs):
    try:
        spider(*args, **kwargs)
    except Exception as e:
        loguru.logger.exception(f"{spider.__name__} 采集失败: {e}")
        raise Exception('出现滑块')


def run(start: str, end: str):
    username = '珀莱雅官方旗舰店:boyin'
    date_range = DateRange(start_date=start, end_date=end)
    for date in date_range.to_date_range_2():
        item_id_list = [
            613869112484,
            610706716420,
            638042023960,
            650626915468,
            656464994485,
            693500260625,
            677610541847,
            630980256640,
            666589708754,
            696213528472,
            675497786268,
            653939069054,
            646698562880,
            621472343338,
            701180619371,
        ]
        crawler(淘宝直播_数据_本店成交_合作直播间.crawler, username, date)
        crawler(淘宝直播_数据_本店成交_本店商品直播间成交.crawler, username, date)
        crawler(淘宝直播_数据_直播业绩_直播间大盘.crawler, username, date)
        crawler(淘宝直播_数据_直播间业绩_直播订单明细.crawler, username, date)
        crawler(热浪引擎_热浪引擎_推广数据总览_全部订单数据总览.crawler, username, date)
        crawler(生意参谋_业务专区_会员分析_会员分析.crawler, username, date)
        crawler(生意参谋_品类_品类360_品类排行.crawler, username, date)
        crawler(生意参谋_品类_商品360_流量来源_新版api.crawler, username, item_id_list, date)
        crawler(生意参谋_品类_商品排行.crawler, username, date)
        crawler(生意参谋_市场_市场大盘_行业趋势.crawler, username, date)
        crawler(生意参谋_市场_市场排行_商品_高交易.crawler, username, date)
        crawler(生意参谋_市场_市场排行_商品_高流量.crawler, username, date)
        crawler(生意参谋_流量_店铺来源_构成_流量来源构成.crawler, username, date)
        crawler(生意参谋_直播_直播概况.crawler, username, date)
        crawler(生意经_宝贝分析.crawler, username, date)



if __name__ == "__main__":
    fire.Fire(run)
    # run("2023-01-26", "2023-01-26")
