"""
模块说明：
    生意参谋-直播-本店商品成交(合作直播间，只要账号为李佳琦Austin的商品数据)
"""

import json
import time
import uuid
from datetime import timedelta, datetime

import requests
from loguru import logger

import model
import crypt_utils
from model import get_account
from helper import fetch_tbzb


def crawler(username: str):
    for cate in [
        {
            "cate_id": "201173503",
            "cate_name": "粉状精华",
            "level": 3
        },
        {
            "cate_id": "201168604",
            "cate_name": "安瓶/原液",
            "level": 3
        },
        {
            "cate_id": "201750001",
            "cate_name": "精华油",
            "level": 3
        },
        {
            "cate_id": "201744402",
            "cate_name": "防晒膏/防晒粉末",
            "level": 3
        },
        {
            "cate_id": "201171302",
            "cate_name": "防晒喷雾",
            "level": 3
        }
    ]:
        # username = "珀莱雅官方旗舰店:安好"
        account = get_account(username)
        if not account:
            logger.error(f"账号 {username} 不存在")

        cookies = account['cookies']['cookie_dict']

        current_date = datetime.now().date() - timedelta(days=1)
        current_date_str = current_date.strftime("%Y-%m-%d")
        if model.col_生意参谋_市场_市场大盘_行业趋势.count_documents(
                {
                    "cate_id": cate["cate_id"],
                    'meta.data.dateRange': f'{current_date_str}|{current_date_str}',
                    'meta.tk_account.username': username
                }
        ):
            logger.info(f"已经存在: {cate}")
            continue


        headers = {
            'Host': 'sycm.taobao.com',
            'sec-ch-ua': '"Chromium";v="110", "Not A(Brand";v="24", "Microsoft Edge";v="110"',
            'bx-umidtoken': 'GCDFCD72C133ABE68E1FBCD2EE213DB54217154D228CF8CB908',
            'sec-ch-ua-mobile': '?0',
            'bx-ua': '225!mRGM/izWooizMm7iFoTo+ikXi+ljrDwFaQ/N+blMNAxeo0bimZ76s1s2NBOOWpkgTKc1Hh93+DZDXizP+kynm4yg1XvPvHs2APPWzFoBeUvgwFSHUsWz04HnB8mE/8vr7094ndQwmyvhWjVJoozlb34dX4f/oLnjDUHofeG0QE0dDMXhfifTomQrcPFTbeVU4dEzVOV0QhcdPhXhf/BCeU4KjcNJyVqz4U/+f4jouoyqC9IzcIm3odnS6VJOFxD840NmYeDxkTb8bY18f1taZObGM4f40/diDBmzfeGoQz0KDM5hfodMbUSde4bxQQMRSNHv7eRpl0oqVBF6AdJ5Ft6uY7I3XnTLgtvBM4QGCjQ8oL56f+KaDKnkx5fDVhRnbkgOAQ3POu4q9ssuuNZgdv3YA7JF4hx/eNP88QojOpSq47XxjmL0FvVYMgr0yQhg4fIIBxGufoC8DbX778BCbUSKjxI4K/jRDG/+fe1dFW3+FlqFQCaimO0mUya7/TN0nSTkzuWadYdVRWFPHtoxoPyfLKFTLuMkVOE55FMl3c7wGUk1vziWNjVVT2YWeCESBVEh5mGpsmXZD75/+86zK++wtMceDzbIX1R1Mv807QfwidYcGH7ZxWHhIZ9VLyKkpDLYR4TYhQRzob71IrEuBDIiZ+u8xeClxUn/NqkbVRAymnAgsbjj7N5NW1rXzjqP4jzMw/h+esCb/9VrLLTQ8CPUkmqZjzfSW75ZkRa7tjU1BxDy/9v4Oumxe4maJ+xKIjtAZ+3Rl8X4EktECj9wqvNMdbDwBpTqQIiKO22jzzoWDMemc9uQ/zVtEGJQNxCgdrxiaOOELujlVqL4sGRpHTobirUxDIk0N3PpAcXNcYVX+msi/bzcDkX8lafwnTThgq6XSIn0X7vw4UZPAoQkF2dGEb6S8r29A1qal65tbK7SEVK/tu6glLqcF+Oz7+60sRTN+0+p1r+subjDKxV8rPVfIntCXOWOdoMAwVxa/zXDFjO6eIFg8H+5puQYvrWpBGyL/nv+/FwWxX60mArznPMNXzXEECgJcAOUv572IFnq7nuHxSyzmfEY6DazKAz7Mqj/Aailtra7x/umnRm29RAp2/zscAVx6Y9hSO4YF10YyWltV89UaHpuy16bdVGYzo2T9DYkRymIK6ohGfxonB5n40nd5TjJ0mFs1f9WOACsucW0HlfkdUiWHOhQShEfx0QfIRgYT6E5BvXMoZolxffNZEsrRereaTGc4KP6Vy7+LRBd54+LnJNDikW7Oo==',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edg/110.0.1587.63',
            'Transit-Id': '8PBSIcxDrZhOezl3Mr2QeABky/C5QtRIlMCq8UXE7RKQ9Qsxm1pHLR7+7rdwZSZsNtBjK2yjm76u1CsJ4ef78Ex1pjQarkxaIlTpoaPsz64f8X00ks0IRNTC3Q5bkwvqc35fObBcvUMGEmtpK1UUewWkajgpHIHZp6uV9w2QAA==',
            'Sycm-Referer': '/mc/mq/market_rank',
            'bx-v': '2.2.3',
            'Onetrace-Card-Id': 'sycm-mc-mq-market-rank.sycm-mc-mq-item-item-sale',
            'Sycm-Query': 'dateType=day&activeKey=item',
            'sec-ch-ua-platform': '"Windows"',
            'Accept': '*/*',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': f'https://sycm.taobao.com/mc/mq/market_rank?activeKey=item&cateFlag=1&cateId={cate["cate_id"]}&dateRange={current_date_str}%7C{current_date_str}&dateType=day&sellerType=-1&spm=a21ag.11815228.LeftMenu.d591.7e2650a5uPilgt',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        }
        params = (
            ('dateRange', f'{current_date_str}|{current_date_str}'),
            ('dateType', 'day'),
            ('pageSize', '10'),
            ('page', '1'),
            ('order', 'desc'),
            ('orderBy', 'tradeIndex'),
            ('cateId', f'{cate["cate_id"]}'),
            ('device', '0'),
            ('sellerType', '-1'),
            ('styleId', ''),
            ('priceSeg', ''),
            ('priceSegName', ''),
            ('minPrice', ''),
            ('maxPrice', ''),
            ('sex', ''),
            ('sexRatio', ''),
            ('age', ''),
            ('ageRatio', ''),
            ('indexCode', 'tradeIndex,tradeGrowthRange,payRateIndex'),
            ('_', f'{int(time.time() * 1000)}'),
            ('token', 'bd414fbfb'),
        )
        response = requests.get(
            'https://sycm.taobao.com/mc/v2/mq/mkt/rank/item/hotsale.json',
            headers=headers,
            params=params,
            cookies=cookies,
            timeout=10
        )



        if "statDate" in response.text:
            logger.error(f'[{username}] {cate["cate_name"]} {current_date_str} 交易指数排行榜抓取失败')
            logger.error(response.text)
            time.sleep(90)
            continue
        content = response.json()
        item = {
            "username": username,
            "source_data": content,
            "cate_id": cate["cate_id"],
            "created_time": datetime.now(),
            "meta": {
                "tk_account": account,
                "data": dict(params),
                "tk": cate
            }
        }
        model.col_生意参谋_市场_市场排行_商品_高交易.insert_one(item)
        logger.info(f'[{username}] {cate["cate_name"]} {current_date_str} 交易指数排行榜抓取成功')
        time.sleep(90)


if __name__ == '__main__':
    crawler('彩棠旗舰店:播音服务商')
