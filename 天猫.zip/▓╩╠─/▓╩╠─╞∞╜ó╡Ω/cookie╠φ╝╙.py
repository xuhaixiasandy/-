import fire
from loguru import logger

from utils import convert_dict_to_cookie_string, convert_cookie_string_to_dict
from model import col_tk_account


def update_cookie(cookie_str, username):
    c = convert_cookie_string_to_dict(cookie_str)
    # user_id 1 为测试
    col_tk_account.update_many(
        {
            "username": username,
        },
        {
            "$set": {
                "cookies": {
                    "cookie_dict": c,
                    "cookie_str": convert_dict_to_cookie_string(c),
                }
            }
        }
    )

    logger.info("成功添加cookie: {}".format(cookie_str))


if __name__ == '__main__':
    # fire.Fire(update_cookie)

    update_cookie(username='彩棠旗舰店:播音服务商', cookie_str="t=d8c7821291cc2e65eedcd1fcdeceb88f; ali_apache_id=33.62.30.202.1679639110563.389903.3; xlly_s=1; _m_h5_tk=0a3ccd71b14af430165e19e7ce9e6d19_1681098708491; _m_h5_tk_enc=10ca45f2892c67578fdcac866718acc5; _cc_=V32FPkk%2Fhw%3D%3D; _samesite_flag_=true; cookie2=1ad13044d4edb78d7ca6eb63f3a8d5f9; _tb_token_=e75ea38d373b0; sgcookie=E100uNHlyTFg1Sq1DsP6dUgvzzzVD28GOWu3pswBZsHIoZ2nLgnCg4fgQ9gySyUUit2AqeuqFhnJ3NDGcLfJGPD20cgXL5sBg2aB1rI8X7mf%2BiM%3D; unb=2215646694985; sn=%E5%BD%A9%E6%A3%A0%E6%97%97%E8%88%B0%E5%BA%97%3A%E6%92%AD%E9%9F%B3%E6%9C%8D%E5%8A%A1%E5%95%86; uc1=cookie21=U%2BGCWk%2F7oPIg&cookie14=Uoe8izHeYtW%2BDw%3D%3D; csg=3319179c; cancelledSubSites=empty; skt=4c0500173a561158; _euacm_ac_l_uid_=2215646694985; 2215646694985_euacm_ac_c_uid_=2978671516; 2215646694985_euacm_ac_rs_uid_=2978671516; v=0; _portal_version_=new; cc_gray=1; cna=bgWgHNTlegkCAXPCvdDuzrl2; XSRF-TOKEN=88a1350a-9e0d-4dee-9338-a6bff8e2373c; _euacm_ac_rs_sid_=null; l=fBjRJkcPNN1HXKT_BO5alurza77tBIOb4sPzaNbMiIEGa6gFwF_6BNCsoJevkdtjgTCFwetyc-f0DdLHR3fRwxDDB31vdf_x3xvtaQtJe; tfstk=cGvRBEtzYq0ltDuh3Th08kU2tkKRaNgdlu_3pdbT6LSm4ye3LsXwIdd53bsC7anA.; JSESSIONID=D7C8BBCC1B219F53FB66A6B13B90EB75; isg=BElJpuo4Sct45DWVBy5VZWB_WHWjlj3IOzgRE-u-xTBvMmlEM-ZNmDdkdJaEcdUA")
