import loguru

from model import get_username
from fire import Fire
import 淘宝直播_数据_本店成交_合作直播间
import 淘宝直播_数据_本店成交_本店商品直播间成交
import 淘宝直播_数据_直播业绩_直播间大盘
import 淘宝直播_数据_直播间业绩_直播订单明细
import 热浪引擎_热浪引擎_推广数据总览_全部订单数据总览
import 生意参谋_业务专区_会员分析_会员分析
import 生意参谋_品类_品类360_品类排行
import 生意参谋_品类_商品360_流量来源_新版api
import 生意参谋_品类_商品排行
import 生意参谋_品类_宏观监控_全量商品排行
import 生意参谋_市场_市场大盘_行业趋势
import 生意参谋_市场_市场排行_商品_高交易
import 生意参谋_市场_市场排行_商品_高流量
import 生意参谋_流量_店铺来源_构成_流量来源构成
import 生意参谋_直播_直播概况
import 生意参谋_竞争_竞品分析_入店搜索词_引流关键词
import 生意经_宝贝分析

from utils import DateRange


def crawler(spider, *args, **kwargs):
    try:
        spider(*args, **kwargs)
    except Exception as e:
        loguru.logger.exception(f"{spider.__name__} 采集失败: {e}")


def run(start: str, end: str):
    username = 'timage彩棠专卖店:boying'
    date_range = DateRange(start_date=start, end_date=end)
    for date in date_range.to_date_range_2():
        item_id_list = [
            681673886232,
            681395017965,
            680641464530,
            681993559035,
            682011483451,
            681396365722,
            682011775405,
            688600490206,
            681040184570,
        ]

        # crawler(淘宝直播_数据_本店成交_合作直播间.crawler, username, date)
        # crawler(淘宝直播_数据_本店成交_本店商品直播间成交.crawler, username, date)
        # crawler(淘宝直播_数据_直播业绩_直播间大盘.crawler, username, date)
        # crawler(淘宝直播_数据_直播间业绩_直播订单明细.crawler, username, date)
        # crawler(热浪引擎_热浪引擎_推广数据总览_全部订单数据总览.crawler, username, date)
        crawler(生意参谋_业务专区_会员分析_会员分析.crawler, username, date)
        crawler(生意参谋_品类_品类360_品类排行.crawler, username, date)
        crawler(生意参谋_品类_商品360_流量来源_新版api.crawler, username, item_id_list, date)
        crawler(生意参谋_品类_商品排行.crawler, username, date)
        crawler(生意参谋_市场_市场大盘_行业趋势.crawler, username, date)
        crawler(生意参谋_品类_宏观监控_全量商品排行.crawler, username, date)
        # crawler(生意参谋_市场_市场排行_商品_高交易.crawler, username, date)
        # crawler(生意参谋_市场_市场排行_商品_高流量.crawler, username, date)
        crawler(生意参谋_流量_店铺来源_构成_流量来源构成.crawler, username, date)
        crawler(生意参谋_直播_直播概况.crawler, username, date)




        # 淘宝直播_数据_本店成交_合作直播间.crawler(username, date)
        # 淘宝直播_数据_本店成交_本店商品直播间成交.crawler(username, date)
        # 淘宝直播_数据_直播业绩_直播间大盘.crawler(username, date)
        # 淘宝直播_数据_直播间业绩_直播订单明细.crawler(username, date)
        # 热浪引擎_热浪引擎_推广数据总览_全部订单数据总览.crawler(username, date)

        # 生意参谋_业务专区_会员分析_会员分析.crawler(username, date)
        # 生意参谋_品类_品类360_品类排行.crawler(username, date)
        # 生意参谋_品类_商品360_流量来源_新版api.crawler(username, item_id_list, date)
        # 生意参谋_品类_商品排行.crawler(username, date)
        # 生意参谋_市场_市场大盘_行业趋势.crawler(username, date)
        # 生意参谋_品类_宏观监控_全量商品排行.crawler(username, date)
        # 生意参谋_市场_市场排行_商品_高交易.crawler(username, date)
        # 生意参谋_市场_市场排行_商品_高流量.crawler(username, date)
        # 生意参谋_流量_店铺来源_构成_流量来源构成.crawler(username, date)
        # 生意参谋_直播_直播概况.crawler(username, date)
        # 生意参谋_竞争_竞品分析_入店搜索词_引流关键词.crawler(username, item_id_list, date)
        # 生意经_宝贝分析.crawler(username, date)


if __name__ == "__main__":
    run("2023-01-26", "2023-01-26")
    # convert：转换
    Fire(run)


