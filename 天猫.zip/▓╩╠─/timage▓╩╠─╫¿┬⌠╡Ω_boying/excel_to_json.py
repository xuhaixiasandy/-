import pprint

import pandas as pd
import json

# 读取Excel文件
df = pd.read_excel('./【生意参谋平台】无线商品二级流量来源详情-timage彩棠专卖店_播音-2023-04-21_2023-04-21-新版api-680641464530.xls', index_col=0)

# 转换为JSON格式
result = {}
for index, row in df.iterrows():
    result[index] = row.to_dict()


pprint.pprint(result)