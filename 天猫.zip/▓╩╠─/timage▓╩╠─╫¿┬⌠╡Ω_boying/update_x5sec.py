from model import mg_client
from fire import Fire
import requests
from loguru import logger


db_bly_tm_cf = mg_client['bly_tm_cf']
db_bolaiya = mg_client['bolaiya']
db_mh = mg_client['mh']
db_huaxi = mg_client['huaxi']


def update(x5sec, mg_collect):
    for i in mg_collect['tk_account'].find({}):
        cookies = i['cookies']
        cookies['cookie_dict']['x5sec'] = x5sec

        if "x5sec" in cookies['cookie_str']:
            for x5sec_str in cookies['cookie_str'].split(";"):
                if "x5sec" in x5sec_str:
                    cookies['cookie_str'].replace(x5sec_str, f"x5sec={x5sec}")
        else:
            cookies['cookie_str'] = f"{cookies['cookie_str']}; x5sec={x5sec};"

        mg_collect['tk_account'].update_one(
            {
                "_id": i['_id']
            },
            {
                "$set": {
                    "cookies": cookies
                }
            }
        )


def set_cookie_x5sec(x5sec, url):
    data = {
        "x5sec": x5sec,
        "url": url
    }
    logger.info("data: ", data)
    response = requests.post("http://39.175.169.130:15555/taobaosecret/ali/slider/x5sec/v1", json=data)
    logger.info(response.text)


def main():
    x5sec = requests.get()
    update(x5sec, db_bly_tm_cf)
    update(x5sec, db_bolaiya)
    update(x5sec, db_mh)
    update(x5sec, db_huaxi)


if __name__ == '__main__':
    Fire(main)
    # x5sec = '7b226f702d6d633b32223a223535383165336436373730303063303462306363373631646634623064646362434d36752f364547454c366e71386930367257666f514561454449794d5455324f4459304e5463304e6a55374d5441776934337431506e2f2f2f2f2f41554144227d'
    # main(x5sec)