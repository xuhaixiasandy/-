import fire
from loguru import logger

from utils import convert_dict_to_cookie_string, convert_cookie_string_to_dict
from model import col_tk_account


def update_cookie(cookie_str):
    username = "timage彩棠专卖店:boying"
    c = convert_cookie_string_to_dict(cookie_str)
    # user_id 1 为测试
    col_tk_account.update_many(
        {
            "username": username,
        },
        {
            "$set": {
                "cookies": {
                    "cookie_dict": c,
                    "cookie_str": convert_dict_to_cookie_string(c),
                }
            }
        }
    )

    logger.info("成功添加cookie: {}".format(cookie_str))


if __name__ == '__main__':
    update_cookie(cookie_str='xlly_s=1; _samesite_flag_=true; cookie2=1eab6f13183d54a4dfe542fe2e7d705e; t=68f9f7da0fdf122ed962fc3c304e116e; _tb_token_=d86b883a8b78; unb=2215686457465; sn=timage彩棠专卖店:boying; cancelledSubSites=empty; XSRF-TOKEN=bf78005d-806b-4f84-b28e-fb9ba0f885c8; _m_h5_tk=b0b413c0ae4bbdc7471fddc182ce72d2_1681904282736; _m_h5_tk_enc=847060b3d48b59e6877aecbe366bfdfb; x5sec=7b226f702d6d633b32223a226631346437336662373538666163643239346238333562336436633962323735434e48742f714547454c326135364f457864574330414561447a49794d5455324f4459304e5463304e6a55374e54434c6a6533552b662f2f2f2f384251414d3d227d; sgcookie=E100WK1BcaDVPSxPo4NeCZu8xUiGwDAozNRbV6422d8wDJfwLPLfK4rloykEi+UVazj3ErPe1LecAyfoyKVHqrHkfC6GOUUmI2AKiASfZy99UGY=; uc1=cookie14=Uoe8izn1GAd6rw==&cookie21=UtASsssmfufd; csg=ef2ec5c9; skt=a8a061081f840f9f; _cc_=UtASsssmfA==; _euacm_ac_l_uid_=2215686457465; 2215686457465_euacm_ac_c_uid_=2214545595990; 2215686457465_euacm_ac_rs_uid_=2214545595990; v=0; _portal_version_=new; cc_gray=1; cna=o5vGHOHa32MBASQOA5DemraR; _euacm_ac_rs_sid_=286300647; JSESSIONID=E9D64C9EB122D02ED60A10B3ED10E3C7; isg=BFxc_5gGVFCIACAMS-lwesCVLXoO1QD_HstksTZfusckgf4LXuBgjvNw4el5CThX; tfstk=ceLcBQTW2nSfJL09FK_j8mSdrU6GalaNKF8Wzb3gk5wv1f8fgscY4kJSfbXmdxr1.; l=fBPLpZUrNbfyNRPYBO5CPurza779UQRbzsPzaNbMiIEGa6OCCFp3-NCs-_tJAdtjgT5AXetyc-fcNdFHz7438AkDBeYIua1hp3v6-eM3N7AN.')
    # fire.Fire(update_cookie)
    