"""
数据模块：
    日度自播数据 -- 产品-自播（计算退款)-天猫商家后台-内容运营中心-淘宝直播
"""

import json
import time
from datetime import timedelta, datetime
from pprint import pprint

from loguru import logger

import model
from model import get_account
from helper import fetch_tbzb
from utils import DateRange
import asyncio


def crawler(username, date):
    account = get_account(username=username)
    if not account:
        logger.error(f"账号 {username} 不存在")

    cookies = account['cookies']['cookie_dict']
    date_str = date
    params = {
        'beginTime': f'{date_str} 00:00:00',
        'dataQRFormId': 'live_overview_order',
        'endTime': f'{date_str} 23:59:59',
        'hit': '5000',
        'itemId': None,
        'itemTitle': None,
        'orderColumn': 'pay_time',
        'orderDateType': '3',
        'orderId': None,
        'orderIds': None,
        'orderType': '1',
        'queryUserRole': 'ALL',
        'start': '0',
        'time': int(time.time() * 1000)
    }

    data = {'dataApi': 'dataQRForm',
            'param': json.dumps(params)}
    text = fetch_tbzb(data, cookies)
    content = json.loads(text)
    item = {
        "username": username,
        "source_data": content,
        "created_time": datetime.now(),
        "meta": {
            "tk_account": account
        }
    }
    model.col_淘宝直播_数据_直播间业绩_直播订单明细.insert_one(item)
    logger.info(f"直播间商品订单采集成功: {username}")
    time.sleep(90)


if __name__ == '__main__':
    crawler('彩棠旗舰店:播音服务商', "2023-04-29")
