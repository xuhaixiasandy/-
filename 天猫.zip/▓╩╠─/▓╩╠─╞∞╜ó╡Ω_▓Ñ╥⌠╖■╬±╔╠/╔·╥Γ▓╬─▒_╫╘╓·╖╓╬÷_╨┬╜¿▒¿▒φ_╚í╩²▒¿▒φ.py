import time
import requests
import httpx
from loguru import logger
from pathlib import Path
import utils
from config import settings
from model import get_account
from datetime import datetime, timedelta


def send(params, cookies):
    headers = {
        'Host': 'sycm.taobao.com',
        'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-User': '?1',
        'Sec-Fetch-Dest': 'document',
        'Referer': 'https://sycm.taobao.com/cc/macroscopic_monitor',
        'Accept-Language': 'zh-CN,zh;q=0.9,zh-TW;q=0.8',
        'cookie': cookies
    }
    response = httpx.get(
        'https://sycm.taobao.com/adm/v2/downloadBySchema.do',
        headers=headers,
        params=params,
        timeout=10
    )
    return response.content


def crawler(username):
    account = get_account(username=username)
    if not account:
        logger.error(f"账号 {username} 不存在")
    cookies = account['cookies']['cookie_str']
    date_type = 'day'
    current_date = datetime.now().date() - timedelta(days=1)
    current_date_str = current_date.strftime("%Y-%m-%d")
    params = (
        ('name', '123123123'),
        ('dateType', f'{date_type}'),
        ('logicType', 'shop'),
        ('dimId', '1'),
        ('themeId', '1,2,3,4,5,6,7,8,9,10'),
        ('startDate', f'{current_date_str}'),
        # ('endDate', f'{current_date_str}'),
        ('isAutoUpdate', 'Y'),
        ('deviceType', '1,0,2'),
        ('indexCode',
         '1,2,5,116,117,118,132,133,134,142,143,144,153,154,155,162,163,164,171,172,173,180,181,182,189,190,191,198,199,200,207,208,209,216,217,218,225,226,227,234,235,236,243,244,245,252,253,254,261,262,263,270,271,272,279,280,281,288,289,290,297,298,299,306,307,308,309,310,311,324,325,326,333,334,335,342,371,372,378,383,403,404,405,407,408,409,410,412,413,414,415,519,570,571,572,588,589,590,597,598,599,606,607,608')
    )
    date_range = utils.before_day_date_range()
    account = get_account(username=username)
    if not account:
        logger.error(f"账号 {username} 不存在")

    name = f"【自助分析_新建报表_取数报表_报表1-{username.replace(':', '_')}-{date_range.replace('|', '_')}"
    path_str = Path(settings.LOG_DATA_FILE_PATH, f"{name}.xls").as_posix()
    if Path(path_str).is_file():
        logger.info(f"{name}文件已存在")
        return

    account = get_account(username=username)
    if not account:
        logger.error(f"账号 {username} 不存在")

    content = send(params, cookies)
    if b"5810" in content or b"DOCTYPE" in content:
        # 登录已经过期
        raise Exception("登录过期")
    if len(content) < 1 * 10 ** 4:
        raise Exception("文件内容过短")

    with open(path_str, mode="wb") as f:

        f.write(content)
        logger.info(f"保存文件 {path_str} 成功")


if __name__ == '__main__':
    crawler('彩棠旗舰店:播音服务商')

