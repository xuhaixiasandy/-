import 淘宝直播_数据_本店成交_合作直播间
import 淘宝直播_数据_本店成交_本店商品直播间成交
import 淘宝直播_数据_直播业绩_直播间大盘
import 淘宝直播_数据_直播间业绩_直播订单明细
import 热浪引擎_热浪引擎_推广数据总览_全部订单数据总览
import 生意参谋_业务专区_会员分析_会员分析
import 生意参谋_品类_品类360_品类排行
import 生意参谋_品类_商品360_流量来源_新版api
import 生意参谋_品类_商品排行
import 生意参谋_市场_市场大盘_行业趋势
import 生意参谋_市场_市场排行_商品_高交易
import 生意参谋_市场_市场排行_商品_高流量
import 生意参谋_流量_店铺来源_构成_流量来源构成
import 生意参谋_直播_直播概况
import 生意参谋_竞争_竞品分析_入店搜索词_引流关键词
import 生意经_宝贝分析
import 生意参谋_自助分析_新建报表_取数报表
import loguru


def main():
    username = '彩棠旗舰店:播音服务商'

    # 彩棠旗舰店:播音服务商 商品ID
    item_id_list = [
        609588171364,
        667552115438,
        632645548699,
        653225360063,
        672354805293,
        653442327868,
        703063163679,
        673586945239,
        617750332175,
        671126623119,
        694297647521,
        664734872013,
        705256411462,
        675434058870,
        696676022175,
    ]
    try:
        淘宝直播_数据_直播业绩_直播间大盘.crawler(username)
        淘宝直播_数据_本店成交_本店商品直播间成交.crawler(username)
        淘宝直播_数据_直播间业绩_直播订单明细.crawler(username)
        淘宝直播_数据_本店成交_合作直播间.crawler(username)
        热浪引擎_热浪引擎_推广数据总览_全部订单数据总览.crawler(username)
        生意参谋_直播_直播概况.crawler(username)
        生意参谋_自助分析_新建报表_取数报表.crawler(username)
        生意参谋_业务专区_会员分析_会员分析.crawler(username)
        生意参谋_品类_品类360_品类排行.crawler(username)
        生意参谋_市场_市场大盘_行业趋势.crawler(username)
        生意参谋_流量_店铺来源_构成_流量来源构成.crawler(username)
        生意参谋_品类_商品排行.crawler(username)
        生意参谋_品类_商品360_流量来源_新版api.crawler(username, item_id_list)
        生意参谋_市场_市场排行_商品_高交易.crawler(username)
        生意参谋_市场_市场排行_商品_高流量.crawler(username)
        生意参谋_竞争_竞品分析_入店搜索词_引流关键词.crawler(username, item_id_list)
        生意经_宝贝分析.crawler(username)
    except Exception as e:
        loguru.logger.error(f'采集失败{username}{e}')


if __name__ == "__main__":
    # convert：转换
    main()

