# -*- coding: utf-8 -*-
"""
模块说明：
    生意参谋-直播-本店商品成交(合作直播间，只要账号为李佳琦Austin的商品数据)
"""

import json
import time
import uuid
from datetime import timedelta, datetime

import requests
from loguru import logger

import model
from model import get_account
from helper import fetch_tbzb


def crawler(username):
    # username = "珀莱雅官方旗舰店:安好"
    account = get_account(username=username)
    if not account:
        logger.error(f"账号 {username} 不存在")

    cookies = account['cookies']['cookie_dict']

    current_date = datetime.now().date() - timedelta(days=1)
    current_date_str = current_date.strftime("%Y%m%d")

    csrf = uuid.uuid4().__str__()

    cookies.update(
        {
            'XSRF-TOKEN': csrf,
        }
    )
    headers = {
        'Host': 'hot.taobao.com',
        'sec-ch-ua': '"Chromium";v="110", "Not A(Brand";v="24", "Microsoft Edge";v="110"',
        'Accept': 'application/json, text/plain, */*',
        'X-XSRF-TOKEN': csrf,
        'sec-ch-ua-mobile': '?0',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edg/110.0.1587.41',
        'sec-ch-ua-platform': '"Windows"',
        'Origin': 'https://hot.taobao.com',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Referer': 'https://hot.taobao.com/hw/union/goods-alliance/databoard/overview',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
    }
    params = (
        ('_csrf', csrf),
    )
    data = {
        'period': '3',
        'planType': '0',
        'queryDate': current_date_str
    }
    response = requests.post('https://hot.taobao.com/commission/panel/shop/item/detail.do', headers=headers,
                             params=params, cookies=cookies, data=data, timeout=10)
    content = response.json()
    if content['msg'] != '成功':
        raise Exception(f'数据插入失败{content}')
    item = {
        "username": username,
        "source_data": content,
        "created_time": datetime.now(),
        "meta": {
            "tk_account": account,
            "data": data
        }
    }
    model.col_热浪引擎_热浪引擎_推广数据总览_全部订单数据总览.insert_one(item)
    logger.info(f"账号 {username} 采集成功")


if __name__ == '__main__':
    crawler('彩棠旗舰店:播音服务商')
