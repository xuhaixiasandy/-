import fire
from loguru import logger

from utils import convert_dict_to_cookie_string, convert_cookie_string_to_dict
from model import col_tk_account


def update_cookie(cookie_str):
    username = "彩棠旗舰店:播音服务商"
    c = convert_cookie_string_to_dict(cookie_str)
    # user_id 1 为测试
    col_tk_account.update_many(
        {
            "username": username,
        },
        {
            "$set": {
                "cookies": {
                    "cookie_dict": c,
                    "cookie_str": convert_dict_to_cookie_string(c),
                }
            }
        }
    )

    logger.info("成功添加cookie: {}".format(cookie_str))


if __name__ == '__main__':
    # fire.Fire(update_cookie)
    update_cookie(cookie_str='arms_uid=ad0d4193-d332-463b-8f65-8e79188af4f4; t=ac68f1b8db3c12aba8eda27a8457c8cf; cookie2=1bedac5e9043ed296381d7942b39b4df; _tb_token_=55e3557e8533e; _samesite_flag_=true; sgcookie=E100c%2Fy5WYTdD2vBCgG1HsSBv1d9TCxh7smU5oGVgAzB36DXbdDry4hH4CwRxJiERfP%2BNPlYD30t2S8%2FqV%2BoWClWV8%2FO3rkHgLkKbGuORMwNU2s%3D; unb=2215646694985; sn=%E5%BD%A9%E6%A3%A0%E6%97%97%E8%88%B0%E5%BA%97%3A%E6%92%AD%E9%9F%B3%E6%9C%8D%E5%8A%A1%E5%95%86; uc1=cookie21=Vq8l%2BKCLiYYu&cookie14=Uoe8j2RSI%2BQBuw%3D%3D; csg=9f649841; cancelledSubSites=empty; skt=e9a784c83dacbae2; _cc_=UIHiLt3xSw%3D%3D; _euacm_ac_l_uid_=2215646694985; 2215646694985_euacm_ac_c_uid_=2978671516; 2215646694985_euacm_ac_rs_uid_=2978671516; _portal_version_=new; cc_gray=1; v=0; cna=b+K6HD7gpj0CAXPjG1JPK8gR; XSRF-TOKEN=2ad6cc85-1b02-4a0b-8cb3-d57701c996ea; _euacm_ac_rs_sid_=236011924; _m_h5_tk=b44f7fc44e6c1022d3e9b2ad85839240_1685333470444; _m_h5_tk_enc=9b7e767afcf1d1f33aa82a592eb17834; xlly_s=1; JSESSIONID=E66257ABDEA454B944E607FC0596442F; isg=BC4uaQHSxm0zdDLOfBfSybZOf43wL_IpkgrC3Fj3kTHuO8-Vwb8ROTwy86_X4-pB; tfstk=cfgGBOgIvgfjxr8xdAa65YYwqQWcZmBLBmoE8IcUATB_Lz0FiJjF45A6KRpWQi1..; l=fBaHo3mqN_V7Ua75BOfZPurza77TjIRfguPzaNbMi9fPO8XX5LuRW1a8oO-WCnGNesZWJ3-i3zx2BMHWqzO-nxv9-QUoY1DmndhyN3pR.')