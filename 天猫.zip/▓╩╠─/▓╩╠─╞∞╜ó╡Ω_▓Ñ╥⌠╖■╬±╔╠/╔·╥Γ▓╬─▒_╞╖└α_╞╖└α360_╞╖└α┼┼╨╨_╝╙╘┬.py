import time

import httpx
from loguru import logger
from pathlib import Path

import utils
from config import settings
from model import get_account


def send(params, cookies):
    headers = {
        'Host': 'sycm.taobao.com',
        'sec-ch-ua': '"Chromium";v="110", "Not A(Brand";v="24", "Microsoft Edge";v="110"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edg/110.0.1587.57',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-User': '?1',
        'Sec-Fetch-Dest': 'document',
        'Referer': 'https://sycm.taobao.com/cc/new_cate_archives?spm=a21ag.12100465.LeftMenu.d2172.5f3450a560wos5',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        'cookie': cookies
    }
    response = httpx.get(
        'https://sycm.taobao.com/cc/cockpit/marcro/excel/cate.json',
        headers=headers,
        params=params,
        timeout=10
    )
    return response.content


def crawler(username):
    date_range = utils.before_month_date_range()
    name = f"【生意参谋_品类_品类360_品类排行-{username.replace(':', '_')}-{date_range.replace('|', '_')}"
    path_str = Path(settings.LOG_DATA_FILE_PATH, f"{name}.xls").as_posix()
    if Path(path_str).is_file():
        logger.info(f"{name}文件已存在")
        return

    # 获取cookie
    # username = "珀莱雅官方旗舰店:安好"
    account = get_account(username=username)
    if not account:
        logger.error(f"账号 {username} 不存在")
    cookies = account['cookies']['cookie_str']

    params = (
        ('dateRange', f'{date_range}'),
        ('dateType', 'month'),
        ('pageSize', '10'),
        ('page', '1'),
        ('order', 'desc'),
        ('orderBy', 'payAmt'),
        ('dtUpdateTime', 'false'),
        ('follow', 'false'),
        ('cateType', 'std'),
        ('indexCode', 'payAmt,payAmtRatio,sucRefundAmt,payRate,itmUv'),
    )
    # print(params)
    params = dict(params)
    content = send(params=params, cookies=cookies)

    if b"5810" in content or b"DOCTYPE" in content:
        # 登录已经过期
        raise Exception("登录过期")

    with open(path_str, mode="wb") as f:
        f.write(content)
        logger.info(f"保存文件 {path_str} 成功")



if __name__ == '__main__':
    crawler('珀莱雅官方旗舰店:安好')