"""
包含两个数据模块：
    日度自播数据 -- 生意参谋-直播-直播间业绩-直播间大盘
    日度自播数据 -- 自播（有退款）-天猫商家后台-内容运营中心-淘宝直播
    日度自播数据 -- 生意参谋-直播-直播概况
"""

import json
import time
from pprint import pprint
from datetime import datetime, timedelta

from loguru import logger

import model
from model import get_account
from helper import fetch_tbzb, slider_get, slider_action_v2


def crawler(username):
    account = get_account(username=username)
    if not account:
        logger.error(f"账号 {username} 不存在")

    current_date = datetime.now().date() - timedelta(days=1)
    new_date = current_date - timedelta(days=30)

    cookies = account['cookies']['cookie_dict']
    # x5sec = slider_get("h5api.m.taobao.com")
    # cookies['x5sec'] = x5sec

    params = {
        'beginDate': f'{new_date.strftime("%Y%m%d")}',
        'dataQRFormId': 'live_overview_dashboard',
        'endDate': f'{current_date.strftime("%Y%m%d")}',
        'orderColumn': 'ds',
        'orderType': '1',
        'queryUserRole': 'ALL',
        'time': int(time.time() * 1000)
    }
    data = {
        'dataApi': 'dataQRForm',
        'param': json.dumps(params)
    }
    text = fetch_tbzb(data, cookies)
    if "x5secdata" in text:
        logger.info(f"滑块验证: {json.loads(text)['data']['url']}")
        slider_action_v2(json.loads(text)['data']['url'])
        time.sleep(10)
    content = json.loads(text)
    if content['ret'][0] != "SUCCESS::调用成功":
        raise Exception(f'数据插入失败{content}')
    assert content['data']['result'][0]['payAmt']
    item = {
        "username": username,
        "source_data": content,
        "created_time": datetime.now(),
        "meta": {
            "tk_account": account
        }
    }
    model.col_淘宝直播_数据_直播业绩_直播间大盘.insert_one(item)
    logger.info(f"插入数据成功: {username}")


if __name__ == '__main__':
    crawler('彩棠旗舰店:播音服务商')
