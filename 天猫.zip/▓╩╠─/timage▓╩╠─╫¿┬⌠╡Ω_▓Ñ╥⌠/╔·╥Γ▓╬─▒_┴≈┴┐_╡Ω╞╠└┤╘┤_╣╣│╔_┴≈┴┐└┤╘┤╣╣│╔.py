import time

import httpx
from loguru import logger
from pathlib import Path

import utils
from config import settings
from model import get_account


def send(params, cookies):
    headers = {
        'Host': 'sycm.taobao.com',
        'sec-ch-ua': '"Chromium";v="110", "Not A(Brand";v="24", "Microsoft Edge";v="110"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edg/110.0.1587.63',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-User': '?1',
        'Sec-Fetch-Dest': 'document',
        'Referer': 'https://sycm.taobao.com/flow/monitor/shopsource/construction?belong=all&dateRange=2023-03-04%7C2023-03-04&dateType=day&device=2&rivalUser1Id=&spm=a21ag.8198212.LeftMenu.d603.596250a5n9dyQr',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        'cookie': cookies
    }
    response = httpx.get(
        'https://sycm.taobao.com/flow/gray/excel.do',
        headers=headers,
        params=params,
        timeout=10
    )
    return response.content


def crawler(username):
    # 生成文件名
    date_range = utils.before_day_date_range()
    name = f"生意参谋_流量_店铺来源_构成_流量来源构成_{username.replace(':', '_')}-{date_range.replace('|', '_')}"
    path_str = Path(settings.LOG_DATA_FILE_PATH, f"{name}.xls").as_posix()
    if Path(path_str).is_file():
        logger.info(f"{name}文件已存在")
        return

    # 获取cookie
    # username = "珀莱雅官方旗舰店:安好"
    account = get_account(username=username)
    if not account:
        logger.error(f"账号 {username} 不存在")
    cookies = account['cookies']['cookie_str']

    params = (
        ('_path_', 'v4/excel/shop/source/v3'),
        ('device', '2'),
        ('dateType', 'day'),
        ('dateRange', f'{date_range}'),
        ('belong', 'all'),
    )

    content = send(params=params, cookies=cookies)

    if b"5810" in content or b"DOCTYPE" in content:
        # 登录已经过期
        raise Exception("登录过期")
    if len(content) < 1 * 10 ** 4:
        raise Exception("文件内容过短")

    with open(path_str, mode="wb") as f:
        f.write(content)
        logger.info(f"保存文件 {path_str} 成功")


if __name__ == '__main__':
    crawler('timage彩棠专卖店:播音')
