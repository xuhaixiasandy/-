"""
模块说明：
    生意参谋-直播-本店商品成交(合作直播间，只要账号为李佳琦Austin的商品数据)
"""

import json
import time
import uuid
from datetime import timedelta, datetime

import requests
from loguru import logger

import model
import crypt_utils
from model import get_account
from helper import fetch_tbzb
from utils import send_slider_url


def crawler(username: str):
    for cate in [
        {
            "cate_id": "125458001",
            "cate_name": "CC霜",
            "level": 2
        },
        {
            "cate_id": "50010814",
            "cate_name": "其它彩妆",
            "level": 2
        },
        {
            "cate_id": "201166702",
            "cate_name": "唇部彩妆",
            "level": 2
        },
        {
            "cate_id": "50010807",
            "cate_name": "唇彩/唇蜜/唇釉",
            "level": 0
        },
        {
            "cate_id": "50010801",
            "cate_name": "唇笔/唇线笔",
            "level": 0
        },
        {
            "cate_id": "50010808",
            "cate_name": "唇膏/口红",
            "level": 0
        },
        {
            "cate_id": "201161605",
            "cate_name": "彩妆套装（新）",
            "level": 2
        },
        {
            "cate_id": "121452004",
            "cate_name": "彩妆套装",
            "level": 0
        },
        {
            "cate_id": "121388008",
            "cate_name": "彩妆盘",
            "level": 0
        },
        {
            "cate_id": "121398006",
            "cate_name": "指甲油/美甲产品（新）",
            "level": 2
        },
        # 1
        {
            "cate_id": "125172008",
            "cate_name": "旅行装/体验装",
            "level": 2
        },
        {
            "cate_id": "201161714",
            "cate_name": "眼部彩妆",
            "level": 2
        },
        {
            "cate_id": "50010798",
            "cate_name": "眉笔/眉粉/眉膏",
            "level": 0
        },
        {
            "cate_id": "50010796",
            "cate_name": "眼影",
            "level": 0
        },
        {
            "cate_id": "50010797",
            "cate_name": "眼线",
            "level": 0
        },
        {
            "cate_id": "50010794",
            "cate_name": "睫毛膏",
            "level": 0
        },
        {
            "cate_id": "122438001",
            "cate_name": "美容工具",
            "level": 2
        },
        {
            "cate_id": "50010817",
            "cate_name": "化妆/美容工具",
            "level": 0
        },
        {
            "cate_id": "121400018",
            "cate_name": "化妆套刷",
            "level": 0
        },
        {
            "cate_id": "121460005",
            "cate_name": "美甲工具",
            "level": 2
        },
        {
            "cate_id": "201164006",
            "cate_name": "面部彩妆",
            "level": 0
        },
        {
            "cate_id": "50013794",
            "cate_name": "BB霜",
            "level": 0
        },
        {
            "cate_id": "201310801",
            "cate_name": "定妆喷雾",
            "level": 0
        },
        {
            "cate_id": "50010789",
            "cate_name": "粉底液/膏",
            "level": 0
        },
        {
            "cate_id": "50010790",
            "cate_name": "粉饼",
            "level": 0
        },
        {
            "cate_id": "50010805",
            "cate_name": "腮红/胭脂",
            "level": 0
        },
        {
            "cate_id": "50010792",
            "cate_name": "蜜粉/散粉",
            "level": 0
        },
        {
            "cate_id": "50010803",
            "cate_name": "遮瑕",
            "level": 0
        },
        {
            "cate_id": "121388007",
            "cate_name": "阴影",
            "level": 0
        },
        {
            "cate_id": "121426007",
            "cate_name": "隔离/妆前",
            "level": 0
        },
        {
            "cate_id": "121382014",
            "cate_name": "高光",
            "level": 0
        },
        {
            "cate_id": "201834201",
            "cate_name": "香水/香水用品",
            "level": 2
        }
    ]:
        # username = "珀莱雅官方旗舰店:安好"
        account = get_account(username)
        if not account:
            logger.error(f"账号 {username} 不存在")

        cookies = account['cookies']['cookie_dict']
        current_date = datetime.now().date() - timedelta(days=1)
        current_date_str = current_date.strftime("%Y-%m-%d")
        if model.col_生意参谋_市场_市场排行_商品_高流量.count_documents(
                {
                    "cate_id": cate["cate_id"],
                    'meta.data.dateRange': f'{current_date_str}|{current_date_str}',
                    'meta.tk_account.username': username
                }
        ):
            logger.info(f"已经存在: {cate}")
            continue

        headers = {
            'Host': 'sycm.taobao.com',
            'sec-ch-ua': '"Chromium";v="110", "Not A(Brand";v="24", "Microsoft Edge";v="110"',
            'bx-umidtoken': 'GCDFCD72C133ABE68E1FBCD2EE213DB54217154D228CF8CB908',
            'sec-ch-ua-mobile': '?0',
            'bx-ua': '225!NNvLBozWooizC8U7toEoV+dXi+ljrDwFaQ/N+b478XebsVTsLgon/F3LG6LaI9cERL8L3e8rhdMW5KfINrJeD/eNgoBVI/+AircaaWmjgs5IXZGOAnh+z4poQzadDIf4fjdNbUDKjeI4oL3jDGHzfeGeui9r/8HCuEzt0dDGjObvoLFXDBmzfefrQEDdDMXSkNvgofDdjxfhoeijDlH+j7hQuo01K/+zMCB3HfiSYsE3HnuE5Ig4AcclWTMke5d4fiFRGULQjcI4oJijDlH+fej0Bz0KDIFE5LLHbZSNw8Ihn9oig+Ju7gRIvuG8ey/6uz1aFvlqPBdL49hJHjdv7ejWW3DNVBtcGtdbZzVOM2rT5MxFy+LPx4SCvWwCgy7ICfF5FISAABribbqKyd/IBh9fpTwvgH+8pZPF+m466rB4e4j9HGEz77BrQE0KDM5hfDm6b34djxI4WusbIRTKKvSVtS6pSRKW8R7YO30jQofYqM3bmtR+ZLO96+B9BXSNKGssCnuY0dfWmMNzeo9BXTGGAq2vBFa31Q3Qv/1UxDmKVeaahXMzK0+QtMceDzbIX1R1Mv807QfwidYcGH7ZxWHhIZ9VLyKkpDLYR4TYhQRzob71IrEuBDIikxk8U2Yz/C+uA+pMHUnrDby1Zkl5Hzq6g83C1Xv2QNxjcTAQGyCvmYF3U8lwbABMeQOivA5ddwqoLYMr29giRaqBN4wRW+e+5aC9edkEVDWS9qk4nOUeie+LwzytDqo3OC1e5HfTxd73azVjzOXRKf+EkXlR3Vh30RXoGet3om+QTqi3eU/M1gnR5+cIEDz2jIRVnrSdWOvv3fNVXrkU5P/Ljylo3jMY7kVXRtNRZtD3VKOKb3nGUUXfxiqnPXbejSELxqQo0t0MSusXGmXPJjL9EO6b5lgInXnvzbpZKYmDNsMfejGh3fJKQsI6pTlqxpd00X5IYfgiwxkStbZOdBKgmmFPbCsgZ6B6niPunYXM38Cf4qwXDBLHyQhBTg30RrAYv3oQFiovG/v8nlhEs/h2DaWMhQzZtDpamCadKIHNeGdTTgCvHrgBHPwIGAWUETJoPs8wQlxsEFUFNop9WHvUTSFDwwLuH68r6OaFNWvADunxDJ9gmckLtCCEKAHRTLi/ZyOl+LxAhJQw3YrQWsQMMcQZRjY5mypUeRf/1HKLouW0bA2wtbohlRjxGy215JFbRuC47sWHavHPVWtNrusXDGGBiuqp',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edg/110.0.1587.63',
            'Transit-Id': 'HLwhanUURYz2tVr4FVUfhQu6ZZLyBR8cWZ+jULbDryAigDPSXtLUW+HrrC/400f4rHZ8fOe/PIBe0it4ntIqVrWaEqmUGJFmYB6ppvjG7GBHV/pMMoojq8FTSp8FlRQnbTaLDaTDjr4yKYPdSDCk7BuEMrz+qoECjT9TDYDgzok=',
            'Sycm-Referer': '/mc/mq/market_rank',
            'bx-v': '2.2.3',
            'Onetrace-Card-Id': 'sycm-mc-mq-market-rank.sycm-mc-mq-item-item-search',
            'Sycm-Query': 'dateType=day&activeKey=item',
            'sec-ch-ua-platform': '"Windows"',
            'Accept': '*/*',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': f'https://sycm.taobao.com/mc/mq/market_rank?activeKey=item&cateFlag=1&cateId={cate["cate_id"]}&dateRange={current_date_str}%7C{current_date_str}&dateType=day&sellerType=-1&spm=a21ag.11815228.LeftMenu.d591.7e2650a5uPilgt',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        }
        params = (
            ('dateRange', f'{current_date_str}|{current_date_str}'),
            ('dateType', 'day'),
            ('pageSize', '10'),
            ('page', '1'),
            ('order', 'desc'),
            ('orderBy', 'uvIndex'),
            ('cateId', f'{cate["cate_id"]}'),
            ('device', '0'),
            ('sellerType', '-1'),
            ('styleId', ''),
            ('priceSeg', ''),
            ('priceSegName', ''),
            ('pageId', ''),
            ('minPrice', ''),
            ('maxPrice', ''),
            ('sex', ''),
            ('sexRatio', ''),
            ('age', ''),
            ('ageRatio', ''),
            ('indexCode', 'uvIndex,seIpvUvHits,tradeIndex'),
            ('_', f'{int(time.time() * 1000)}'),
            ('token', 'bd414fbfb'),
        )
        response = requests.get(
            'https://sycm.taobao.com/mc/v2/mq/mkt/rank/item/hotsearch.json',
            headers=headers,
            params=params,
            cookies=cookies,
            timeout=10
        )
        if "statDate" in response.text:
            logger.error(f'[{username}] {cate["cate_name"]} {current_date_str} 交易指数排行榜抓取失败')
            logger.error(response.text)
            time.sleep(90)
            continue
        content = send_slider_url(response)
        if "操作成功" not in response.text:
            raise Exception(f"采集失败{response.text}")
        item = {
            "username": username,
            "source_data": content,
            "cate_id": cate["cate_id"],
            "created_time": datetime.now(),
            "meta": {
                "tk_account": account,
                "data": dict(params),
                "tk": cate
            }
        }
        model.col_生意参谋_市场_市场排行_商品_高流量.insert_one(item)
        logger.info(f'[{username}] {cate["cate_name"]} {current_date_str} 交易指数排行榜抓取成功')
        time.sleep(90)


if __name__ == '__main__':
    crawler("timage彩棠专卖店:播音")
