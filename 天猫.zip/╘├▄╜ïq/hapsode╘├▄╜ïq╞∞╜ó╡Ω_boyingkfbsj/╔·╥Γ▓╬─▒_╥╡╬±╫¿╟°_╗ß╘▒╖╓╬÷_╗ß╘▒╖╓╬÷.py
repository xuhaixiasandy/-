"""
模块说明：
    生意参谋-直播-本店商品成交(合作直播间，只要账号为李佳琦Austin的商品数据)
"""

import json
import time
import uuid
from datetime import timedelta, datetime

import requests
from loguru import logger

import model
from model import get_account
from helper import fetch_tbzb
from utils import DateRange
import asyncio


def crawler(username, date: str):
    # username = "珀莱雅官方旗舰店:安好"
    account = get_account(username=username)
    if not account:
        logger.error(f"账号 {username} 不存在")

    cookies = account['cookies']['cookie_dict']
    date_str = date
    headers = {
        'Host': 'sycm.taobao.com',
        'sec-ch-ua': '"Chromium";v="110", "Not A(Brand";v="24", "Microsoft Edge";v="110"',
        'sec-ch-ua-mobile': '?0',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edg/110.0.1587.57',
        'Sycm-Referer': '/xsite/flagship/member.htm',
        'bx-v': '2.2.3',
        'Onetrace-Card-Id': 'sycm-oneness-page-flagship-member.sycm-oneness-page-flagship-member',
        'Sycm-Query': 'dateType=recent7',
        'sec-ch-ua-platform': '"Windows"',
        'Accept': '*/*',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Referer': f'https://sycm.taobao.com/xsite/flagship/member.htm?dateRange={date_str}%7C{date_str}&dateType=recent7&spm=a21ag.13491718.LeftMenu.d380.1c5150a54hZxo7',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
    }
    params = (
        ('dateType', 'recent1'),
        ('dateRange', f'{date_str}|{date_str}'),
        ('_', f'{int(time.time() * 1000)}'),
        ('token', '26a2fa8c4'),
    )
    response = requests.get(
        'https://sycm.taobao.com/xsite/flagShip/member/overview.json',
        headers=headers,
        params=params,
        cookies=cookies,
        timeout=10
    )
    content = response.json()
    item = {
        "username": username,
        "source_data": content,
        "created_time": datetime.now(),
        "meta": {
            "tk_account": account,
            "data": dict(params)
        }
    }
    model.col_生意参谋_业务专区_会员分析_会员分析.insert_one(item)
    logger.info(f"账号 {username} 采集成功")
    time.sleep(90)


if __name__ == '__main__':
    crawler("hapsode悦芙媞旗舰店:boyingbsj", "2023-01-11")
