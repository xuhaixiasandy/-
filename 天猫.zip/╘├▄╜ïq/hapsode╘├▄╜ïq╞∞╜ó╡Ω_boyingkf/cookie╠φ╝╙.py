import fire
from loguru import logger

from utils import convert_dict_to_cookie_string, convert_cookie_string_to_dict
from model import col_tk_account
import pprint


def update_cookie(cookie_str):
    username = "hapsode悦芙媞旗舰店:boyingkf"
    c = convert_cookie_string_to_dict(cookie_str)
    # user_id 1 为测试
    col_tk_account.update_many(
        {
            "username": username,
        },
        {
            "$set": {
                "cookies": {
                    "cookie_dict": c,
                    "cookie_str": convert_dict_to_cookie_string(c),
                }
            }
        }
    )

    logger.info("成功添加cookie: {}".format(cookie_str))


if __name__ == '__main__':
    # fire.Fire(update_cookie)
    # update_cookie()
    res = convert_cookie_string_to_dict('_ga=GA1.1.1374759597.1685935101; _clck=133nscf|2|fc7|0|1251; _clsk=13u3pzn|1685935101914|1|1|o.clarity.ms/collect; _ga_R0N8N5VGXX=GS1.1.1685935100.1.1.1685935113.0.0.0; dsy_lg_tp=1; Hm_lvt_10d04bfe4defa9232fe38f7e9a7e9567=1685935100,1686019868; session=0062787a-0415-11ee-84ec-00163e16e2df; lg_tp=2; remember_token=$2b$10$bWETjzdbJ4/gDUekbphlM.uRCe4ibTAdTg0bStiZw18yoM2AooIDe|ba2f8d48575f4a5ada2460a1aa251cdc978cdcbe4de9eba7f8955f0a255bde41c007c1e38af0b9a004512371829c8ed4a0c3909b6765e84c52c7e922dc366c7f; CSRFToken=ImEzMTFmNDAwOGU5ZjQ3NTdmNGZhYzc1ZjY5MGIyMGQwOTIxZDVhYjIi.ZH6fMA.3dUzZ64PUwoprFxjPxOctKHUhag; token=7acab102c2; sidebarStatus=0; Hm_lpvt_10d04bfe4defa9232fe38f7e9a7e9567=1686019900')
    pprint.pprint(res)