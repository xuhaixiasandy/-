import requests

"""
模块说明：
    生意参谋-直播-本店商品成交(合作直播间，只要账号为李佳琦Austin的商品数据)
"""

import json
import time
import uuid
from datetime import timedelta, datetime

import requests
from loguru import logger

import model
import crypt_utils
from model import get_syj_account
from helper import fetch_tbzb


def crawler(username):
    # username = "hapsode悦芙媞旗舰店:boyingkf"
    account = get_syj_account(username=username)
    if not account:
        logger.error(f"账号 {username} 不存在")

    cookies = account['cookies']['cookie_dict']

    current_date = datetime.now().date() - timedelta(days=1)
    current_date_str = current_date.strftime("%Y%m%d")

    headers = {
        'Host': 'f2.shengejing.com',
        'sec-ch-ua': '"Chromium";v="110", "Not A(Brand";v="24", "Microsoft Edge";v="110"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edg/110.0.1587.63',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-User': '?1',
        'Sec-Fetch-Dest': 'document',
        'Referer': 'https://f0.shengejing.com/index.php?tab=12',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
    }

    params = (
        ('type', 'baobeitrans'),
        ('dd', f'{current_date_str}'),
        ('onsale', ''),
        ('starred_iids', ''),
        ('cid', ''),
        ('seller_cid', ''),
        ('group', ''),
        ('ext', 'false'),
    )
    response = requests.get(
        'https://f0.shengejing.com/download.php',
        headers=headers,
        params=params,
        cookies=cookies,
        timeout=10
    )
    text = response.text
    if ("<html>" and "</html>") in text:
        raise Exception(f'采集失败{text}')
    item = {
        "username": username,
        "source_data": text,
        "created_time": datetime.now(),
        "meta": {
            "tk_account": account,
            "data": dict(params),
        }
    }
    model.col_生意经_宝贝分析.insert_one(item)
    logger.info(f"账号 {username} 宝贝分析数据爬取成功")


if __name__ == '__main__':
    crawler('hapsode悦芙媞旗舰店:boyingkf')
