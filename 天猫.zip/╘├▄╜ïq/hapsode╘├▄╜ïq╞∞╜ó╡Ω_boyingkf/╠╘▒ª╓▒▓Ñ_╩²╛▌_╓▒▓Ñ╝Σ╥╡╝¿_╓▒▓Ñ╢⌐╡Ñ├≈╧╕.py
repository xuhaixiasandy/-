"""
数据模块：
    日度自播数据 -- 产品-自播（计算退款)-天猫商家后台-内容运营中心-淘宝直播
"""

import json
import time
from datetime import timedelta, datetime
from pprint import pprint

from loguru import logger

import model
from model import get_account
from helper import fetch_tbzb


def crawler(username):
    account = get_account(username=username)
    if not account:
        logger.error(f"账号 {username} 不存在")

    cookies = account['cookies']['cookie_dict']

    end_date = datetime.now().date() - timedelta(days=1)
    begin_date = end_date - timedelta(days=1)

    params = {
        'beginTime': f'{begin_date} 00:00:00',
        'dataQRFormId': 'live_overview_order',
        'endTime': f'{end_date} 23:59:59',
        'hit': '5000',
        'itemId': None,
        'itemTitle': None,
        'orderColumn': 'pay_time',
        'orderDateType': '3',
        'orderId': None,
        'orderIds': None,
        'orderType': '1',
        'queryUserRole': 'ALL',
        'start': '0',
        'time': int(time.time() * 1000)
    }

    data = {'dataApi': 'dataQRForm',
            'param': json.dumps(params)}
    text = fetch_tbzb(data, cookies)
    content = json.loads(text)
    if content['ret'][0] != "SUCCESS::调用成功":
        raise Exception(f'数据插入失败{content}')
    item = {
        "username": username,
        "source_data": content,
        "created_time": datetime.now(),
        "meta": {
            "tk_account": account
        }
    }
    model.col_淘宝直播_数据_直播间业绩_直播订单明细.insert_one(item)
    logger.info(f"直播间商品订单采集成功: {username}")


if __name__ == '__main__':
    crawler('hapsode悦芙媞旗舰店:boyingkf')
