"""
模块说明：
    生意参谋-直播-本店商品成交(合作直播间，只要账号为李佳琦Austin的商品数据)
"""

import json
import time
import uuid
from datetime import timedelta, datetime

import requests
from loguru import logger

import model
import crypt_utils
from model import get_account
from helper import fetch_tbzb
from utils import send_slider_url


def crawler(username: str):
    for cate in [
        {
            "cate_id": "50011993",
            "cate_name": "面部护理套装",
            "level": 0
        },
        {
            "cate_id": "201174001",
            "cate_name": "面部精华（新）",
            "level": 2
        },
        {
            "cate_id": "50011980",
            "cate_name": "乳液/面霜",
            "level": 0
        },
        {
            "cate_id": "121390006",
            "cate_name": "面膜（新）",
            "level": 2
        },
        {
            "cate_id": "201173303",
            "cate_name": "防晒（新）",
            "level": 2
        },
        {
            "cate_id": "50011978",
            "cate_name": "化妆水/爽肤水",
            "level": 0
        },
        {
            "cate_id": "50011977",
            "cate_name": "洁面",
            "level": 0
        },
        {
            "cate_id": "121454013",
            "cate_name": "眼部护理（新）",
            "level": 2
        },
        {
            "cate_id": "121466009",
            "cate_name": "身体护理（新）",
            "level": 2
        },
        {
            "cate_id": "50011990",
            "cate_name": "卸妆",
            "level": 0
        },
        {
            "cate_id": "121390007",
            "cate_name": "手部保养（新）",
            "level": 2
        },
        {
            "cate_id": "201850303",
            "cate_name": "身体清洁(新）",
            "level": 2
        },
        {
            "cate_id": "50011997",
            "cate_name": "面部磨砂/去角质",
            "level": 0
        },
    ]:
        account = get_account(username)
        if not account:
            logger.error(f"账号 {username} 不存在")

        cookies = account['cookies']['cookie_dict']

        current_date = datetime.now().date() - timedelta(days=1)
        current_date_str = current_date.strftime("%Y-%m-%d")

        if model.col_生意参谋_市场_市场大盘_行业趋势.count_documents(
                {
                    "cate_id": cate["cate_id"],
                    'meta.data.dateRange': f'{current_date_str}|{current_date_str}',
                    'meta.tk_account.username': username
                }
        ):
            logger.info(f"已经存在: {cate}")
            continue

        headers = {
            'Host': 'sycm.taobao.com',
            'sec-ch-ua': '"Chromium";v="110", "Not A(Brand";v="24", "Microsoft Edge";v="110"',
            'bx-umidtoken': 'G772F3FA9C57A0F45591ED16C222DD254D684756E77863360D9',
            'sec-ch-ua-mobile': '?0',
            'bx-ua': '225!N7BFkizWooizlOApDiioV+dXi+ljrDwFaQ/N+564wv6Qn7dHUDJQUJHwbOYKKFf8Qa43OFWBE+AqvTxDvRka9VnKSa1QlrsSVlFhmPOR3WZCFVh+zhioQzadDIf4fjdNbUDKjeI4oL3jDGHzfeGeui9r/8HCuEzt0dDGjObvoLFXDBmzfefrQEDdDMXSkNvgofDdjxfhoeijDlH+j7hQuo01K/+zMCB3HfiSYsE3HnuE5Ig4AcclWTMke5d4fiFRGULQjcI4oJijDlH+fej0Bz0KDIFE5LLHbZSNw8Ihn9oig+Ju7gRIvuG8ey/6uz1aFvlqPBdL49hJHjdv7ejWW3DNVBtcGtdbZzVOM2rT5MxFy+LPx4SCvWwCgy7ICfF5FISAABribbqKyd/IBh9fpTwvgH+8pZPF+m466rB4e4j9HGEz77BrQE0KDM5hfDm6b34djxI4Wu+aGkaUKOWeE96pSRKW/QxSiM1ZvZYRh24p+LN16v8l7ZdYoncCRv+HCbAg5mBIIW6WumxI26XIoQHSG4NEen0vphS4DbwtIifcoR/w8lAXE3iIbIcM4AVAj/r4rU0s/4K7uAnZfbuvtdNWqwUF2hFTyFJhijzXcM7lcLGhfKvhhRV55DmKk29BEFy40WKPAjMATEnQWZn5k84MieURaSq3mpYmmsV2XR+jBVN4qplYc/ScYJMF/tRt7cB07mllTTgObcqdtVEIWihKtOn0ci3pvgLoOouo2jaoD/Fj+6oCwSk2Ee7HEVfVEtbuBhurRGJhjrom7/Z2a20JcBFZrNitaW3I/KWpmSL+V2jq/u9UvMZfm8OsszaLhYEF60kJ51nGl5TTOWzbKEoS4QEt8PuYSRzs7HRPEfj2Ky1tu0T5eEtSmonPa9CHT2594YRWzrIJh9/CDjDZj6FSqZ3rCN35CwcYcUnMzUm3FZ4p2KpoJqK8YfPY8fR4d/rPNWJOPmRW7/GrmA8dAHcxHVBMUVGny0Os/aKwtyz6rLKI7aFjYHGZnIPJEXCjdbOtG+yAn8FIMG4euxNL23bGSvkI/noekNAWwuLidVBb7U0HG3zwLerjYOgvtJxWh8ZpQeRthwy6yixG4OUDXHXrqiIC5yXzyCNCZ1d1ZdX3OmA+Vcjczh1SRKcYr6LTaXAFdZg4WDTp1+tvx8ezl+oGnFaFtdHYI0AXOkddAhrk5kvU2RrsOQS5EB2QhOuiFKWw7f6SaMBvzllrohrk',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edg/110.0.1587.63',
            'Transit-Id': 'BsESCAieTjZGWCHb9vAXOJN9RNDchRNXwxx1ipiVAUjp6kyHcRyB5N+p65pelTkcLG6p7ve0Wu80HCw13Y4K6+nCV3HOS8VtFVKSy+/ZJHhaSp9YUlcq/jHE17Yjju0yQAxoxV4TKdZiwn/drqGxCUnRKC9sl2xKqcu2h4Sp6B0=',
            'Sycm-Referer': '/mc/mq/overview',
            'bx-v': '2.2.3',
            'Onetrace-Card-Id': 'sycm-mc-mq-market-overview.sycm-mc-mq-cate-trend',
            'Sycm-Query': 'dateType=week',
            'sec-ch-ua-platform': '"Windows"',
            'Accept': '*/*',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': f'https://sycm.taobao.com/mc/mq/overview?cateFlag=1&cateId={cate["cate_id"]}&dateRange={current_date_str}%7C{current_date_str}&dateType=day&sellerType=-1&spm=a21ag.11815228.LeftMenu.d590.7e2650a559ttEj',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        }
        params = (
            ('dateType', 'day'),
            ('dateRange', f'{current_date_str}|{current_date_str}'),
            ('cateId', f'{cate["cate_id"]}'),
            ('device', '0'),
            ('sellerType', '-1'),
            ('_', f'{int(time.time() * 1000)}'),
            ('token', '4f7376b6f'),
        )
        response = requests.get(
            'https://sycm.taobao.com/mc/mq/supply/mkt/overview.json',
            headers=headers,
            params=params,
            cookies=cookies,
            timeout=10,
        )
        content = send_slider_url(response)
        content = json.loads(crypt_utils.data_decrypt(content['data']))
        item = {
            "username": username,
            "cate_id": cate["cate_id"],
            "source_data": content,
            "created_time": datetime.now(),
            "meta": {
                "tk_account": account,
                "data": dict(params),
                "tk": cate
            }
        }
        model.col_生意参谋_市场_市场大盘_行业趋势.insert_one(item)
        logger.info(f"采集成功: {cate}")
        time.sleep(90)


if __name__ == '__main__':
    crawler('hapsode悦芙媞旗舰店:boyingkf')
