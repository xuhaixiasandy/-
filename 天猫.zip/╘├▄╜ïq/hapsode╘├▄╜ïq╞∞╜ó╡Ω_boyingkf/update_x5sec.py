from model import mg_client
import requests
from loguru import logger
import json


db_bly_tm_cf = mg_client['bly_tm_cf']
db_bolaiya = mg_client['bolaiya']
db_mh = mg_client['mh']
db_huaxi = mg_client['huaxi']


def update(x5sec, mg_collect):
    for i in mg_collect['tk_account'].find({}):
        cookies = i['cookies']
        cookies['cookie_dict']['x5sec'] = x5sec

        if "x5sec" in cookies['cookie_str']:
            for x5sec_str in cookies['cookie_str'].split(";"):
                if "x5sec" in x5sec_str:
                    cookies['cookie_str'].replace(x5sec_str, f"x5sec={x5sec}")
        else:
            cookies['cookie_str'] = f"{cookies['cookie_str']}; x5sec={x5sec};"

        mg_collect['tk_account'].update_one(
            {
                "_id": i['_id']
            },
            {
                "$set": {
                    "cookies": cookies
                }
            }
        )


# http://39.175.169.130:15555/taobaosecret/ali/slider/x5sec/cookie/v1?domain=sycm.taobao.com
def get_x5sec():
    req = requests.get("http://39.175.169.130:15555/taobaosecret/ali/slider/x5sec/cookie/v1?domain=sycm.taobao.com")
    x5sec = json.loads(req.text)
    logger.info(f'x5sec:{x5sec}更新成功')
    if x5sec['data'] is None:
        raise Exception('更新失败')
    return x5sec['data']


def main():
    x5sec = get_x5sec()
    if x5sec:
        update(x5sec, db_bly_tm_cf)
        update(x5sec, db_bolaiya)
        update(x5sec, db_mh)
        update(x5sec, db_huaxi)


if __name__ == '__main__':
    main()
