from model import get_username
import 淘宝直播_数据_本店成交_合作直播间
import 淘宝直播_数据_本店成交_本店商品直播间成交
import 淘宝直播_数据_直播业绩_直播间大盘
import 淘宝直播_数据_直播间业绩_直播订单明细
import 热浪引擎_热浪引擎_推广数据总览_全部订单数据总览
import 生意参谋_业务专区_会员分析_会员分析
import 生意参谋_品类_品类360_品类排行
import 生意参谋_品类_商品360_流量来源_新版api
import 生意参谋_品类_商品排行
import 生意参谋_市场_市场大盘_行业趋势
import 生意参谋_市场_市场排行_商品_高交易
import 生意参谋_市场_市场排行_商品_高流量
import 生意参谋_流量_店铺来源_构成_流量来源构成
import 生意参谋_直播_直播概况
import 生意参谋_竞争_竞品分析_入店搜索词_引流关键词
import 生意经_宝贝分析
import 生意参谋_自助分析_新建报表_取数报表
import loguru


def main():
    username = 'offrelax旗舰店:boyingkf'

    # or海外旗舰店 商品ID
    item_id_list = [
        681705197690,
        682008342906,
        687108058692,
        702447997992,
        681355608556,
         682323827681,
         693917900979,
         696948157242,
         681366760523,
         681712029329,
         703227534305,
         682328743992,
         681365836110,
         692359424078,
         688103117271,
    ]
    try:
        淘宝直播_数据_直播业绩_直播间大盘.crawler(username)
        淘宝直播_数据_本店成交_本店商品直播间成交.crawler(username)
        淘宝直播_数据_直播间业绩_直播订单明细.crawler(username)
        淘宝直播_数据_本店成交_合作直播间.crawler(username)
        热浪引擎_热浪引擎_推广数据总览_全部订单数据总览.crawler(username)
        生意参谋_直播_直播概况.crawler(username)
        生意参谋_自助分析_新建报表_取数报表.crawler(username)
        生意参谋_业务专区_会员分析_会员分析.crawler(username)
        生意参谋_品类_品类360_品类排行.crawler(username)
        生意参谋_市场_市场大盘_行业趋势.crawler(username)
        生意参谋_流量_店铺来源_构成_流量来源构成.crawler(username)
        生意参谋_品类_商品排行.crawler(username)
        生意参谋_品类_商品360_流量来源_新版api.crawler(username, item_id_list)
        生意参谋_市场_市场排行_商品_高交易.crawler(username)
        生意参谋_市场_市场排行_商品_高流量.crawler(username)
        生意参谋_竞争_竞品分析_入店搜索词_引流关键词.crawler(username, item_id_list)
        生意经_宝贝分析.crawler(username)
    except Exception as e:
        loguru.logger.error(f'采集失败{username}{e}')


    # 生意经没有cookies暂不进行采集

    # 重要！！！！！  彩棠旗舰店:播音服务商 这个账号下面三个脚本不采
    # 生意参谋_品类_品类360_品类排行_加月.crawler(username)
    # 生意参谋_品类_宏观监控_全量商品排行_加月.crawler(username)


if __name__ == "__main__":
    # convert：转换
    main()

