import time

import httpx
from loguru import logger
from pathlib import Path

import utils
from config import settings
from model import get_account


def send(params, cookies):
    headers = {
        'Host': 'sycm.taobao.com',
        'sec-ch-ua': '"Chromium";v="110", "Not A(Brand";v="24", "Microsoft Edge";v="110"',
        'bx-v': '2.2.3',
        'sec-ch-ua-mobile': '?0',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edg/110.0.1587.57',
        'sec-ch-ua-platform': '"Windows"',
        'Accept': '*/*',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Referer': f'https://sycm.taobao.com/cc/item_archives?activeKey=flow&dateRange={params["dateRange"]}%7C{params["dateRange"]}&dateType=day&itemId={params["itemId"]}&spm=a21ag.12100465.sycm-cc-item-archives-top-goods-item-rank-table.7.416350a5hMHYwp',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        'cookie': cookies
    }
    response = httpx.get(
        'https://sycm.taobao.com/flow/excel.do',
        headers=headers,
        params=params,
        timeout=10,
        verify=False
    )
    return response.content


def crawler(username, item_id_lst: list):
    for item_id in item_id_lst:
        date_range = utils.before_day_date_range()
        name = f"【生意参谋平台】无线商品二级流量来源详情-{username.replace(':', '_')}-{date_range.replace('|', '_')}-新版api-{item_id}"
        path_str = Path(settings.LOG_DATA_FILE_PATH, f"{name}.xls").as_posix()
        if Path(path_str).is_file():
            logger.info(f"{name}文件已存在")
            continue

        account = get_account(username)
        if not account:
            logger.error(f"账号 {username} 不存在")
        cookies = account['cookies']['cookie_str']

        params = (
            ('_path_', 'v6/excel/item/crowdtype/source/v3'),
            ('belong', 'all'),
            ('dateType', 'day'),
            ('dateRange', f'{date_range}'),
            ('crowdType', 'all'),
            ('device', '2'),
            ('itemId', f'{item_id}'),
            ('device', '2'),
            ('order', 'desc'),
            ('orderBy', 'uv'),
        )
        params = dict(params)
        content = send(params=params, cookies=cookies)
        if b"5810" in content or b"DOCTYPE" in content:
            # 登录已经过期
            raise Exception("登录过期")
        if len(content) < 1 * 10 ** 4:
            raise Exception("文件内容过短")
        with open(path_str, mode="wb") as f:
            f.write(content)
            logger.info(f"保存文件 {path_str} 成功")

        time.sleep(90)


if __name__ == '__main__':
    #商品id
    item_id_list = [
        681705197690,
        682008342906,
        687108058692,
        702447997992,
        681355608556,
        682323827681,
        693917900979,
        696948157242,
        681366760523,
        681712029329,
        703227534305,
        682328743992,
        681365836110,
        692359424078,
        688103117271,
    ]
    crawler('offrelax旗舰店:boyingkf', item_id_lst=item_id_list)
