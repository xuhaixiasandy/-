"""
模块说明：
    生意参谋-直播-本店商品成交(合作直播间，只要账号为李佳琦Austin的商品数据)
"""

import json
import time
import uuid
from datetime import timedelta, datetime

import requests
from loguru import logger

import model
from model import get_account
from helper import fetch_tbzb


def crawler(username):
    account = get_account(username=username)
    if not account:
        logger.error(f"账号 {username} 不存在")

    cookies = account['cookies']['cookie_dict']

    current_date = datetime.now().date() - timedelta(days=1)
    current_date_str = current_date.strftime("%Y-%m-%d")

    headers = {
        'Host': 'sycm.taobao.com',
        'sec-ch-ua': '"Chromium";v="110", "Not A(Brand";v="24", "Microsoft Edge";v="110"',
        'sec-ch-ua-mobile': '?0',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edg/110.0.1587.41',
        'Sycm-Referer': '/xsite/contentanalysis/live_overview',
        'bx-v': '2.2.3',
        'Onetrace-Card-Id': 'sycm-cp-content-live-overview.sycm-content-live-overview-overall',
        'Sycm-Query': 'dateType=day',
        'sec-ch-ua-platform': '"Windows"',
        'Accept': '*/*',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Referer': f'https://sycm.taobao.com/xsite/contentanalysis/live_overview?dateRange={current_date_str}%7C{current_date_str}&dateType=day',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
    }
    params = (
        ('dateType', 'day'),
        ('dateRange', f'{current_date_str}|{current_date_str}'),
        ('_', f'{int(time.time() * 1000)}'),
        ('token', '0203f40e6'),
    )
    response = requests.get(
        'https://sycm.taobao.com/s_content/live/overall/overview.json',
        headers=headers,
        params=params,
        cookies=cookies,
        timeout=10
    )
    content = response.json()
    if content['code'] != 0:
        raise Exception(f'采集失败{content}')
    item = {
        "username": username,
        "source_data": content,
        "created_time": datetime.now(),
        "meta": {
            "tk_account": account,
            "data": dict(params)
        }
    }
    model.col_生意参谋_直播_直播概况.insert_one(item)
    logger.info(f"账号 {username} 采集成功")


if __name__ == '__main__':
    crawler("offrelax旗舰店:boyingkf")
