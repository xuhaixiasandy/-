import time

from bson import ObjectId
from pymongo import MongoClient
from redbird.logging import RepoHandler
from rocketry import Rocketry
from redbird.repos import MongoRepo, MemoryRepo, CSVFileRepo
from rocketry.log import MinimalRecord, LogRecord, TaskLogRecord

repo = CSVFileRepo(filename="tasks.csv", model=MinimalRecord, encodings="utf-8")

repo = MongoRepo(
    uri="mongodb://192.168.1.21:27015", database="bly_tm_cf", collection="tk_log", model=TaskLogRecord
)
app = Rocketry(
    logger_repo=repo,
)


# 每一个小时执行一次 淘宝直播_直播详情_数据大屏_核心数据 的crawler函数
@app.task('hourly')
def 淘宝直播核心数据():
    time.sleep(5)
    from 淘宝直播_直播详情_数据大屏_核心数据 import crawler
    crawler()


if __name__ == '__main__':
    app.run()
