import json
import time
from pprint import pprint

from loguru import logger

from model import get_account, col_tk_live
from helper import fetch_api


def crawler(username):
    account = get_account(username=username)
    if not account:
        logger.error(f"账号 {username} 不存在")
    cookies = account['cookies']['cookie_dict']

    data = {
        "currentPage": 1,
        "pageSize": 20,
        # "roomNum": '98255',
    }
    data = json.dumps(data)
    text = fetch_api("mtop.taobao.dreamweb.live.get.list", "1.0", data, cookies)
    content = json.loads(text)
    for item in content['data']['data']:
        if item['roomStatus'] == "1":
            result = {
                "live_id": item['id'],
                "author_id": item['accountId'],
                "live_status": item['roomStatus'],
                "topic": item['topic'],
                "username": account['username'],
                'title': item['title']
            }
            col_tk_live.update_many(
                {"live_id": item['id']},
                {"$set": result},
                upsert=True
            )
            # 不等于item['id']的数据，全部设置为0
            col_tk_live.update_many(
                {
                    "live_id": {"$ne": item['id']},
                    "username": account['username']
                 },
                {"$set": {"live_status": '0'}},
            )

            logger.info("直播管理: " + str(result))


if __name__ == '__main__':
    crawler('offrelax旗舰店:boyingkf')
