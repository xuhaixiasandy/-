#!/bin/bash

LOG_FILE="/root/Desktop/bly_tm_v2/logs/bly_tm_logs.txt"
PYTHON_SCRIPT="/root/Desktop/bly_tm_v2/run.py"

# 将日志打印到终端并追加到日志文件中
echo tee -a "$LOG_FILE"

source activate bly_tm

# 执行 Python 脚本并将输出追加到日志文件中
nohup /root/miniconda3/envs/bly_tm/bin/python3 "$PYTHON_SCRIPT" >> "$LOG_FILE" 2>&1 | tee -a "$LOG_FILE" &

# 将其他消息打印到终端并追加到日志文件中
echo tee -a "$LOG_FILE"
