import paramiko


class SFTPClient:
    def __init__(self, hostname, port, username, password):
        self.hostname = hostname
        self.port = port
        self.username = username
        self.password = password
        self.ssh = None
        self.sftp = None

    def __enter__(self):
        # 建立 SSH 连接
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(self.hostname, port=self.port, username=self.username, password=self.password)
        self.ssh = ssh

        # 建立 SFTP 连接
        self.sftp = ssh.open_sftp()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        # 关闭 SFTP 连接和 SSH 连接
        self.sftp.close()
        self.ssh.close()

    def check_file_exists(self, remote_file):
        # 检查远程目录中是否存在指定的文件
        try:
            self.sftp.stat(remote_file)
            print(f'文件 {remote_file} 存在')
            return True
        except FileNotFoundError:
            print(f'文件 {remote_file} 不存在')
            return False

    def upload_file(self, local_file, remote_file):
        # 将本地文件上传到远程目录中
        self.sftp.put(local_file, remote_file)
        print(f'文件 {local_file} 已上传到 {remote_file}')

