import time

import httpx
from loguru import logger
from pathlib import Path
import utils
from config import settings
from model import get_account


def send(params, cookies):
    headers = {
        'Host': 'sycm.taobao.com',
        'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-User': '?1',
        'Sec-Fetch-Dest': 'document',
        'Referer': 'https://sycm.taobao.com/cc/macroscopic_monitor',
        'Accept-Language': 'zh-CN,zh;q=0.9,zh-TW;q=0.8',
        'cookie': cookies
    }
    response = httpx.get(
        'https://sycm.taobao.com/cc/cockpit/marcro/item/excel/top.json',
        headers=headers,
        params=params,
        timeout=10
    )
    return response.content


def send_request(username: str, data_range, data_type: str) -> None:
    date_type = data_type
    date_range = data_range()
    account = get_account(username=username)
    if not account:
        logger.error(f"账号 {username} 不存在")
    cookies = account['cookies']['cookie_str']

    params = {
        'cateId': '',
        'cateLevel': '',
        'dateRange': date_range,
        'dateType': date_type,
        'device': '0',
        'dtUpdateTime': 'false',
        'follow': 'false',
        'guideCateId': '',
        'indexCode': 'itmUv,itemCartCnt,payItmCnt,payAmt',
        'keyword': '',
        'order': 'desc',
        'orderBy': 'payAmt',
        'page': '1',
        'pageSize': '10',
    }
    name = f"【生意参谋_品类_宏观监控_全量商品排行-{username.replace(':', '_')}-{date_range.replace('|', '_')}"
    path_str = Path(settings.LOG_DATA_FILE_PATH, f"{name}.xls").as_posix()
    if Path(path_str).is_file():
        logger.info(f"{name}文件已存在")
        return

    # 获取cookie
    # username = "珀莱雅官方旗舰店:安好"
    account = get_account(username=username)
    if not account:
        logger.error(f"账号 {username} 不存在")

    content = send(params, cookies)
    if b"5810" in content or b"DOCTYPE" in content:
        # 登录已经过期
        raise Exception("登录过期")

    with open(path_str, mode="wb") as f:
        f.write(content)
        logger.info(f"保存文件 {path_str} 成功")

    time.sleep(90)


def monthly_collection(username):
    # 采集月度报表
    send_request(username=username, data_range=utils.before_month_date_range, data_type='month')


def weekly_collection(username):
    # 采集周度报表
    send_request(username=username, data_range=utils.before_week_date_range, data_type='week')


def crawler(username):
    monthly_collection(username)
    weekly_collection(username)


if __name__ == '__main__':
    crawler("offrelax海外旗舰店:boyingkf")
