"""
模块说明：
    生意参谋-直播-本店商品成交(合作直播间，只要账号为李佳琦Austin的商品数据)
"""

import json
import time
from datetime import timedelta, datetime

from loguru import logger

import model
from model import get_account
from helper import fetch_tbzb


def crawler(username):
    account = get_account(username=username)

    if not account:
        logger.error(f"账号 {username} 不存在")
    cookies = account['cookies']['cookie_dict']
    current_date = datetime.now().date() - timedelta(days=1)
    current_date_str = current_date.strftime("%Y%m%d")
    params = {
        "dataQRFormId": "live_ia_co_item",
        "beginDate": current_date_str,
        "endDate": current_date_str,
        "itemId": None,
        "itemTitle": None, "contentId": None,
        "coAccountId": "1759494485",
        "orderType": "1",
        "orderColumn": "live_start_time",
        "start": "0",
        "hit": "5000",
        "queryUserRole": "ALL",
        'time': int(time.time() * 1000)
    }
    data = {
        'dataApi': 'dataQRForm',
        'param': json.dumps(params)
    }
    data = json.dumps(data)
    text = fetch_tbzb(data, cookies)
    content = json.loads(text)
    item = {
        "username": username,
        "source_data": content,
        "created_time": datetime.now(),
        "meta": {
            "tk_account": account
        }
    }
    model.col_淘宝直播_数据_本店成交_合作直播间.insert_one(item)
    logger.info(f"账号 {username} 本店成交数据已更新")
    time.sleep(90)


if __name__ == '__main__':
    crawler('offrelax海外旗舰店:boyingkf')
