"""
模块说明：
    生意参谋-直播-本店商品成交(合作直播间，只要账号为李佳琦Austin的商品数据)
"""

import json
import time
import uuid
from datetime import timedelta, datetime

import requests
from loguru import logger

import model
import crypt_utils
from model import get_account
from helper import fetch_tbzb
from utils import send_slider_url

def crawler(username: str):
    for cate in [
        {
            "cate_id": "50464015",
            "cate_name": "头发清洁/护理/造型",
            "level": 2
        },
        {
            "cate_id": "50016883",
            "cate_name": "护发素",
            "level": 0
        },
        {
            "cate_id": "50016885",
            "cate_name": "摩丝/啫喱/头发造型",
            "level": 0
        },
        {
            "cate_id": "213202",
            "cate_name": "洗发水",
            "level": 0
        },
        {
            "cate_id": "50024999",
            "cate_name": "发膜/护发产品",
            "level": 0
        },
        {
            "cate_id": "50466023",
            "cate_name": "洗护套装",
            "level": 0
        },
        {
            "cate_id": "201858201",
            "cate_name": "头发造型（新）",
            "level": 2
        },
        {
            "cate_id": "201857802",
            "cate_name": "定型喷雾",
            "level": 0
        },
        {
            "cate_id": "50023293",
            "cate_name": "发胶/发泥/发蜡",
            "level": 0
        },
        {
            "cate_id": "127668025",
            "cate_name": "男士个人护理",
            "level": 2
        },
        {
            "cate_id": "201847006",
            "cate_name": "头皮护理",
            "level": 2
        },
        {
            "cate_id": "201858701",
            "cate_name": "头皮磨砂膏",
            "level": 2
        },
        {
            "cate_id": "127736001",
            "cate_name": "头皮精油/精华",
            "level": 0
        },
        {
            "cate_id": "201858501",
            "cate_name": "头皮预洗",
            "level": 0
        },
        {
            "cate_id": "127692023",
            "cate_name": "头发护理",
            "level": 2
        },
        {
            "cate_id": "201310704",
            "cate_name": "护发素",
            "level": 0
        },
        {
            "cate_id": "201307623",
            "cate_name": "发膜/蒸汽发膜/焗油膏",
            "level": 0
        },
        {
            "cate_id": "121410029",
            "cate_name": "其它护发",
            "level": 0
        },
        {
            "cate_id": "127738001",
            "cate_name": "护发精油",
            "level": 0
        },
        {
            "cate_id": "201168001",
            "cate_name": "护发精油安瓶",
            "level": 0
        },
        {
            "cate_id": "201853303",
            "cate_name": "头发清洁",
            "level": 2
        },
        {
            "cate_id": "121396029",
            "cate_name": "洗发水 ",
            "level": 0
        },
        {
            "cate_id": "121476023",
            "cate_name": "洗护套装",
            "level": 0
        },
        {
            "cate_id": "201858401",
            "cate_name": "免洗洗发水/喷雾",
            "level": 0
        },
        {
            "cate_id": "50023294",
            "cate_name": "染发烫发",
            "level": 2
        },
        {
            "cate_id": "201847304",
            "cate_name": "漂发剂",
            "level": 0
        },
        {
            "cate_id": "201858601",
            "cate_name": "补发笔/发际线粉",
            "level": 0
        },

        {
            "cate_id": "201843906",
            "cate_name": "盖白",
            "level": 0
        },
        {
            "cate_id": "50023328",
            "cate_name": "其它染发烫发产品",
            "level": 0
        },
        {
            "cate_id": "50023327",
            "cate_name": "烫发水",
            "level": 0
        },
        {
            "cate_id": "50023326",
            "cate_name": "彩染",
            "level": 0
        },

        {
            "cate_id": "201167901",
            "cate_name": "短效染发剂",
            "level": 0
        },
        {
            "cate_id": "50023283",
            "cate_name": "假发",
            "level": 2
        },

    ]:
        account = get_account(username)
        if not account:
            logger.error(f"账号 {username} 不存在")

        cookies = account['cookies']['cookie_dict']

        current_date = datetime.now().date() - timedelta(days=1)
        current_date_str = current_date.strftime("%Y-%m-%d")
        if model.col_生意参谋_市场_市场排行_商品_高交易.count_documents(
                {
                    "cate_id": cate["cate_id"],
                    'meta.data.dateRange': f'{current_date_str}|{current_date_str}',
                    'meta.tk_account.username': username
                }
        ):
            logger.info(f"已经存在: {cate}")
            continue


        headers = {
            'Host': 'sycm.taobao.com',
            'sec-ch-ua': '"Chromium";v="110", "Not A(Brand";v="24", "Microsoft Edge";v="110"',
            'bx-umidtoken': 'GCDFCD72C133ABE68E1FBCD2EE213DB54217154D228CF8CB908',
            'sec-ch-ua-mobile': '?0',
            'bx-ua': '225!mRGM/izWooizMm7iFoTo+ikXi+ljrDwFaQ/N+blMNAxeo0bimZ76s1s2NBOOWpkgTKc1Hh93+DZDXizP+kynm4yg1XvPvHs2APPWzFoBeUvgwFSHUsWz04HnB8mE/8vr7094ndQwmyvhWjVJoozlb34dX4f/oLnjDUHofeG0QE0dDMXhfifTomQrcPFTbeVU4dEzVOV0QhcdPhXhf/BCeU4KjcNJyVqz4U/+f4jouoyqC9IzcIm3odnS6VJOFxD840NmYeDxkTb8bY18f1taZObGM4f40/diDBmzfeGoQz0KDM5hfodMbUSde4bxQQMRSNHv7eRpl0oqVBF6AdJ5Ft6uY7I3XnTLgtvBM4QGCjQ8oL56f+KaDKnkx5fDVhRnbkgOAQ3POu4q9ssuuNZgdv3YA7JF4hx/eNP88QojOpSq47XxjmL0FvVYMgr0yQhg4fIIBxGufoC8DbX778BCbUSKjxI4K/jRDG/+fe1dFW3+FlqFQCaimO0mUya7/TN0nSTkzuWadYdVRWFPHtoxoPyfLKFTLuMkVOE55FMl3c7wGUk1vziWNjVVT2YWeCESBVEh5mGpsmXZD75/+86zK++wtMceDzbIX1R1Mv807QfwidYcGH7ZxWHhIZ9VLyKkpDLYR4TYhQRzob71IrEuBDIiZ+u8xeClxUn/NqkbVRAymnAgsbjj7N5NW1rXzjqP4jzMw/h+esCb/9VrLLTQ8CPUkmqZjzfSW75ZkRa7tjU1BxDy/9v4Oumxe4maJ+xKIjtAZ+3Rl8X4EktECj9wqvNMdbDwBpTqQIiKO22jzzoWDMemc9uQ/zVtEGJQNxCgdrxiaOOELujlVqL4sGRpHTobirUxDIk0N3PpAcXNcYVX+msi/bzcDkX8lafwnTThgq6XSIn0X7vw4UZPAoQkF2dGEb6S8r29A1qal65tbK7SEVK/tu6glLqcF+Oz7+60sRTN+0+p1r+subjDKxV8rPVfIntCXOWOdoMAwVxa/zXDFjO6eIFg8H+5puQYvrWpBGyL/nv+/FwWxX60mArznPMNXzXEECgJcAOUv572IFnq7nuHxSyzmfEY6DazKAz7Mqj/Aailtra7x/umnRm29RAp2/zscAVx6Y9hSO4YF10YyWltV89UaHpuy16bdVGYzo2T9DYkRymIK6ohGfxonB5n40nd5TjJ0mFs1f9WOACsucW0HlfkdUiWHOhQShEfx0QfIRgYT6E5BvXMoZolxffNZEsrRereaTGc4KP6Vy7+LRBd54+LnJNDikW7Oo==',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edg/110.0.1587.63',
            'Transit-Id': '8PBSIcxDrZhOezl3Mr2QeABky/C5QtRIlMCq8UXE7RKQ9Qsxm1pHLR7+7rdwZSZsNtBjK2yjm76u1CsJ4ef78Ex1pjQarkxaIlTpoaPsz64f8X00ks0IRNTC3Q5bkwvqc35fObBcvUMGEmtpK1UUewWkajgpHIHZp6uV9w2QAA==',
            'Sycm-Referer': '/mc/mq/market_rank',
            'bx-v': '2.2.3',
            'Onetrace-Card-Id': 'sycm-mc-mq-market-rank.sycm-mc-mq-item-item-sale',
            'Sycm-Query': 'dateType=day&activeKey=item',
            'sec-ch-ua-platform': '"Windows"',
            'Accept': '*/*',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': f'https://sycm.taobao.com/mc/mq/market_rank?activeKey=item&cateFlag=1&cateId={cate["cate_id"]}&dateRange={current_date_str}%7C{current_date_str}&dateType=day&sellerType=-1&spm=a21ag.11815228.LeftMenu.d591.7e2650a5uPilgt',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        }
        params = (
            ('dateRange', f'{current_date_str}|{current_date_str}'),
            ('dateType', 'day'),
            ('pageSize', '10'),
            ('page', '1'),
            ('order', 'desc'),
            ('orderBy', 'tradeIndex'),
            ('cateId', f'{cate["cate_id"]}'),
            ('device', '0'),
            ('sellerType', '-1'),
            ('styleId', ''),
            ('priceSeg', ''),
            ('priceSegName', ''),
            ('minPrice', ''),
            ('maxPrice', ''),
            ('sex', ''),
            ('sexRatio', ''),
            ('age', ''),
            ('ageRatio', ''),
            ('indexCode', 'tradeIndex,tradeGrowthRange,payRateIndex'),
            ('_', f'{int(time.time() * 1000)}'),
            ('token', '0203f40e6'),
        )
        response = requests.get(
            'https://sycm.taobao.com/mc/v2/mq/mkt/rank/item/hotsale.json',
            headers=headers,
            params=params,
            cookies=cookies,
            timeout=10
        )

        if "statDate" in response.text:
            logger.error(f'[{username}] {cate["cate_name"]} {current_date_str} 交易指数排行榜抓取失败')
            logger.error(response.text)
            time.sleep(90)
            continue
        content = send_slider_url(response)
        if "操作成功" not in response.text:
            raise Exception(response.text)
        item = {
            "username": username,
            "source_data": content,
            "cate_id": cate["cate_id"],
            "created_time": datetime.now(),
            "meta": {
                "tk_account": account,
                "data": dict(params),
                "tk": cate
            }
        }
        model.col_生意参谋_市场_市场排行_商品_高交易.insert_one(item)
        logger.info(f'[{username}] {cate["cate_name"]} {current_date_str} 交易指数排行榜抓取成功')
        time.sleep(90)


if __name__ == '__main__':
    crawler('offrelax海外旗舰店:boyingkf')
