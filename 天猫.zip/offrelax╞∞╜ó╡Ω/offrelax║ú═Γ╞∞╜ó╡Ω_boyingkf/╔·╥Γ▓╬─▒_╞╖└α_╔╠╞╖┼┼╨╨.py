import time

import httpx
from loguru import logger
from pathlib import Path

import utils
from config import settings
from model import get_account


def send(params, cookies):
    headers = {
        'Host': 'sycm.taobao.com',
        'sec-ch-ua': '"Chromium";v="110", "Not A(Brand";v="24", "Microsoft Edge";v="110"',
        'bx-v': '2.2.3',
        'sec-ch-ua-mobile': '?0',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edg/110.0.1587.57',
        'sec-ch-ua-platform': '"Windows"',
        'Accept': '*/*',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Referer': 'https://sycm.taobao.com/cc/item_rank?spm=a21ag.12100459.goBack.d122527.3a9450a52NTCPG&_clear_module_code_=category-experience-ptimization-transit',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        'cookie': cookies
    }
    response = httpx.get(
        'https://sycm.taobao.com/cc/item/view/excel/top.json',
        headers=headers,
        params=params,
        timeout=10
    )
    return response.content


def crawler(username):
    # 生成文件名
    date_range = utils.before_day_date_range()
    name = f"品类_商品排行_{username.replace(':', '_')}-{date_range.replace('|', '_')}"
    path_str = Path(settings.LOG_DATA_FILE_PATH, f"{name}.xls").as_posix()
    if Path(path_str).is_file():
        logger.info(f"{name}文件已存在")
        return

    account = get_account(username)
    if not account:
        logger.error(f"账号 {username} 不存在")
    cookies = account['cookies']['cookie_str']

    params = (
        ('dateRange', f'{date_range}'),
        ('dateType', 'day'),
        ('pageSize', '10'),
        ('page', '1'),
        ('order', 'desc'),
        ('orderBy', 'payAmt'),
        ('dtUpdateTime', 'false'),
        ('dtMaxAge', '0'),
        ('device', '0'),
        ('compareType', 'cycle'),
        ('keyword', ''),
        ('follow', 'false'),
        ('cateId', ''),
        ('cateLevel', ''),
        ('indexCode', 'payAmt,payAmtRatio,sucRefundAmt,payRate,itmUv'),
    )
    params = dict(params)

    content = send(params=params, cookies=cookies)

    if b"5810" in content or b"DOCTYPE" in content:
        # 登录已经过期
        raise Exception("登录过期")
    if len(content) < 1 * 10 ** 4:
        raise Exception("文件内容过短")

    with open(path_str, mode="wb") as f:
        f.write(content)
        logger.info(f"保存文件 {path_str} 成功")


if __name__ == '__main__':
    crawler("offrelax海外旗舰店:boyingkf")
