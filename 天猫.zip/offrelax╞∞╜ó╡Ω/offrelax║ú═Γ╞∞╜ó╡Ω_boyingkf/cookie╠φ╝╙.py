import fire
from loguru import logger

from utils import convert_dict_to_cookie_string, convert_cookie_string_to_dict
from model import col_tk_account


def update_cookie(cookie_str):
    username = "offrelax海外旗舰店:boyingkf"
    c = convert_cookie_string_to_dict(cookie_str)
    # user_id 1 为测试
    col_tk_account.update_many(
        {
            "username": username,
        },
        {
            "$set": {
                "cookies": {
                    "cookie_dict": c,
                    "cookie_str": convert_dict_to_cookie_string(c),
                }
            }
        }
    )

    logger.info("成功添加cookie: {}".format(cookie_str))


if __name__ == '__main__':
    #update_cookie(cookie_str="xlly_s=1; t=173cf7e35be8ba69221de5a3e377011d; _samesite_flag_=true; cookie2=1b872aab13117cadb4970b1920162761; _tb_token_=3fdb133f753ee; unb=2215742276197; sn=offrelax海外旗舰店:boyingkf; cancelledSubSites=empty; _euacm_ac_l_uid_=2215742276197; 2215742276197_euacm_ac_c_uid_=2211348569776; 2215742276197_euacm_ac_rs_uid_=2211348569776; _portal_version_=new; cc_gray=1; XSRF-TOKEN=0ce1f865-37da-4dae-ae64-f2b9dbdd7285; _euacm_ac_rs_sid_=212536454; _m_h5_tk=390438009e84a003dbe5ae66aecac3cc_1682588464732; _m_h5_tk_enc=baabba5d40a8180d1e420dd06c476ac2; adm_version=new; sgcookie=E100YFx9yP5FcKK+o6awHpk+zcMyT2DKGttuMJNw6AQPN/SIC8YQaq4C1n9aX/DcRQKGtFQFxps+/YHDYf+J79SnnCEiVFzxebgEYJnH9/Pc+Uk=; uc1=cookie14=Uoe8iCSFxZ0+XQ==&cookie21=UtASsssmfufd; csg=4736cc6c; skt=22475d23f9bffc72; _cc_=URm48syIZQ==; cna=mvjQHJHfTRsCAbYqauaxSsdr; v=0; isg=BNHRLjIPUaoei72-KYw-nwqb4NRrPkWweUuNFbNnhRiSWuGs_I8VgQHz_Ca80t3o; l=fBgfv9WrNR2bqe_KBO5Churza77trIOXcsPzaNbMiIEGa6pRxhL_GNC__fqJIdtj_TfcLF-yjxzk0d3H-AU3rjkDBeYIua1hpxJ9-bpU-L5..; tfstk=c8yFBdw_1Ip_BzrRkADz7iqEpBlNa0q3qdojtaIIrOUCXeDEus2wyccGPcoWbUch.; JSESSIONID=467FA11C5F6A0DD3D5A606DB168FD4F9")
    fire.Fire(update_cookie)