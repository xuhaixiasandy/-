from model import mg_client
from fire import Fire


db_bly_tm_cf = mg_client['bly_tm_cf']
db_bolaiya = mg_client['bolaiya']
db_mh = mg_client['mh']
db_huaxi = mg_client['huaxi']


def bly_tm(x5sec):
    for i in db_bly_tm_cf['tk_account'].find({}):
        cookies = i['cookies']
        cookies['cookie_dict']['x5sec'] = x5sec

        if "x5sec" in cookies['cookie_str']:
            for x5sec_str in cookies['cookie_str'].split(";"):
                if "x5sec" in x5sec_str:
                    cookies['cookie_str'].replace(x5sec_str, f"x5sec={x5sec}")
        else:
            cookies['cookie_str'] = f"{cookies['cookie_str']}; x5sec={x5sec};"

        db_bly_tm_cf['tk_account'].update_one(
            {
                "_id": i['_id']
            },
            {
                "$set": {
                    "cookies": cookies
                }
            }
        )


def bolaiya(x5sec):
    for i in db_bolaiya['account_manager'].find({}):
        if i['account_user_name'] == "韩雅旗舰店:小班":
            pass
        cookie_str = i['account_cookie']
        if "x5sec" in cookie_str:
            for x5sec_str in cookie_str.split(";"):
                if "x5sec" in x5sec_str:
                    cookie_str = cookie_str.replace(x5sec_str, f"x5sec={x5sec}")
        else:
            cookie_str = f"{cookie_str}; x5sec={x5sec};"

        db_bolaiya['account_manager'].update_one(
            {
                "_id": i['_id']
            },
            {
                "$set": {
                    'account_cookie': cookie_str
                }
            }
        )


def mh(x5sec):
    for i in db_mh['account_manager'].find({}):
        cookie_str = i['account_cookie']
        if "x5sec" in cookie_str:
            for x5sec_str in cookie_str.split(";"):
                if "x5sec" in x5sec_str:
                    cookie_str = cookie_str.replace(x5sec_str, f"x5sec={x5sec}")
        else:
            cookie_str = f"{cookie_str}; x5sec={x5sec};"

        db_mh['account_manager'].update_one(
            {
                "_id": i['_id']
            },
            {
                "$set": {
                    'account_cookie': cookie_str
                }
            }
        )


def huaxi(x5sec):
    for i in db_huaxi['account_manager'].find({}):
        cookie_str = i['account_cookie']
        if "x5sec" in cookie_str:
            for x5sec_str in cookie_str.split(";"):
                if "x5sec" in x5sec_str:
                    cookie_str = cookie_str.replace(x5sec_str, f"x5sec={x5sec}")
        else:
            cookie_str = f"{cookie_str}; x5sec={x5sec};"

        db_huaxi['account_manager'].update_one(
            {
                "_id": i['_id']
            },
            {
                "$set": {
                    'account_cookie': cookie_str
                }
            }
        )


def main(x5sec):
    huaxi(x5sec)
    mh(x5sec)
    bolaiya(x5sec)
    bly_tm(x5sec)


if __name__ == '__main__':
    Fire(main)
    # x5sec = '7b226f702d6d633b32223a223535383165336436373730303063303462306363373631646634623064646362434d36752f364547454c366e71386930367257666f514561454449794d5455324f4459304e5463304e6a55374d5441776934337431506e2f2f2f2f2f41554144227d'
    # main(x5sec)