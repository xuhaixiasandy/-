"""
模块说明：
    生意参谋-直播-本店商品成交(合作直播间，只要账号为李佳琦Austin的商品数据)
"""

import json
import time
import uuid
from datetime import timedelta, datetime

import requests
from loguru import logger

import model
import crypt_utils
from model import get_account
from helper import fetch_tbzb
from utils import DateRange, send_slider_url


def crawler(username: str, date: str):
    date_str = date
    for cate in [
        {
            "cate_id": "50464015",
            "cate_name": "头发清洁/护理/造型",
            "level": 2
        },
        {
            "cate_id": "50016883",
            "cate_name": "护发素",
            "level": 0
        },
        {
            "cate_id": "50016885",
            "cate_name": "摩丝/啫喱/头发造型",
            "level": 0
        },
        {
            "cate_id": "213202",
            "cate_name": "洗发水",
            "level": 0
        },
        {
            "cate_id": "50024999",
            "cate_name": "发膜/护发产品",
            "level": 0
        },
        {
            "cate_id": "50466023",
            "cate_name": "洗护套装",
            "level": 0
        },
        {
            "cate_id": "201858201",
            "cate_name": "头发造型（新）",
            "level": 2
        },
        {
            "cate_id": "201857802",
            "cate_name": "定型喷雾",
            "level": 0
        },
        {
            "cate_id": "50023293",
            "cate_name": "发胶/发泥/发蜡",
            "level": 0
        },
        {
            "cate_id": "127668025",
            "cate_name": "男士个人护理",
            "level": 2
        },
        {
            "cate_id": "201847006",
            "cate_name": "头皮护理",
            "level": 2
        },
        {
            "cate_id": "201858701",
            "cate_name": "头皮磨砂膏",
            "level": 2
        },
        {
            "cate_id": "127736001",
            "cate_name": "头皮精油/精华",
            "level": 0
        },
        {
            "cate_id": "201858501",
            "cate_name": "头皮预洗",
            "level": 0
        },
        {
            "cate_id": "127692023",
            "cate_name": "头发护理",
            "level": 2
        },
        {
            "cate_id": "201310704",
            "cate_name": "护发素",
            "level": 0
        },
        {
            "cate_id": "201307623",
            "cate_name": "发膜/蒸汽发膜/焗油膏",
            "level": 0
        },
        {
            "cate_id": "121410029",
            "cate_name": "其它护发",
            "level": 0
        },
        {
            "cate_id": "127738001",
            "cate_name": "护发精油",
            "level": 0
        },
        {
            "cate_id": "201168001",
            "cate_name": "护发精油安瓶",
            "level": 0
        },
        {
            "cate_id": "201853303",
            "cate_name": "头发清洁",
            "level": 2
        },
        {
            "cate_id": "121396029",
            "cate_name": "洗发水 ",
            "level": 0
        },
        {
            "cate_id": "121476023",
            "cate_name": "洗护套装",
            "level": 0
        },
        {
            "cate_id": "201858401",
            "cate_name": "免洗洗发水/喷雾",
            "level": 0
        },
        {
            "cate_id": "50023294",
            "cate_name": "染发烫发",
            "level": 2
        },
        {
            "cate_id": "201847304",
            "cate_name": "漂发剂",
            "level": 0
        },
        {
            "cate_id": "201858601",
            "cate_name": "补发笔/发际线粉",
            "level": 0
        },

        {
            "cate_id": "201843906",
            "cate_name": "盖白",
            "level": 0
        },
        {
            "cate_id": "50023328",
            "cate_name": "其它染发烫发产品",
            "level": 0
        },
        {
            "cate_id": "50023327",
            "cate_name": "烫发水",
            "level": 0
        },
        {
            "cate_id": "50023326",
            "cate_name": "彩染",
            "level": 0
        },

        {
            "cate_id": "201167901",
            "cate_name": "短效染发剂",
            "level": 0
        },
        {
            "cate_id": "50023283",
            "cate_name": "假发",
            "level": 2
        },
    ]:
        account = get_account(username)
        if not account:
            logger.error(f"账号 {username} 不存在")

        cookies = account['cookies']['cookie_dict']
        if model.col_生意参谋_市场_市场大盘_行业趋势.count_documents(
                {
                    "cate_id": cate["cate_id"],
                    'meta.data.dateRange': f'{date_str}|{date_str}',
                    'meta.tk_account.username': username
                }
        ):
            logger.info(f"已经存在: {cate}")
            continue

        headers = {
            'host': 'sycm.taobao.com',
            'sec-ch-ua': '"Chromium";v="112", "Not A(Brand";v="99", "Microsoft Edge";v="112"',
            'bx-umidtoken': 'G4432355C7B23E4C77B744AFBFF3F7A306E682CEA1637DD1A60',
            'sec-ch-ua-mobile': '?0',
            'bx-ua': '225!qDuW6ozWooizuBDztiDpVO5Xi+ljrDwFaQ/N+5641rcP9LvNeCmOg9iPbMOWNYVGoFGymUIUeqa13xpEC6aMH8/WB2fllTnCZ73MKYNqoTP1oafIEnZUopRwoJiRDGhcf460Qk0UDMzhfidCbU4KjcI4+eGd/fzjBxjGfEKQD654VpoHb3SdX4fSoJiRiRKAMqUIQE0dD6XMBodlbaCOrPIhbHM+KFL4B5bIPu3re2suuNviHI31YBfZS9SzDGHKOtloKIaKD6XhfodlbUSKjxE3oLFdtHplqsVWR00NS2JqvKr0D1nZM5XLy94TSNBr84ePvllAgHL8ltvkUKSNwAf9VnaK9OAvc9RulUou/JfIC+raF+6CYAghnqx4ytg16QRROTGCy/XOR+7ToFcYx5mFSnx+eZvqAQ3jfpaG4/HlftkNbZTdX4f4oLijDl/yRb3oQE0KDGTUMk83iWiv3aK/VKhDwh5i3mx1jfD20E6c+JjRrqveZgM44qj1HV6r/lbI+S9RkTBAvTo9pj1qsDYJPEnpv34xIPxa9nyQVbVUKrkSt6ceDzbIX1R1Mv807Q2w7GBmC1PRVfJPwRNuFURM9x5xFtdV4CiIfvrjdpBKJkVTPP7XhzABJPoGlwD8OSpCOWvqmPrkRBA9Dz45jW1kjpgcQMlnKR/uYuLd7+PnND3/7LojMBBbvj1RbKGys5r/xbpBkxO8zVYxBHpei+FHquxvdjegH1GxmFsJS+X6G4LUt5O7zehrKt2EplKlVJsKPK6VDcx3nRRXUpO2IKpdmgkHRW/F0JH0paYDGY6RHeuY25FcRv7zEYRdxP8OXk88c4e6NYfMQCGwudYwN9I3/mukoeAeBKeoP/xPiawHUhPrpLYOvC/q5NSh1fvFIay/N6FbikkOmqd9RcP/nPsef638zmV15JUxOOf0l85JcWRF4hzbhTrtKO/n6LC/uTrOXpBP5rseOV7CQ475F4zFDH7HGYuzd+vvBzXdHIo3cVsyk28aeLKHIkwE9ZHCH0jrhslUY+mwwB/Pm3eNg6B8p2cRLrzdYApB8lVOAWsRLKAcl4hn78O0pIi6Cnj4/eoSZ+IQ+0BigyuHPFGuqgjImQcu7xXsLcCqcwCbpZxAnYzCDUyF2fM9XPWaNJ5JusE4c2yaHnwhbMDQOiJrNgbznAHdNVSe1LTBoNkSIsyey8D4QnqJgTUi5pcKOQR3H09hbQ2cr8itp0KDleqvGiANIRwMVcIWQbVVXVgIYxkSp9/2hkDst6R7tcRlt+85SmgsWpPF+PounIblmC1nIfF2T2sMVBtYbEcWtmnpSYdguJo=',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.48',
            'transit-Id': 'hdgSLjSy0XDH/DrF4Rr6fXO1AoQ8mc/8Ojkd8qTnEm1D6luEp7rArtyt51eFJ4Bo2d+u0U6em2HZBLkCHdWo2DqhPbLyobvMB+k/8m4S2ejxHHXKQxOiHiZMRn7N2TTwi4KtkFnLIyM+msYm+vR1w9JKJq472WK8IYCnRYXj0FU=',
            'sycm-Referer': '/mc/mq/overview',
            'bx-v': '2.2.3',
            'onetrace-card-id': 'sycm-mc-mq-market-overview.sycm-mc-mq-cate-trend',
            'sycm-Query': 'dateType=week',
            'sec-ch-ua-platform': '"Windows"',
            'accept': '*/*',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'cors',
            'sec-fetch-dest': 'empty',
            'referer': f'https://sycm.taobao.com/mc/mq/overview?cateFlag=1&cateId={cate["cate_id"]}&dateRange={date_str}%7C{date_str}&dateType=day&sellerType=-1&spm=a21ag.11815242.LeftMenu.d590.70f250a5PkNjV4',
            'accept-language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        }
        params = (
            ('dateType', 'day'),
            ('dateRange', f'{date_str}|{date_str}'),
            ('cateId', f'{cate["cate_id"]}'),
            ('device', '0'),
            ('sellerType', '-1'),
            ('_', f'{int(time.time() * 1000)}'),
            ('token', 'a537ee9c6'),
        )
        response = requests.get(
            'https://sycm.taobao.com/mc/mq/supply/mkt/overview.json',
            headers=headers,
            params=params,
            cookies=cookies,
            timeout=10
        )
        # content = response.json()
        content = send_slider_url(response)
        content = json.loads(crypt_utils.data_decrypt(content['data']))
        item = {
            "username": username,
            "cate_id": cate["cate_id"],
            "source_data": content,
            "created_time": datetime.now(),
            "meta": {
                "tk_account": account,
                "data": dict(params),
                "tk": cate
            }
        }
        model.col_生意参谋_市场_市场大盘_行业趋势.insert_one(item)
        logger.info(f"采集成功: {cate}")
        time.sleep(90)


if __name__ == '__main__':
    crawler("offrelax海外旗舰店:boyingbsj", "2023-01-28")
