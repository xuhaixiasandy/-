import fire
from loguru import logger

from utils import convert_dict_to_cookie_string, convert_cookie_string_to_dict
from model import col_tk_account


def update_cookie(cookie_str):
    username = "offrelax海外旗舰店:boyingbsj"
    c = convert_cookie_string_to_dict(cookie_str)
    # user_id 1 为测试
    col_tk_account.update_many(
        {
            "username": username,
        },
        {
            "$set": {
                "cookies": {
                    "cookie_dict": c,
                    "cookie_str": convert_dict_to_cookie_string(c),
                }
            }
        }
    )

    logger.info("成功添加cookie: {}".format(cookie_str))


if __name__ == '__main__':
    #update_cookie(cookie_str='arms_uid=967b64b3-7c01-444c-8ba7-047e6f5da7f8; t=2c880832d141a6871bd610f4210a60ea; cookie2=15439517a54f09488471ae18bfebae3a; _tb_token_=e7e93eb3b86e5; _samesite_flag_=true; xlly_s=1; sgcookie=E100jDVfh1sHB4mgq0D2UqFO78ZAR7T8SLLZ8GTpqMx4NUc3Ef3mgf2KMsZrdgteaOgvzWHDGcTAm1bLSUn1BTZ1sUY1sWsi5Wi/+WWhG+GO4UE=; unb=2215745472526; sn=offrelax海外旗舰店:boyingbsj; uc1=cookie21=UIHiLt3xSalX&cookie14=Uoe8iCcC+0EyjQ==; csg=6d14e5a0; cancelledSubSites=empty; skt=be774385479d8b18; _cc_=Vq8l+KCLiw==; cna=9zDSHCmxUXACAbYqfr5J6C/W; _euacm_ac_l_uid_=2215745472526; 2215745472526_euacm_ac_c_uid_=2211348569776; 2215745472526_euacm_ac_rs_uid_=2211348569776; _portal_version_=new; cc_gray=1; v=0; XSRF-TOKEN=aaa97382-c484-4dbf-8033-88369af42f65; _euacm_ac_rs_sid_=212536454; _m_h5_tk=ec248a5be2da9b89fa4349058f51d2ae_1682662720884; _m_h5_tk_enc=225ee8c328984577cf211c3dc4c2ac97; JSESSIONID=04DD9A8E8103827153BAD3DE8E9CB1E3; isg=BDU18Wh4vb9-uNkDZfLbC3J6RLjvsunEJZ-pybda7Kz5jlSAfgAslIGH2Fq4zgF8; l=fBTlHjdlNRtZF-oGBOfwFurza77O_IRfguPzaNbMi9fP93Bp50VlW1NiUmx9CnGNEsjeJ3-i3zx2Bc8t2yU8gxv9-egVP6XKYdLnwpzHU; tfstk=c5pOBZta07j_xG3cLOh3u78u3_SOZBNco4_YHLDwO54gAnwAiR9keoAzFi7PWDC..')
    fire.Fire(update_cookie)
    