"""
模块说明：
    生意参谋-直播-本店商品成交(合作直播间，只要账号为李佳琦Austin的商品数据)
"""

import json
import time
import uuid
from datetime import timedelta, datetime

import requests
from loguru import logger

import model
import crypt_utils
from model import get_account
from helper import fetch_tbzb
from utils import DateRange


def crawler(username, item_id_lst: list, date: str):
    item_id_lst = [
        674887327334,
        696613068412,
        648531250648,
        656602690281,
        678314223731,
        675689984148,
        642723620176,
        682713474973,
        695021130187,
        702940999740,
        651297498335,
        648169381196,
        676379406671,
        668478757041,
        676713091218,
    ]
    for item_id in item_id_lst:
        item_id = str(item_id)
        account = get_account(username=username)
        if not account:
            logger.error(f"账号 {username} 不存在")

        cookies = account['cookies']['cookie_dict']
        date_str = date
        if model.col_生意参谋_竞争_竞品分析_入店搜索词_引流关键词.count_documents(
                {
                    "item_id": item_id,
                    "created_time": {"$gte": datetime.combine(datetime.now().date(), datetime.min.time())},
                    'meta.data.dateRange': f'{date_str}|{date_str}',
                    'meta.tk_account.username': username,
                }
        ):
            logger.info(f"item_id {item_id} 已存在")
            continue
        headers = {
            'Host': 'sycm.taobao.com',
            'sec-ch-ua': '"Chromium";v="110", "Not A(Brand";v="24", "Microsoft Edge";v="110"',
            'bx-umidtoken': 'G772F3FA9C57A0F45591ED16C222DD254D684756E77863360D9',
            'sec-ch-ua-mobile': '?0',
            'bx-ua': '225!NHUBJozWooizkns5EoEp9OHXi+ljrDwFaQ/N+564wsTjRXsUhFJwM0c0ZyMPPcuK8HDkqnywUsdPjAvju0Nz/3szUnarNdDhEBBV+yV8SwWyxXn50fbi8z2dopfpoJiRDGhcf460Qk0UDMzhfidCbU4KjcI4z43+/mB1Q43jGpDG4bbkVpdCIGLQjcI47P3GDGHz1nQqvpeGD654foz3sIo0HMXfJ4io4WmjpB9LuKcGKyLluK1e3O6Omy7/SVTHVItRf4Ga640dPhXhfizlbUSKjxIhoLjjDlhuGOfmNIaNSP56fK+iU+pkx/OMhwx45IZm7eicWTwYg5PRfmtFzN60w8IhVnTUSvJG84UWIapObAg8CtB5T1pmAAFZSnqL9tN86Q4uOu61ysr7lzzg0NWf6rf+4waLVvNjAwaACjYf/XXPfEFh+ZcUj77r7P3jDlH+feGS7zadD65hfn4ifUOMXRLviUK/VKhDqE7Su9K/r5IPSfv7QA9Ekn3lKK7eVJeHbXUUTDFUm6D7W0t5/c6xrzuF7csMdUkz2WROvHfzdX3zas+wtMceDzbIX1R1Mv807QfwidYcGH7ZxWHhIZ9VLyKkpDLYR4TYhQRzob71IrEuBDIi3zsYlMgJ5l2RpTeLnFf3qv5VQF1DJITBmDLaIlArNbMpNanIjSfkt8dYnrfH9d3aSrDjIhK/ymmt+IdchsJDCHWxJCHL2Lce/Fgwy2aSOKszx8hOhytFc1CdgInVuRXAYS2YRmpN4hk9QMB8hUMdgObJApaaxTFW7WCPquHjg7rST9Xev5/oh1ALwZEC/R8ufkIj9GLIoQ9EQvlVPfAriVcmVomZy17AjTpXawBYaxmz3vrkgqy1uwMoGCIZ4jqahjUv+n6wizmG47Ic+2v3TF+h20NXwsqrQokdfxQyMdqxS7dHq8gvZm6DbK/CLVfefUGmCRyACb4zYlpYIAG8eqTiD9Xbub2prc2n0+fb4Vg4xvN+PyjBL8aBtb742TCSz9rGPl8+raSLcF7oaxINmLXrV+7rbghu04/Pdnq1WvOs73GvtYfjgOVNH9V5uV6MOqSJTbqOqk12yXGLUIYuDlF7bV2RizcC8vQlvdkcYj4jYpoWuTb3v79Efd7z5FZifdZ/txu6P6J20+9g1VHVZ7wlLd67UdvDuJrfgdlq6tGNP/XGCczusFK3LgMtzoAdY86SK4ugHZINoDZPMRAkQ+sX',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edg/110.0.1587.63',
            'Transit-Id': 'fW+Eyz4hIkQ8+OOuNEk9EWVn7M9CXjofxy/3mb648bUsLEOUMXpAAfiUgKgRh787fEGiY1XYcN23Z21Z5mWgUOjPE9T7KG+hujFFvAoysrXMzTYJidaa8ZEN+fKyWHO0i2g18v1NbF2s16E5xJE79uGS9u04cxfPZFCWKbnUwHw=',
            'Sycm-Referer': '/mc/ci/item/analysis',
            'bx-v': '2.2.3',
            'Onetrace-Card-Id': 'sycm-mc-ci-item-analysis.sycm-mc-ci-item-analysis-keyword-table-flow-selfItem',
            'Sycm-Query': 'dateType=day',
            'sec-ch-ua-platform': '"Windows"',
            'Accept': '*/*',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': f'https://sycm.taobao.com/mc/ci/item/analysis?cateFlag=1&cateId=1801&dateRange={date_str}%7C{date_str}&dateType=day&rivalItem1Id=&rivalItem2Id=&selfItemId={item_id}',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        }
        params = (
            ('dateRange', f'{date_str}|{date_str}'),
            ('dateType', 'day'),
            ('pageSize', '20'),
            ('page', '1'),
            ('device', '2'),
            ('sellerType', '0'),
            ('cateId', '50010705'),
            ('itemId', f'{item_id}'),
            ('topType', 'flow'),
            ('indexCode', 'uv'),
            ('_', f'{int(time.time() * 1000)}'),
            ('token', 'a537ee9c6'),
        )
        response = requests.get(
            'https://sycm.taobao.com/mc/rivalItem/analysis/getKeywords.json',
            headers=headers,
            params=params,
            cookies=cookies,
            timeout=10
        )
        content = response.json()
        content = json.loads(crypt_utils.data_decrypt(content['data']))
        item = {
            "username": username,
            "item_id": item_id,
            "source_data": content,
            "created_time": datetime.now(),
            "meta": {
                "tk_account": account,
                "data": dict(params)
            }
        }
        model.col_生意参谋_竞争_竞品分析_入店搜索词_引流关键词.insert_one(item)
        logger.info(f"插入数据成功: {item_id}")
        time.sleep(90)


if __name__ == '__main__':
    item_id_list = [
        674887327334,
        696613068412,
        648531250648,
        656602690281,
        678314223731,
        675689984148,
        642723620176,
        682713474973,
        695021130187,
        702940999740,
        651297498335,
        648169381196,
        676379406671,
        668478757041,
        676713091218,
    ]
    crawler("offrelax海外旗舰店:boyingbsj", item_id_list, "2023-01-28")
