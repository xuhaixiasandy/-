"""
这个模块是用来下载淘宝联盟的商品分析数据的。具体来说，它会打开一个Chromium浏览器，模拟人工操作，登录淘宝联盟，进入商品分析页面，选择昨天的数据，下载数据，然后上传到服务器上。这个模块的主要功能在download_file函数中实现。
"""
# 导入所需模块
from datetime import datetime, timedelta
from loguru import logger
from playwright.sync_api import Playwright, sync_playwright
import model
from sftp_utils import SFTPClient


# 获取昨天的日期
def get_yesterday_date():
    today = datetime.today()
    yesterday = today - timedelta(days=1)
    yesterday_str = yesterday.strftime('%Y-%m-%d')
    return f"{yesterday_str} 00:00:00~{yesterday_str} 23:59:59"


# 将cookie字典转换为cookie列表
def dict_to_cookie(cookie_dict, domain=".alimama.com", path="/"):
    cookie_list = []
    for name, value in cookie_dict.items():
        cookie_list.append({"name": name, "value": value, "domain": domain, "path": path})
    return cookie_list


# 下载文件
def download_file():
    # 设置文件名
    file_name = f"淘宝联盟_数据分析_商品分析_商品管理_{get_yesterday_date()}.csv".replace(":", "_")
    print(file_name)
    # 判断文件是否已存在
    # with SFTPClient("39.175.169.130", 8020, "root", "boying6699") as sftp:
    #     if sftp.check_file_exists(f"/data/lsg/珀莱雅天猫/data/{file_name}"):
    #         logger.info("文件已存在")
    #         return

    with sync_playwright() as p:
        # 打开Chromium浏览器
        browser_type = p.chromium

        # browser = p.webkit.launch(headless=False)
        # page = browser.new_page()
        # page.goto("https://www.baidu.com")

        context = browser_type.launch_persistent_context(
            user_data_dir=r'./user_data',
            # user_data_dir=None,
            headless=False,
            args=['--disable-infobars']
        )
        # 创建一个新的浏览器页面
        page = context.new_page()
        extra_headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
        }
        page.set_extra_http_headers(extra_headers)
        # 这段代码是在模拟浏览器操作时，为了防止被网站检测到使用了自动化工具而添加的。
        # 它的作用是将navigator.webdriver属性的值设置为undefined，从而隐藏浏览器自动化工具的痕迹。
        page.add_init_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
        # 获取账号信息
        account = model.get_account("珀莱雅官方旗舰店:安好")
        if not account:
            raise Exception("账号不存在")
        # 添加cookie
        page.context.add_cookies(dict_to_cookie(account['cookies']['cookie_dict']))
        page.context.add_cookies(dict_to_cookie(account['cookies']['cookie_dict'], domain=".taobao.com", path="/"))
        # 打开页面
        page.goto('https://ad.alimama.com/portal/v2/report/item/list.htm')
        # 等待页面加载完成
        page.wait_for_load_state()
        # 判断是否为webdriver
        result = page.evaluate("() => navigator.webdriver")
        # 点击昨日按钮
        button_zuoRi = page.wait_for_selector("//button[text()='昨日']")
        button_zuoRi.click()
        # 点击下载按钮
        button_download = page.wait_for_selector("//*[@class='next-btn next-medium next-btn-normal ml10']")
        button_download.click()
        # 点击确定按钮
        button_queDing = page.wait_for_selector("//button[text()='确定']")
        button_queDing.click()
        # 点击下载记录按钮
        button_xiaZaiJiLu = page.wait_for_selector("//*[@id='mux-tabs-0-tab-record']")
        button_xiaZaiJiLu.click()
        # 等待元素出现
        element = page.wait_for_selector(f"//div[text()='{get_yesterday_date()}-商品分析']")
        if element.is_visible():
            pass
        # 等待下载完成
        with page.expect_download(timeout=60 * 1000) as download_info:
            # 点击下载按钮
            page.wait_for_selector(
                f"//div[text()='{get_yesterday_date()}-商品分析']/parent::td/following-sibling::td[2]//span[text()='下载']",
                timeout=60 * 1000).click()
        download = download_info.value
        local_file_path = f'./{file_name}'
        # 保存文件
        download.save_as(local_file_path)
        # 上传文件
        with SFTPClient("39.175.169.130", 8020, "root", "boying6699") as sftp:
            sftp.upload_file(local_file_path, f"/data/lsg/珀莱雅天猫/data/{file_name}")
            logger.info("上传成功")
        # 关闭页面
        page.close()
        context.close()


if __name__ == "__main__":
# 调用下载文件函数
    download_file()
