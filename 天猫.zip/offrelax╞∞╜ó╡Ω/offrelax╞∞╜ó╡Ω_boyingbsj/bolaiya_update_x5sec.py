from model import mg_client
from fire import Fire
from loguru import logger
import requests
import json
import time


db_bly_tm_cf = mg_client['bly_tm_cf']
db_bolaiya = mg_client['bolaiya']
db_mh = mg_client['mh']
db_huaxi = mg_client['huaxi']


def bly_tm(x5sec):
    for i in db_bly_tm_cf['tk_account'].find({}):
        cookies = i['cookies']
        cookies['cookie_dict']['x5sec'] = x5sec

        if "x5sec" in cookies['cookie_str']:
            for x5sec_str in cookies['cookie_str'].split(";"):
                if "x5sec" in x5sec_str:
                    cookies['cookie_str'].replace(x5sec_str, f"x5sec={x5sec}")
        else:
            cookies['cookie_str'] = f"{cookies['cookie_str']}; x5sec={x5sec};"

        db_bly_tm_cf['tk_account'].update_one(
            {
                "_id": i['_id']
            },
            {
                "$set": {
                    "cookies": cookies
                }
            }
        )


def bolaiya(x5sec):
    for i in db_bolaiya['account_manager'].find({}):
        cookie_str = i['account_cookie']
        if "x5sec" in cookie_str:
            for x5sec_str in cookie_str.split(";"):
                if "x5sec" in x5sec_str:
                    cookie_str = cookie_str.replace(x5sec_str, f"x5sec={x5sec}")
        else:
            cookie_str = f"{cookie_str}; x5sec={x5sec};"

        db_bolaiya['account_manager'].update_one(
            {
                "_id": i['_id']
            },
            {
                "$set": {
                    'account_cookie': cookie_str
                }
            }
        )
        logger.info(f'珀莱雅x5sec更新 成功账号{i["account_user_name"]}, e5sec:{x5sec}')


def mh(x5sec):
    for i in db_mh['account_manager'].find({}):
        cookie_str = i['account_cookie']
        if "x5sec" in cookie_str:
            for x5sec_str in cookie_str.split(";"):
                if "x5sec" in x5sec_str:
                    cookie_str = cookie_str.replace(x5sec_str, f"x5sec={x5sec}")
        else:
            cookie_str = f"{cookie_str}; x5sec={x5sec};"

        db_mh['account_manager'].update_one(
            {
                "_id": i['_id']
            },
            {
                "$set": {
                    'account_cookie': cookie_str
                }
            }
        )
        logger.info(f'梦幻x5sec更新成功 账号{i["account_user_name"]}, e5sec:{x5sec}')


def huaxi(x5sec):
    for i in db_huaxi['account_manager'].find({}):
        cookie_str = i['account_cookie']
        if "x5sec" in cookie_str:
            for x5sec_str in cookie_str.split(";"):
                if "x5sec" in x5sec_str:
                    cookie_str = cookie_str.replace(x5sec_str, f"x5sec={x5sec}")
        else:
            cookie_str = f"{cookie_str}; x5sec={x5sec};"

        db_huaxi['account_manager'].update_one(
            {
                "_id": i['_id']
            },
            {
                "$set": {
                    'account_cookie': cookie_str
                }
            }
        )
        logger.info(f'华熙x5sec更新成功 账号{i["account_user_name"]}, e5sec:{x5sec}')

def get_x5sec():
    try:
        req = requests.get("http://39.175.169.130:15555/taobaosecret/ali/slider/x5sec/cookie/v1?domain=sycm.taobao.com")
        x5sec = json.loads(req.text)
    except Exception as e:
        logger.exception(e)
    else:
        return x5sec['data']


def main():
    while True:
        x5sec = get_x5sec()
        if x5sec:
            bolaiya(x5sec)
            mh(x5sec)
            huaxi(x5sec)
        else:
            logger.info("没有x5sec")
        time.sleep(5)


if __name__ == '__main__':
    main()
