"""
模块说明：
    生意参谋-直播-本店商品成交(合作直播间，只要账号为李佳琦Austin的商品数据)
"""

import json
import time
import uuid
from datetime import timedelta, datetime

import requests
from loguru import logger

import model
import crypt_utils
from model import get_account
from helper import fetch_tbzb
from utils import DateRange, send_slider_url


def crawler(username: str, date: str):
    date_str = f"{date}|{date}"
    for cate in [
        {
            "cate_id": "121408009",
            "cate_name": "T区护理（新）",
            "level": 2
        },
        {
            "cate_id": "50011980",
            "cate_name": "乳液/面霜",
            "level": 0
        },
        {
            "cate_id": "50011978",
            "cate_name": "化妆水/爽肤水",
            "level": 0
        },
        {
            "cate_id": "50011990",
            "cate_name": "卸妆",
            "level": 0
        },
        {
            "cate_id": "125178006",
            "cate_name": "旅行装/体验装",
            "level": 0
        },
        {
            "cate_id": "50011977",
            "cate_name": "洁面",
            "level": 0
        },
        {
            "cate_id": "121454013",
            "cate_name": "眼部护理（新）",
            "level": 2
        },
        {
            "cate_id": "121484013",
            "cate_name": "眼霜",
            "level": 0
        },
        {
            "cate_id": "201173303",
            "cate_name": "防晒（新）",
            "level": 2
        },
        {
            "cate_id": "121390006",
            "cate_name": "面膜（新）",
            "level": 2
        },
        {
            "cate_id": "50011993",
            "cate_name": "面部护理套装",
            "level": 0
        },
        {
            "cate_id": "201174001",
            "cate_name": "面部精华（新）",
            "level": 2
        },
        {
            "cate_id": "201168604",
            "cate_name": "安瓶/原液",
            "level": 0
        },
        {
            "cate_id": "50011979",
            "cate_name": "液态精华",
            "level": 0
        },
        {
            "cate_id": "201750001",
            "cate_name": "精华油",
            "level": 0
        },
    ]:
        account = get_account(username)
        if not account:
            logger.error(f"账号 {username} 不存在")

        cookies = account['cookies']['cookie_dict']
        if model.col_生意参谋_市场_市场排行_商品_高流量.count_documents(
                {
                    "cate_id": cate["cate_id"],
                    'meta.data.dateRange': f'{date}|{date}',
                    'meta.tk_account.username': username
                }
        ):
            logger.info(f"已经存在: {cate}")
            continue

        headers = {
            'Host': 'sycm.taobao.com',
            'sec-ch-ua': '"Chromium";v="110", "Not A(Brand";v="24", "Microsoft Edge";v="110"',
            'bx-umidtoken': 'GCDFCD72C133ABE68E1FBCD2EE213DB54217154D228CF8CB908',
            'sec-ch-ua-mobile': '?0',
            'bx-ua': '225!NNvLBozWooizC8U7toEoV+dXi+ljrDwFaQ/N+b478XebsVTsLgon/F3LG6LaI9cERL8L3e8rhdMW5KfINrJeD/eNgoBVI/+AircaaWmjgs5IXZGOAnh+z4poQzadDIf4fjdNbUDKjeI4oL3jDGHzfeGeui9r/8HCuEzt0dDGjObvoLFXDBmzfefrQEDdDMXSkNvgofDdjxfhoeijDlH+j7hQuo01K/+zMCB3HfiSYsE3HnuE5Ig4AcclWTMke5d4fiFRGULQjcI4oJijDlH+fej0Bz0KDIFE5LLHbZSNw8Ihn9oig+Ju7gRIvuG8ey/6uz1aFvlqPBdL49hJHjdv7ejWW3DNVBtcGtdbZzVOM2rT5MxFy+LPx4SCvWwCgy7ICfF5FISAABribbqKyd/IBh9fpTwvgH+8pZPF+m466rB4e4j9HGEz77BrQE0KDM5hfDm6b34djxI4WusbIRTKKvSVtS6pSRKW8R7YO30jQofYqM3bmtR+ZLO96+B9BXSNKGssCnuY0dfWmMNzeo9BXTGGAq2vBFa31Q3Qv/1UxDmKVeaahXMzK0+QtMceDzbIX1R1Mv807QfwidYcGH7ZxWHhIZ9VLyKkpDLYR4TYhQRzob71IrEuBDIikxk8U2Yz/C+uA+pMHUnrDby1Zkl5Hzq6g83C1Xv2QNxjcTAQGyCvmYF3U8lwbABMeQOivA5ddwqoLYMr29giRaqBN4wRW+e+5aC9edkEVDWS9qk4nOUeie+LwzytDqo3OC1e5HfTxd73azVjzOXRKf+EkXlR3Vh30RXoGet3om+QTqi3eU/M1gnR5+cIEDz2jIRVnrSdWOvv3fNVXrkU5P/Ljylo3jMY7kVXRtNRZtD3VKOKb3nGUUXfxiqnPXbejSELxqQo0t0MSusXGmXPJjL9EO6b5lgInXnvzbpZKYmDNsMfejGh3fJKQsI6pTlqxpd00X5IYfgiwxkStbZOdBKgmmFPbCsgZ6B6niPunYXM38Cf4qwXDBLHyQhBTg30RrAYv3oQFiovG/v8nlhEs/h2DaWMhQzZtDpamCadKIHNeGdTTgCvHrgBHPwIGAWUETJoPs8wQlxsEFUFNop9WHvUTSFDwwLuH68r6OaFNWvADunxDJ9gmckLtCCEKAHRTLi/ZyOl+LxAhJQw3YrQWsQMMcQZRjY5mypUeRf/1HKLouW0bA2wtbohlRjxGy215JFbRuC47sWHavHPVWtNrusXDGGBiuqp',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edg/110.0.1587.63',
            'Transit-Id': 'HLwhanUURYz2tVr4FVUfhQu6ZZLyBR8cWZ+jULbDryAigDPSXtLUW+HrrC/400f4rHZ8fOe/PIBe0it4ntIqVrWaEqmUGJFmYB6ppvjG7GBHV/pMMoojq8FTSp8FlRQnbTaLDaTDjr4yKYPdSDCk7BuEMrz+qoECjT9TDYDgzok=',
            'Sycm-Referer': '/mc/mq/market_rank',
            'bx-v': '2.2.3',
            'Onetrace-Card-Id': 'sycm-mc-mq-market-rank.sycm-mc-mq-item-item-search',
            'Sycm-Query': 'dateType=day&activeKey=item',
            'sec-ch-ua-platform': '"Windows"',
            'Accept': '*/*',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': f'https://sycm.taobao.com/mc/mq/market_rank?activeKey=item&cateFlag=1&cateId={cate["cate_id"]}&dateRange={date_str}%7C{date_str}&dateType=day&sellerType=-1&spm=a21ag.11815228.LeftMenu.d591.7e2650a5uPilgt',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        }
        params = (
            ('dateRange', f'{date_str}'),
            ('dateType', 'day'),
            ('pageSize', '10'),
            ('page', '1'),
            ('order', 'desc'),
            ('orderBy', 'uvIndex'),
            ('cateId', f'{cate["cate_id"]}'),
            ('device', '0'),
            ('sellerType', '-1'),
            ('styleId', ''),
            ('priceSeg', ''),
            ('priceSegName', ''),
            ('pageId', ''),
            ('minPrice', ''),
            ('maxPrice', ''),
            ('sex', ''),
            ('sexRatio', ''),
            ('age', ''),
            ('ageRatio', ''),
            ('indexCode', 'uvIndex,seIpvUvHits,tradeIndex'),
            ('_', f'{int(time.time() * 1000)}'),
            ('token', 'bd414fbfb'),
        )
        response = requests.get(
            'https://sycm.taobao.com/mc/v2/mq/mkt/rank/item/hotsearch.json',
            headers=headers,
            params=params,
            cookies=cookies,
            timeout=10
        )
        if "statDate" in response.text:
            logger.error(f'[{username}] {cate["cate_name"]} {date_str} 交易指数排行榜抓取失败')
            logger.error(response.text)
            time.sleep(90)
            continue
        content = send_slider_url(response)
        if "操作成功" not in response.text:
            raise Exception(response.text)
        item = {
            "username": username,
            "source_data": content,
            "cate_id": cate["cate_id"],
            "created_time": datetime.now(),
            "meta": {
                "tk_account": account,
                "data": dict(params),
                "tk": cate
            }
        }
        model.col_生意参谋_市场_市场排行_商品_高流量.insert_one(item)
        logger.info(f'[{username}] {cate["cate_name"]} {date_str} 交易指数排行榜抓取成功')
        time.sleep(90)


if __name__ == '__main__':
    crawler("correctors科瑞肤旗舰店:boying", "2023-04-21")
