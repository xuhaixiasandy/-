import hashlib
import http.cookies
import requests


def md5(value):
    m = hashlib.md5()
    if isinstance(value, str):
        value = value.encode(encoding='utf-8')
    m.update(value)
    str_md5 = m.hexdigest()
    return str_md5


def convert_dict_to_cookie_string(cookies):
    cookie_list = ["{}={}".format(k, v) for k, v in cookies.items()]
    cookie_string = "; ".join(cookie_list)
    return cookie_string


def open_cookie_txt(filename: str) -> str:
    with open(filename, 'r', encoding='utf8') as f:
        cookie_str = f.readline()
        return cookie_str


def convert_cookie_string_to_dict(cookie_string):
    cookie = http.cookies.SimpleCookie()
    cookie.load(cookie_string)

    cookie_dict = {}
    for key in cookie.keys():
        cookie_dict[key] = cookie[key].value

    return cookie_dict


def convert_cookie_list_to_dict(cookie_list):
    cookie_dict = dict()
    for cookie in cookie_list:
        cookie_dict[cookie['name']] = cookie['value']
    return cookie_dict


def convert_cookies(cookie_list):
    cookie_dict = convert_cookie_list_to_dict(cookie_list)
    cookie_str = convert_dict_to_cookie_string(cookie_dict)
    output = {
        "cookie_dict": cookie_dict,
        "cookie_str": cookie_str
    }
    return output


# 如果是周一，采集上一周数据
import datetime
import hashlib
import subprocess
import time
import socket
from pypinyin import lazy_pinyin

import arrow
import pandas as pd

from loguru import logger


def before_week():
    """
    如果当前日期是周一, 获取上周 周一和周日日期
    """
    current_time = arrow.now()
    weekday = current_time.isoweekday()
    sunday = -weekday
    monyday = -(weekday + 6)
    # 上周日
    stop_date = current_time.shift(days=sunday).date()
    # 上周一
    start_date = current_time.shift(days=monyday).date()
    return {"start_date": start_date, "stop_date": stop_date}


def before_week_date_range():
    week = before_week()
    if week:
        date_range = f'{week["start_date"]}|{week["stop_date"]}'
        return date_range


def before_day():
    """
    获取上一天的日期
    """
    day = arrow.now().shift(days=-1).date().strftime("%Y-%m-%d")
    return day


def before_day_date_range():
    day = before_day()
    date_range = f'{day}|{day}'
    return date_range


def before_month():
    """
    如果当前日期是1号, 获取上一月开始和结束日期
    """
    current_time = arrow.now()
    if current_time.day == 1:
        pass
    # 获取上个月第一天
    start_date = current_time.shift(months=-1).replace(day=1).strftime("%Y-%m-%d")
    # 获取上个月最后一天
    stop_date = current_time.replace(day=1).shift(days=-1).strftime("%Y-%m-%d")
    return {"start_date": start_date, "stop_date": stop_date}


def before_month_date_range():
    month = before_month()
    if month:
        date_range = f'{month["start_date"]}|{month["stop_date"]}'
        return date_range


def work_sleep(min_time, max_time, sleep=5):
    arw = arrow.now()
    while arw.replace(**max_time) >= arw >= arw.replace(**min_time):
        arw = arrow.now()
        logger.info(f"休眠时间段: {min_time} - {max_time}")
        time.sleep(sleep)


# 生成当前时间
current_datetime = lambda: datetime.datetime.now()

# 生成当前时间 str格式
current_datetime_str = lambda: datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# 根据字符串转换日期, 字符串格式示例: 2020-2-2
str_to_date = lambda x: datetime.datetime.strptime(x, '%Y-%m-%d')


# 字符串转换日期时间, 字符串格式示例: 2020-02-02 00:00:00
def str_to_datetime(x):
    return datetime.datetime.strptime(x, '%Y-%m-%d %H:%M:%S')


# datetiem转换字符串, 字符串格式示例：xxxx-xx-xx xx:xx:xx
datetime_to_str = lambda x: datetime.datetime.strftime(x, "%Y-%m-%d %H:%M:%S")

# datetime转换date字符串
datetime_to_date_str = lambda x: datetime.datetime.strftime(x, "%Y-%m-%d")

# 时间戳转换datetiem, 精确到毫秒
timestamp_to_datetime = lambda x: datetime.datetime.fromtimestamp(x / 1000)

# 时间戳转换日期字符串, 格式为: xxxx-xx-xx, 示例: 2020-10-25
timestamp_to_datestr = lambda x: datetime.datetime.strftime(timestamp_to_datetime(x), "%Y-%m-%d")


def timestamp_to_date(x):
    return datetime.datetime.strptime(timestamp_to_datestr(x), "%Y-%m-%d")


def current_date():
    """
    生成当前日期
    :return:
    """
    today = datetime.datetime.today()
    x = f"{today.year}-{today.month}-{today.day}"
    return str_to_date(x)


def current_date_str():
    """
    生成当前日期，格式为str类型
    :return: None
    """
    today = datetime.datetime.today()
    day = str(today.day)
    if len(str(today.day)) == 1:
        day = "0%s" % day
    return f"{today.year}-{today.month}-{day}"


def to_date_range(start):
    """
    生成生意参谋date_range参数列表
    用于修复数据使用, 传入开始时间， 结束时间由当前日期-2
    日期传入格式：YYYY-MM-DD
    """
    date = arrow.now().shift(days=-2).date().__str__()
    rng = pd.date_range(start, end=date, freq='D')
    rng = rng.sort_values(ascending=False)
    rng = rng.astype("str")
    return [f"{i}|{i}" for i in rng.tolist()]


class DateRange(object):
    def __init__(self,
                 start_date: str,
                 end_date: str=arrow.now().shift(days=-2).date().__str__()):
        self.start_date = start_date
        self.end_date = end_date

    def gen_rng(self):
        """
        生成日期范围
        :return:
        """
        date = self.end_date
        rng = pd.date_range(self.start_date, end=date, freq='D')
        rng = rng.sort_values(ascending=False)
        rng = rng.astype("str")
        return rng

    def to_date_range(self):
        """
        生成生意参谋date_range参数列表
        用于修复数据使用, 传入开始时间， 结束时间由当前日期-2
        日期传入格式：YYYY-MM-DD
        返回格式：xxxxxxxx
        """
        return list(reversed([f"{i.replace('-', '')}" for i in self.gen_rng().tolist()]))

    def to_date_range_2(self):
        """
        生成生意参谋date_range参数列表
        用于修复数据使用, 传入开始时间， 结束时间由当前日期-2
        日期传入格式：YYYY-MM-DD
        返回格式：xxxx-xx-xx
        """
        return list(reversed([f"{i}" for i in self.gen_rng().tolist()]))

    def to_date_range_3(self):
        """
        生成生意参谋date_range参数列表
        用于修复数据使用, 传入开始时间， 结束时间由当前日期-2
        日期传入格式：YYYY-MM-DD
        返回格式：xxxx-xx-xx|xxxx-xx-xx
        """
        return list(reversed([f"{i}|{i}" for i in self.gen_rng().tolist()]))


def slider_url(url):
    headers = {'accept': 'application/json',}
    json_data = {'url': url}
    response = requests.post('http://39.175.169.130:15555/taobaosecret/ali/slider/v2/', headers=headers, json=json_data)
    return response


def send_slider_url(response):
    content = response.json()
    if "RGV587_ERROR::SM::哎哟喂,被挤爆啦,请稍后重试" in response.text:
        s_url = content['data']['url']
        logger.info("出现滑块")
        slider_url(url=s_url)
        raise Exception(f"出现滑块{response.text}")
    else:
        return content



if __name__ == '__main__':
    # date_range = DateRange('2023-01-01')
    # print(date_range.gen_rng())
    # print(date_range.to_date_range())

    from pprint import pprint
    # print(list(reversed(to_date_range('2023-01-01'))))
    pprint(convert_cookie_string_to_dict('dsy_lg_tp=1; lg_tp=1; remember_token=$2b$10$ew2b6SOZ4OhUCwkQnBwlZueJ0Mzgd2jdk.V2.eIlwM.tWAHrE4mDa|74aa03c138c36bfd968313a61c1ce464a1522357226d3329e946871fc227bcad003e7da3af8f7d8fd68bcb469e89845c9d32f5e5c54b4f7f1463a062a7f2cac9; token=e005a8c5e1; session=77a41592-059f-11ee-ad42-00163e16c1a3; sidebarStatus=0; CSRFToken=ImMyZjk2YzEzNzk2MDdjNzE3NjA4MTU0YTAzNzQ5MjY5NzhhMzExMDci.ZIKh6w.dpvDF3EGoUdENo5L2duxaQLiqFM'))
    # cookie_str = open_cookie_txt('cookies.txt')
    # print(type(cookie_str))
    # print(convert_cookie_string_to_dict(cookie_str))