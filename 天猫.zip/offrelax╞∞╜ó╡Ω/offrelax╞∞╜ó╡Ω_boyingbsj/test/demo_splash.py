# import requests
#
#
# lua = """
#     function main(splash)
#     splash:on_request(function(request)
#         request:set_proxy{
#             'host':'61.138.33.20',
#             'port':808,
#             'username':'uanme',
#             'password':'passwrod'
#         }
#
#      end)
#
#     -- 设置请求头
#     splash:set_user_agent("Mozilla/5.0")
#
#     splash:go("https://httpbin.org/get")
#     return splash:html()
# end
#
# """
#
#
#
# url = 'http://192.168.237.128:8050/render.html?url=https://www.sohu.com/'
# response = requests.get(url)
# print(response.text)

def my_func(num_1, num_2, fn):
    return fn(num_1, num_2)

def add(a, b):
    return a + b

print(my_func(1, 2, fn=add))