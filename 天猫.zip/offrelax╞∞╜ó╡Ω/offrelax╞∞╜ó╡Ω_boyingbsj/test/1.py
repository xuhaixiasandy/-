from model import col_tk_account

# col_tk_account.update_one(
#     {
#         "username": "珀莱雅官方旗舰店:安好"
#     },
#     {
#         "$set": {
#             "username": "珀莱雅官方旗舰店:安好",
#             "password": "proya777",
#             "status": 1,
#             "cookies": {
#                 'cookie_dict': {
#                     'thw': 'cn',
#                     'WAPFDFDTGFG': '%2B4cMKKP%2B8PI%2BMKxsQDYPVkNY',
#                     '_w_app_lg': '0',
#                     'useNativeIM': 'false',
#                     'wwUserTip': 'false',
#                     'enc': 'Tw7xJg9pug%2BrB7rSLdP1PdMR4dK4qI%2BUiDUZUgUWvrTjDmYr28Z0UEit6bzMcItCiOwmlMiubjSCjCTUOSPz9g%3D%3D',
#                     't': '1ce49ca473701426efc20f9079dba0f2',
#                     'ali_apache_id': '33.80.66.151.1675314468996.377459.7',
#                     'cookie2': '196f85c111b58d8847da169aae3394bf',
#                     '_tb_token_': 'e63eee1535b63',
#                     '_samesite_flag_': 'true',
#                     'xlly_s': '1',
#                     'sgcookie': 'E100KFJ451qoQqyrHP%2BB5MvsJBD%2FszlBb%2BXYlxILAW3PjiZBveTyTWgMu0f6Ma0aydJQLc%2FDrXJd%2BTyDpqmz1lauyCDipV5YQ4tZEF1%2Fef6osRM%3D',
#                     'unb': '2215437797594',
#                     'sn': '%E7%8F%80%E8%8E%B1%E9%9B%85%E5%AE%98%E6%96%B9%E6%97%97%E8%88%B0%E5%BA%97%3A%E5%AE%89%E5%A5%BD',
#                     'csg': '1f7999db',
#                     'cancelledSubSites': 'empty',
#                     'skt': 'ce53d6ad8628ebcf',
#                     '_cc_': 'URm48syIZQ%3D%3D',
#                     'v': '0',
#                     'cna': '7cbfG6uZIU0CAbecjuKxEnng',
#                     'uc1': 'cookie14=UoezSgBaxA%2Buyw%3D%3D&cookie21=VFC%2FuZ9aj3yE',
#                     '_m_h5_tk': '0e29d36df541238dc45edae2e5b135cf_1675668383440',
#                     '_m_h5_tk_enc': '95e8a0ecb8dad83d72106b7b764ca557',
#                     'isg': 'BCQkg0prG3c1V28AqC5C52bX9SIWvUgnwVSueT5Fju-y6cSzaclnt1oIrUFxMYB_',
#                     'l': 'fBM3Y3-HTVtQkGEZBOfwnurza77O9IRAguPzaNbMi9fP9TBB5VnCW6-Yxfx6CnGVF6ueu37ri_iWBeYBqgI-nxvO_ilFTGDmnmOk-Wf..',
#                     'tfstk': 'cjhdB-_ewhxHs-xu_WpGU1UyTsrRZ3YufTr5wjoQ9Lb597fRiahmM8RJzzq4vFC..',
#                 },
#                 'cookie_str': 'thw=cn; WAPFDFDTGFG=%2B4cMKKP%2B8PI%2BMKxsQDYPVkNY; _w_app_lg=0; useNativeIM=false; wwUserTip=false; enc=Tw7xJg9pug%2BrB7rSLdP1PdMR4dK4qI%2BUiDUZUgUWvrTjDmYr28Z0UEit6bzMcItCiOwmlMiubjSCjCTUOSPz9g%3D%3D; t=1ce49ca473701426efc20f9079dba0f2; ali_apache_id=33.80.66.151.1675314468996.377459.7; cookie2=196f85c111b58d8847da169aae3394bf; _tb_token_=e63eee1535b63; _samesite_flag_=true; xlly_s=1; sgcookie=E100KFJ451qoQqyrHP%2BB5MvsJBD%2FszlBb%2BXYlxILAW3PjiZBveTyTWgMu0f6Ma0aydJQLc%2FDrXJd%2BTyDpqmz1lauyCDipV5YQ4tZEF1%2Fef6osRM%3D; unb=2215437797594; sn=%E7%8F%80%E8%8E%B1%E9%9B%85%E5%AE%98%E6%96%B9%E6%97%97%E8%88%B0%E5%BA%97%3A%E5%AE%89%E5%A5%BD; csg=1f7999db; cancelledSubSites=empty; skt=ce53d6ad8628ebcf; _cc_=URm48syIZQ%3D%3D; v=0; cna=7cbfG6uZIU0CAbecjuKxEnng; uc1=cookie14=UoezSgBaxA%2Buyw%3D%3D&cookie21=VFC%2FuZ9aj3yE; _m_h5_tk=0e29d36df541238dc45edae2e5b135cf_1675668383440; _m_h5_tk_enc=95e8a0ecb8dad83d72106b7b764ca557; isg=BCQkg0prG3c1V28AqC5C52bX9SIWvUgnwVSueT5Fju-y6cSzaclnt1oIrUFxMYB_; l=fBM3Y3-HTVtQkGEZBOfwnurza77O9IRAguPzaNbMi9fP9TBB5VnCW6-Yxfx6CnGVF6ueu37ri_iWBeYBqgI-nxvO_ilFTGDmnmOk-Wf..; tfstk=cjhdB-_ewhxHs-xu_WpGU1UyTsrRZ3YufTr5wjoQ9Lb597fRiahmM8RJzzq4vFC..',
#             }
#         }
#     }
# )

if __name__ == "__main__":

    col_tk_account.insert_one(
        {
            "username": "彩棠旗舰店:播音服务商",
            "password": "ct183619",
            "status": 1,
            "cookies": {
                'cookie_dict': {
                    'thw': 'cn',
                    'WAPFDFDTGFG': '%2B4cMKKP%2B8PI%2BMKxsQDYPVkNY',
                    '_w_app_lg': '0',
                    'useNativeIM': 'false',
                    'wwUserTip': 'false',
                    'enc': 'Tw7xJg9pug%2BrB7rSLdP1PdMR4dK4qI%2BUiDUZUgUWvrTjDmYr28Z0UEit6bzMcItCiOwmlMiubjSCjCTUOSPz9g%3D%3D',
                    't': '1ce49ca473701426efc20f9079dba0f2',
                    'ali_apache_id': '33.80.66.151.1675314468996.377459.7',
                    'cookie2': '196f85c111b58d8847da169aae3394bf',
                    '_tb_token_': 'e63eee1535b63',
                    '_samesite_flag_': 'true',
                    'xlly_s': '1',
                    'sgcookie': 'E100KFJ451qoQqyrHP%2BB5MvsJBD%2FszlBb%2BXYlxILAW3PjiZBveTyTWgMu0f6Ma0aydJQLc%2FDrXJd%2BTyDpqmz1lauyCDipV5YQ4tZEF1%2Fef6osRM%3D',
                    'unb': '2215437797594',
                    'sn': '%E7%8F%80%E8%8E%B1%E9%9B%85%E5%AE%98%E6%96%B9%E6%97%97%E8%88%B0%E5%BA%97%3A%E5%AE%89%E5%A5%BD',
                    'csg': '1f7999db',
                    'cancelledSubSites': 'empty',
                    'skt': 'ce53d6ad8628ebcf',
                    '_cc_': 'URm48syIZQ%3D%3D',
                    'v': '0',
                    'cna': '7cbfG6uZIU0CAbecjuKxEnng',
                    'uc1': 'cookie14=UoezSgBaxA%2Buyw%3D%3D&cookie21=VFC%2FuZ9aj3yE',
                    '_m_h5_tk': '0e29d36df541238dc45edae2e5b135cf_1675668383440',
                    '_m_h5_tk_enc': '95e8a0ecb8dad83d72106b7b764ca557',
                    'isg': 'BCQkg0prG3c1V28AqC5C52bX9SIWvUgnwVSueT5Fju-y6cSzaclnt1oIrUFxMYB_',
                    'l': 'fBM3Y3-HTVtQkGEZBOfwnurza77O9IRAguPzaNbMi9fP9TBB5VnCW6-Yxfx6CnGVF6ueu37ri_iWBeYBqgI-nxvO_ilFTGDmnmOk-Wf..',
                    'tfstk': 'cjhdB-_ewhxHs-xu_WpGU1UyTsrRZ3YufTr5wjoQ9Lb597fRiahmM8RJzzq4vFC..',
                },
                'cookie_str': 'thw=cn; WAPFDFDTGFG=%2B4cMKKP%2B8PI%2BMKxsQDYPVkNY; _w_app_lg=0; useNativeIM=false; wwUserTip=false; enc=Tw7xJg9pug%2BrB7rSLdP1PdMR4dK4qI%2BUiDUZUgUWvrTjDmYr28Z0UEit6bzMcItCiOwmlMiubjSCjCTUOSPz9g%3D%3D; t=1ce49ca473701426efc20f9079dba0f2; ali_apache_id=33.80.66.151.1675314468996.377459.7; cookie2=196f85c111b58d8847da169aae3394bf; _tb_token_=e63eee1535b63; _samesite_flag_=true; xlly_s=1; sgcookie=E100KFJ451qoQqyrHP%2BB5MvsJBD%2FszlBb%2BXYlxILAW3PjiZBveTyTWgMu0f6Ma0aydJQLc%2FDrXJd%2BTyDpqmz1lauyCDipV5YQ4tZEF1%2Fef6osRM%3D; unb=2215437797594; sn=%E7%8F%80%E8%8E%B1%E9%9B%85%E5%AE%98%E6%96%B9%E6%97%97%E8%88%B0%E5%BA%97%3A%E5%AE%89%E5%A5%BD; csg=1f7999db; cancelledSubSites=empty; skt=ce53d6ad8628ebcf; _cc_=URm48syIZQ%3D%3D; v=0; cna=7cbfG6uZIU0CAbecjuKxEnng; uc1=cookie14=UoezSgBaxA%2Buyw%3D%3D&cookie21=VFC%2FuZ9aj3yE; _m_h5_tk=0e29d36df541238dc45edae2e5b135cf_1675668383440; _m_h5_tk_enc=95e8a0ecb8dad83d72106b7b764ca557; isg=BCQkg0prG3c1V28AqC5C52bX9SIWvUgnwVSueT5Fju-y6cSzaclnt1oIrUFxMYB_; l=fBM3Y3-HTVtQkGEZBOfwnurza77O9IRAguPzaNbMi9fP9TBB5VnCW6-Yxfx6CnGVF6ueu37ri_iWBeYBqgI-nxvO_ilFTGDmnmOk-Wf..; tfstk=cjhdB-_ewhxHs-xu_WpGU1UyTsrRZ3YufTr5wjoQ9Lb597fRiahmM8RJzzq4vFC..',
            }
        }
    )