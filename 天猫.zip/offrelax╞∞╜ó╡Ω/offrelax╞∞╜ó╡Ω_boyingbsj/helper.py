import time
from urllib import parse

import httpx
from loguru import logger

from utils import md5


def fetch_sycm():
    pass


# 发送请求
def fetch_tbzb(data, cookies):
    try:
        params = (
            ('jsv', '2.6.1'),
            ('appKey', '12574478'),
            ('t', f'{int(time.time() * 1000)}'),
            ('api', 'mtop.dreamweb.query.general.generalQuery'),
            ('v', '1.0'),
            ('preventFallback', 'true'),
            ('dataType', 'json'),
            # ('callback', 'mtopjsonp21'),
            ('data', data),
            ('bx-ua', 'fast-load'),
        )
        params = dict(params)

        token = cookies['_m_h5_tk'].split("_")[0]
        s = f"{token}&{params['t']}&{params['appKey']}&{params['data']}"
        params['sign'] = md5(s)

        headers = {
            'Host': 'h5api.m.taobao.com',
            'sec-ch-ua': '"Not_A Brand";v="99", "Microsoft Edge";v="109", "Chromium";v="109"',
            'sec-ch-ua-mobile': '?0',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36 Edg/109.0.1518.70',
            'sec-ch-ua-platform': '"Windows"',
            'Accept': '*/*',
            'Sec-Fetch-Site': 'same-site',
            'Sec-Fetch-Mode': 'no-cors',
            'Sec-Fetch-Dest': 'script',
            'Referer': 'https://live.taobao.com/',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        }

        url = 'https://h5api.m.taobao.com/h5/mtop.dreamweb.query.general.generalquery/1.0/'
        with httpx.Client() as client:
            resp = client.get(url=url, params=params, headers=headers, cookies=cookies, timeout=10)
            return parse.unquote(resp.text)
    except Exception as e:
        logger.error("获取数据失败", exc_info=True)
        return None


def fetch_api(api, v, data, cookies):
    headers = {
        'Host': 'h5api.m.taobao.com',
        'sec-ch-ua': '"Not_A Brand";v="99", "Microsoft Edge";v="109", "Chromium";v="109"',
        'sec-ch-ua-mobile': '?0',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36 Edg/109.0.1518.70',
        'sec-ch-ua-platform': '"Windows"',
        'Accept': '*/*',
        'Sec-Fetch-Site': 'same-site',
        'Sec-Fetch-Mode': 'no-cors',
        'Sec-Fetch-Dest': 'script',
        'Referer': 'https://market.m.taobao.com/',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
    }
    params = (
        ('jsv', '2.6.1'),
        ('appKey', '12574478'),
        ('t', f'{int(time.time() * 1000)}'),
        ('api', api),
        ('v', v),
        ('jsonpIncPrefix', 'dataCenter'),
        ('preventFallback', 'true'),
        # ('type', 'json'),
        ('dataType', 'json'),
        ('data', data),
    )
    params = dict(params)

    token = cookies['_m_h5_tk'].split("_")[0]
    s = f"{token}&{params['t']}&{params['appKey']}&{params['data']}"
    params['sign'] = md5(s)

    url = f'https://h5api.m.taobao.com/h5/{api}/{v}/'
    with httpx.Client() as client:
        resp = client.get(url=url, params=params, headers=headers, cookies=cookies, timeout=10)
        return parse.unquote(resp.text)


def slider_get(domain):
    """
    获取滑块cookie
    :return:
    """
    headers = {
        'accept': 'application/json',
    }

    params = (
        ('domain', domain),
    )

    response = httpx.get('http://192.168.1.20:5555/taobaosecret/ali/slider/x5sec/cookie/v1', headers=headers,
                         timeout=15,
                         params=params)
    return response.json()['data']


def slider_action_v2(url):
    """
    滑动滑块
    :param url: 滑块url
    :return:
    """
    headers = {
        'Content-Type': 'application/json',
    }
    data = {"url": url}
    response = httpx.post('http://192.168.1.20:5555/taobaosecret/ali/slider/v2/', headers=headers, timeout=20,
                          json=data)
    return response.json()


if __name__ == '__main__':
    data = '{"dataApi":"dataQRForm","param":"{\\"dataQRFormId\\":\\"live_ia_co_item\\",\\"beginDate\\":\\"20230201\\",\\"endDate\\":\\"20230201\\",\\"itemId\\":null,\\"itemTitle\\":null,\\"contentId\\":null,\\"coAccountId\\":\\"1759494485\\",\\"orderType\\":\\"1\\",\\"orderColumn\\":\\"live_start_time\\",\\"start\\":\\"0\\",\\"hit\\":\\"10\\",\\"queryUserRole\\":\\"ALL\\",\\"time\\":1630598400000}"}'
    fetch_tbzb(data=data)
