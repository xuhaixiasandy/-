import json
import random
import time

import requests
from loguru import logger

from model import col_tk_account
from utils import md5 as md5_hash, convert_dict_to_cookie_string

cookies = {
    'cna': 'mX0YHB+TXBwCATyxsHSsWJIc',
    '__pageEnvFromApp': 'release',
    '_m_h5_tk': f'{random.randint(1, 100)}_1670825112626',
    '_m_h5_tk_enc': 'a31603c1a09ffd67b9ceddec4cd6faa5',
    'isg': 'BI6OVJRnYW8IXNVMZ4Or9Orw1GZQD1IJvN0IarjX-hFMGy51IJ-iGTTdVkF3c0oh',
}

c = {
    "st": "19a4546443a6a562c6b29df3166d4e3d",
    "loginScene": "miniProgramLogin",
    "resultCode": 100,
    "appEntrance": "weixin",
    "smartlock": False,
    "snsType": "weixin_mini_program",
    "sid": "1884534de0e5e5d720e83797982d2315",
    "cookie2": "1884534de0e5e5d720e83797982d2315",
    "munb": 2208794055396,
    "loginResult": "success",
    "sgcookie": "W100grnudalRPkq2qkyenpW6pptVEhvPYAeXaknWYxWG0EDEWdUPXth5qPfaXMzKDpzsoacTklVg%2BeWTB2cW0ItLb99pK%2BztOoK6kfb0LtVvOVEavAIZPbxaPaA9tpJJNozL",
    "csg": "290ee050"
}

headers = {
    'Host': 'acs-m.feizhu.com',
    'bx-umidtoken': 'S2gA2u2PPdI0LRE8s9WW1s34UoWQFd73vszkqBpAWVUdD_k4byEnGUaJssmIkkjto2lbkmaxWdSYxHFTZ1RZEsByWacotfHKE1qujUiyf40-w5bwE9tSXlBkL8rMIZI2c4o=',
    'charset': 'utf-8',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; Pixel 2 Build/QQ3A.200805.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/86.0.4240.99 XWEB/4365 MMWEBSDK/20221012 Mobile Safari/537.36 MMWEBID/9165 MicroMessenger/8.0.30.2260(0x28001E55) WeChat/arm64 Weixin NetType/WIFI Language/zh_CN ABI/arm64 MiniProgramEnv/android',
    'x-uid': '2140185585',
    'mini-janus': '10%40%2FXs5QfVE%2Fm6YDgbDG8MUdDciDFaf83Q1lw%2BRVJRNWpD1F0%2BOBRFF6dJwBf41z1O6ta561eTPD1%3D%3D',
    'accept': 'application/json',
    'sgcookie': 'M100Q9HrhzpoRznkUJH%2FFw01mZGNcSM4U7VqOUR%2FMjGv%2FoUqM0ug0P9BzqEATCE7%2BJEBKdivhwabZxm03wJanaVcb15wZO2s7JO4jv565p0NP%2FGJYxRbuY5oPkJUAomusjI1',
    'x-lx-unionid': 'ocrTX6SZqZuTA5v5Iax1VGVDY_U0',
    'content-type': 'application/x-www-form-urlencoded',
    # 'x-smallstc': '{"st":"19a4546443a6a562c6b29df3166d4e3d","loginScene":"miniProgramLogin","resultCode":100,"appEntrance":"weixin","smartlock":false,"snsType":"weixin_mini_program","sid":"19a4546443a6a562c6b29df3166d4e3d","cookie2":"19a4546443a6a562c6b29df3166d4e3d","munb":2140185585,"loginResult":"success","sgcookie":"M100Q9HrhzpoRznkUJH/Fw01mZGNcSM4U7VqOUR/MjGv/oUqM0ug0P9BzqEATCE7+JEBKdivhwabZxm03wJanaVcb15wZO2s7JO4jv565p0NP/GJYxRbuY5oPkJUAomusjI1","csg":"77c4f992"}',
    'x-smallstc': json.dumps(c),
    'x-tap': 'wx',
    'Referer': 'https://servicewechat.com/wx6a96c49f29850eb5/156/page-frame.html',
}

params = (
    ('type', 'originaljson'),
    ('api', 'mtop.trip.rate.getmixratelist'),
    ('c', '07fa722ee2821be9c34e5141724b9826_1670812665814;f981b8ba47c992ed77d8b557aa7fc2d1'),
    ('v', '4.1'),
    ('data',
     '{"bizType":"1000","itemId":"54796090","pageNo":1,"loadReply":1,"isFiveGrade":0,"hideFold":true,"onlyHideRate":false,"pageSize":15,"sort":0,"tabFilter":"[{\\"code\\":\\"0\\",\\"type\\":0,\\"selected\\":true,\\"name\\":\\"\u5168\u90E8\\"}]","isNewTab":true,"stickUserRate":1,"h5Version":"1.7.2"}'),
    ('prefetch',
     'api,v,data.bizType,data.itemId,data.pageNo,data.loadReply,data.isFiveGrade,data.pageSize,data.hideFold,data.onlyHideRate,data.tabFilter,data.isNewTab,data.stickUserRate'),
    ('ttid', '12wechat000002867'),
    ('appKey', '12574478'),
    ('t', '1670814751396'),
    ('sign', 'c2017a6cead90852957cd79d81a7e32e'),
)

params = dict(params)

params['t'] = time.time()

token = cookies['_m_h5_tk'].split("_")[0]
s = f"{token}&{params['t']}&{params['appKey']}&{params['data']}"

params['sign'] = md5_hash(s)

response = requests.get('https://acs-m.feizhu.com/h5/mtop.trip.rate.getmixratelist/4.1', headers=headers,
                        params=params, cookies=cookies)
cookies = response.cookies.get_dict()
logger.info(cookies)
if cookies.get("_m_h5_tk"):
    for account in col_tk_account.find():
        account['cookies']['cookie_dict'].update(cookies)
        cookie_str = convert_dict_to_cookie_string(account['cookies']['cookie_dict'])
        account['cookies']['cookie_str'] = cookie_str
        col_tk_account.update_one(
            {"_id": account['_id']},
            {"$set": {"cookies": account['cookies']}}
        )
        logger.info(f"更新cookies成功 {account['username']}")
